<?php
session_start();
include('includes/db.php');
header('Content-Type: application/json');

if(!isset($_SESSION['user_id'])){
    echo json_encode(['success'=>false, 'message'=>'Unauthorized']);
    exit;
}

$staff_id = $_POST['staff_id'] ?? '';
$full_name = $_POST['full_name'] ?? '';
$role = $_POST['role'] ?? '';
$organization = $_POST['organization'] ?? '';
$schedule = $_POST['schedule'] ?? '';
$status = $_POST['status'] ?? '';

if(!$staff_id || !$full_name || !$role || !$status){
    echo json_encode(['success'=>false, 'message'=>'Please fill required fields']);
    exit;
}

$stmt = $conn->prepare("UPDATE medical_staff SET full_name=?, role=?, organization=?, schedule=?, status=?, updated_at=NOW() WHERE staff_id=?");
$stmt->bind_param("sssssi", $full_name, $role, $organization, $schedule, $status, $staff_id);

if($stmt->execute()){
    echo json_encode(['success'=>true]);
} else {
    echo json_encode(['success'=>false, 'message'=>'Database error']);
}
?>
