<?php
session_start();
include('includes/db.php');
header('Content-Type: application/json');

if(!isset($_SESSION['user_id'])){
    echo json_encode(['success'=>false, 'message'=>'Unauthorized']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$staff_id = $data['staff_id'] ?? '';

if(!$staff_id){
    echo json_encode(['success'=>false, 'message'=>'Invalid staff ID']);
    exit;
}

$stmt = $conn->prepare("DELETE FROM medical_staff WHERE staff_id=?");
$stmt->bind_param("i", $staff_id);

if($stmt->execute()){
    echo json_encode(['success'=>true]);
} else {
    echo json_encode(['success'=>false, 'message'=>'Database error']);
}
?>
