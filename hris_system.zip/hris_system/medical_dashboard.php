<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

include 'generate_medical_notifications.php';

// Fetch all medical staff
$staffList = [];
$staffSql = "SELECT * FROM medical_staff ORDER BY full_name ASC";
$staffResult = $conn->query($staffSql);
if($staffResult && $staffResult->num_rows > 0){
    while($row = $staffResult->fetch_assoc()){
        $staffList[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Medical Dashboard</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <!-- FullCalendar -->
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
</head>

<body>

<!-- TOP NAVBAR (reuse exactly) -->
<div class="navbar">
    <h2>PulseWork: Medical Information System</h2>
    <div class="user-info">
        <div class="notification-wrapper">
            <button id="notificationBtn" class="notification-btn">
                🔔
                <span class="notification-badge" id="notificationCount">0</span>
            </button>
        </div>

        <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<!-- MEDICAL SUB NAVBAR (simplified) -->
<nav class="sub-navbar">
    <ul class="nav-menu">
        <li><a href="medical_dashboard.php" class="active">Dashboard</a></li>
        <li><a href="medical_staff.php">Medical Staff</a></li>
        <li><a href="medical_schedule.php">Schedules</a></li>
        <li><a href="medical_reports.php">Reports</a></li>
    </ul>

    <div class="dashboard-switch">
        <a href="dashboard.php" class="switch-btn">
            👥 HR Dashboard
        </a>
    </div>
</nav>

<!-- MAIN CONTENT -->
<div class="main-content">

    <h2>🏥 Medical Staff Overview</h2>

    <div class="dashboard-grid">

        <!-- STAFF LIST -->
        <div class="employee-list">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Organization</th>
                        <th>Schedule</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($staffList)): ?>
                        <?php foreach($staffList as $staff): ?>
                            <tr onclick="window.location='medical_staff_view.php?staff_id=<?= $staff['staff_id'] ?>'" style="cursor:pointer;">
                                <td><?= htmlspecialchars($staff['full_name']); ?></td>
                                <td><?= htmlspecialchars($staff['role']); ?></td>
                                <td><?= htmlspecialchars($staff['organization']); ?></td>
                                <td>
                                    <?php
                                    // Optionally, fetch schedule for this staff for today or the next duty
                                    $scheduleSql = "SELECT duty_date, start_time, end_time 
                                                    FROM medical_schedules 
                                                    WHERE staff_id = ? 
                                                    ORDER BY duty_date ASC LIMIT 1";
                                    $stmt = $conn->prepare($scheduleSql);
                                    $stmt->bind_param("i", $staff['staff_id']);
                                    $stmt->execute();
                                    $res = $stmt->get_result();
                                    if($res && $res->num_rows > 0){
                                        $s = $res->fetch_assoc();
                                        echo htmlspecialchars($s['duty_date'] . ' ' . substr($s['start_time'],0,5) . '-' . substr($s['end_time'],0,5));
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td><?= htmlspecialchars($staff['status']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align:center; color:gray;">No medical staff found.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
            </table>
        </div>

        <!-- CALENDAR PANEL -->
        <div class="dashboard-calendar">
            <h2>On-Duty Schedule</h2>
            <div id="calendar" style="min-height: 500px"></div>
        </div>

    </div>
</div>

<!-- NOTIFICATION MODAL -->
<div id="notificationModal" class="modal">
    <div class="modal-content" style="max-width:600px; max-height:70vh; overflow-y:auto; padding:20px;">
        <span class="close" onclick="closeNotificationModal()">&times;</span>
        <h3>🔔 Notifications</h3>
        <div id="notificationContent">
            <p style="color:gray;">Loading notifications...</p>
        </div>
    </div>
</div>

<!-- LOGOUT MODAL -->
<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<!-- SCHEDULE MODAL -->
<div id="scheduleModal" class="modal">
    <div class="modal-content" style="max-width:600px; max-height:70vh; overflow-y:auto; padding:20px;">
        <span class="close" onclick="closeScheduleModal()">&times;</span>
        <h3>Schedule Details</h3>
        <div id="scheduleContent">
            <p style="color:gray;">Loading...</p>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendar');

    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        events: 'fetch_medical_schedule.php', // your PHP endpoint
        height: 'auto',
        eventColor: '#378006',
        navLinks: true,
        editable: false,
        dayMaxEvents: true,
        eventDidMount: function(info) {
            const startTime = info.event.start ? info.event.start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
            const endTime = info.event.end ? info.event.end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
            info.el.setAttribute('title', info.event.title + (startTime && endTime ? `\n${startTime} - ${endTime}` : ''));
        },
        // Open modal on date click
        dateClick: function(info) {
            const modal = document.getElementById('scheduleModal');
            const content = document.getElementById('scheduleContent');
            content.innerHTML = '<p style="color:gray;">Loading...</p>';
            modal.style.display = 'block';

            fetch(`fetch_medical_schedule.php?date=${info.dateStr}`)
                .then(res => res.json())
                .then(events => {
                    if(events.length === 0) {
                        content.innerHTML = '<p style="color:gray;">No doctors scheduled for this day.</p>';
                        return;
                    }
                    let html = '';
                    events.forEach(e => {
                        const start = e.start.slice(11,16); // HH:MM
                        const end = e.end.slice(11,16);     // HH:MM
                        html += `<p><strong>${e.title}</strong> (${start} - ${end})</p>`;
                    });
                    content.innerHTML = html;
                })
                .catch(() => {
                    content.innerHTML = '<p style="color:red;">Failed to load schedule.</p>';
                });
        }
    });

    calendar.render();
});

// Close schedule modal function
function closeScheduleModal() {
    document.getElementById('scheduleModal').style.display = 'none';
}

// Notifications and logout logic (same as before)
const notificationBtn = document.getElementById('notificationBtn');
const notificationModal = document.getElementById('notificationModal');
const notificationContent = document.getElementById('notificationContent');
const notificationCount = document.getElementById('notificationCount');

notificationBtn.onclick = function () {
    notificationModal.style.display = 'block';
    loadNotifications();
};

function loadNotifications() {
    fetch('fetch_notifications.php')
        .then(res => res.json())
        .then(data => {
            notificationContent.innerHTML = '';
            let total = 0;
            for (const section in data) {
                if (!data[section].length) continue;
                const title = document.createElement('div');
                title.className = 'notification-group-title';
                title.textContent = section;
                notificationContent.appendChild(title);
                data[section].forEach(item => {
                    total++;
                    const div = document.createElement('div');
                    div.className = 'notification-item';
                    div.innerHTML = item.text;
                    if (!item.read) {
                        div.classList.add('unread');
                        const dot = document.createElement('span');
                        dot.className = 'unread-dot';
                        div.appendChild(dot);
                    }
                    div.onclick = () => markAsRead(item.id, div);
                    notificationContent.appendChild(div);
                });
            }
            notificationCount.textContent = total || 0;
            if (total === 0) notificationContent.innerHTML = '<p style="color:gray;">No notifications today 🎉</p>';
        })
        .catch(() => notificationContent.innerHTML = '<p style="color:red;">Error loading notifications</p>');
}

// Mark notification as read AND redirect
function markAsReadAndRedirect(id, element, redirectPage) {
    fetch('mark_notification_read.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
    })
    .then(res => res.json())
    .then(resp => {
        if(resp.success){
            element.classList.remove('unread');
            const dot = element.querySelector('.unread-dot');
            if(dot) dot.remove();
            if(redirectPage) window.location.href = redirectPage;
        }
    });
}

// Make all modal close buttons work
document.querySelectorAll('.modal .close').forEach(btn => {
    btn.onclick = function() {
        this.closest('.modal').style.display = 'none';
    }
});

// Close modal when clicking outside
window.onclick = function(event) {
    document.querySelectorAll('.modal').forEach(modal => {
        if(event.target === modal) modal.style.display = 'none';
    });
};

// Logout modal logic
const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e){
    e.preventDefault();
    logoutModal.style.display = 'block';
}
cancelLogout.onclick = function(){ logoutModal.style.display = 'none'; }
confirmLogout.onclick = function(){ window.location.href = 'logout.php'; }
</script>

</body>
</html>
