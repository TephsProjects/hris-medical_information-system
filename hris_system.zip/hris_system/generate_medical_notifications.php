<?php
include 'includes/db.php';

$today = date('Y-m-d');
$upcoming = date('Y-m-d', strtotime('+3 days'));

/* 1️⃣ On-duty today */
$q = $conn->query("
    SELECT staff_id, full_name
    FROM medical_staff
    WHERE staff_id IN (
        SELECT staff_id FROM medical_schedules
        WHERE duty_date = '$today'
    )
");

while ($r = $q->fetch_assoc()) {
    $msg = "{$r['full_name']} is on medical duty today";

    // Check if notification already exists today
    $check = $conn->prepare("
        SELECT id FROM notifications 
        WHERE emp_id = ? AND type = 'medical_today' AND message = ? AND DATE(created_at) = CURDATE()
    ");
    $check->bind_param("is", $r['staff_id'], $msg);
    $check->execute();
    $check->store_result();

    if ($check->num_rows === 0) {
        $stmt = $conn->prepare("
            INSERT INTO notifications (emp_id, type, message)
            VALUES (?, 'medical_today', ?)
        ");
        $stmt->bind_param("is", $r['staff_id'], $msg);
        $stmt->execute();
    }

    $check->close();
}

/* 2️⃣ Upcoming duties */
$q = $conn->query("
    SELECT m.staff_id, m.full_name, s.duty_date
    FROM medical_schedules s
    JOIN medical_staff m ON s.staff_id = m.staff_id
    WHERE s.duty_date BETWEEN '$today' AND '$upcoming'
");

while ($r = $q->fetch_assoc()) {
    $msg = "{$r['full_name']} has medical duty on {$r['duty_date']}";

    $check = $conn->prepare("
        SELECT id FROM notifications 
        WHERE emp_id = ? AND type = 'medical_upcoming' AND message = ? AND DATE(created_at) = CURDATE()
    ");
    $check->bind_param("is", $r['staff_id'], $msg);
    $check->execute();
    $check->store_result();

    if ($check->num_rows === 0) {
        $stmt = $conn->prepare("
            INSERT INTO notifications (emp_id, type, message)
            VALUES (?, 'medical_upcoming', ?)
        ");
        $stmt->bind_param("is", $r['staff_id'], $msg);
        $stmt->execute();
    }

    $check->close();
}

/* 3️⃣ No schedule assigned */
$q = $conn->query("
    SELECT staff_id, full_name
    FROM medical_staff
    WHERE staff_id NOT IN (
        SELECT DISTINCT staff_id FROM medical_schedules
    )
");

while ($r = $q->fetch_assoc()) {
    $msg = "{$r['full_name']} has no assigned medical schedule";

    $check = $conn->prepare("
        SELECT id FROM notifications 
        WHERE emp_id = ? AND type = 'medical_missing' AND message = ? AND DATE(created_at) = CURDATE()
    ");
    $check->bind_param("is", $r['staff_id'], $msg);
    $check->execute();
    $check->store_result();

    if ($check->num_rows === 0) {
        $stmt = $conn->prepare("
            INSERT INTO notifications (emp_id, type, message)
            VALUES (?, 'medical_missing', ?)
        ");
        $stmt->bind_param("is", $r['staff_id'], $msg);
        $stmt->execute();
    }

    $check->close();
}
?>
