<?php
session_start();
include 'db.php'; // Database connection

/**
 * Check if user is logged in
 */
function check_login() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }
}

/**
 * Redirect user based on role
 */
function redirect_role($role) {
    switch ($role) {
        case 'admin':
            header("Location: admin_dashboard.php");
            break;
        case 'hr':
            header("Location: hr_dashboard.php");
            break;
        case 'employee':
            header("Location: employee_dashboard.php");
            break;
        default:
            header("Location: index.php");
    }
    exit();
}

/**
 * Sanitize user input
 */
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

/**
 * Get company info
 */
function get_company_info() {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM company_info LIMIT 1");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        // Insert default row if none exists
        $conn->query("INSERT INTO company_info (company_name) VALUES ('Your Company')");
        $stmt->execute();
        $result = $stmt->get_result();
    }
    return $result->fetch_assoc();
}

/**
 * Get system settings
 */
function get_settings() {
    global $conn;
    $result = $conn->query("SELECT * FROM settings LIMIT 1");
    return $result->fetch_assoc();
}

/**
 * Send notification for new employee
 */
function sendNewEmployeeNotification($employee_id) {
    global $conn;

    // Fetch employee info
    $stmt = $conn->prepare("SELECT first_name, last_name, email FROM employees WHERE employee_id = ?");
    $stmt->bind_param("i", $employee_id);
    $stmt->execute();
    $emp = $stmt->get_result()->fetch_assoc();

    if (!$emp) return;

    // Example: send email to HR or Admin
    $to = "hr@yourcompany.com"; // Could be dynamic
    $subject = "New Employee Added: {$emp['first_name']} {$emp['last_name']}";
    $message = "A new employee has been added to the system.\n\n";
    $message .= "Name: {$emp['first_name']} {$emp['last_name']}\n";
    $message .= "Email: {$emp['email']}\n\n";
    $message .= "Check the system for more details.";
    $headers = "From: noreply@yourcompany.com";

    @mail($to, $subject, $message, $headers);
}

/**
 * Send notification for new leave request
 */
function sendLeaveNotification($leave_id) {
    global $conn;

    // Fetch leave info
    $stmt = $conn->prepare("SELECT l.*, e.first_name, e.last_name FROM leaves l 
                            JOIN employees e ON l.employee_id = e.employee_id 
                            WHERE leave_id = ?");
    $stmt->bind_param("i", $leave_id);
    $stmt->execute();
    $leave = $stmt->get_result()->fetch_assoc();

    if (!$leave) return;

    // Example: send email to HR/Admin
    $to = "hr@yourcompany.com"; // Could be dynamic
    $subject = "New Leave Request: {$leave['first_name']} {$leave['last_name']}";
    $message = "A new leave request has been submitted.\n\n";
    $message .= "Employee: {$leave['first_name']} {$leave['last_name']}\n";
    $message .= "Leave Type: {$leave['leave_type']}\n";
    $message .= "From: {$leave['start_date']} To: {$leave['end_date']}\n\n";
    $message .= "Check the system for approval.";
    $headers = "From: noreply@yourcompany.com";

    @mail($to, $subject, $message, $headers);
}
