<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: settings.php");
    exit();
}

$id = $_POST['id'] ?? null;
$default_work_hours = trim($_POST['default_work_hours'] ?? '8:00-17:00');
$regularization_days = (int)($_POST['regularization_days'] ?? 90);
$date_format = trim($_POST['date_format'] ?? 'Y-m-d');
$notify_new_employee = isset($_POST['notify_new_employee']) ? (int)$_POST['notify_new_employee'] : 1;
$notify_leave_request = isset($_POST['notify_leave_request']) ? (int)$_POST['notify_leave_request'] : 1;

if ($id) {
    $stmt = $conn->prepare("UPDATE settings SET default_work_hours=?, regularization_days=?, date_format=?, notify_new_employee=?, notify_leave_request=? WHERE id=?");
    $stmt->bind_param("sisiii", $default_work_hours, $regularization_days, $date_format, $notify_new_employee, $notify_leave_request, $id);
    $stmt->execute();
}

header("Location: settings.php?updated=1");
exit();
