<?php
session_start();
include('includes/db.php');

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $full_name = trim($_POST['full_name']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'];

    if ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Username already exists!";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $insert = $conn->prepare("INSERT INTO users (username, password, full_name, role) VALUES (?, ?, ?, ?)");
            $insert->bind_param("ssss", $username, $hashed_password, $full_name, $role);

            if ($insert->execute()) {
                $success = "Account created successfully! You can now <a href='index.php'>login</a>.";
            } else {
                $error = "Error creating account: " . $conn->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - PulseWork</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body.register-body {
            background: linear-gradient(135deg, #50e3c2, #4a90e2);
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .register-container {
            background: #fff;
            padding: 40px 35px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            width: 380px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .register-container:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }
        .register-container h2 {
            margin-bottom: 5px;
            font-size: 28px;
            color: #333;
        }
        .tagline {
            font-size: 14px;
            color: #777;
            margin-bottom: 25px;
        }
        .input-group {
            margin-bottom: 18px;
            text-align: left;
        }
        .input-group label {
            font-weight: 600;
            margin-bottom: 6px;
            display: block;
            color: #555;
        }
        .input-group input, .input-group select {
            width: 93%;
            padding: 10px 12px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 15px;
            transition: border-color 0.3s, box-shadow 0.3s;
        }
        .input-group input:focus, .input-group select:focus {
            border-color: #007bff;
            box-shadow: 0 0 8px rgba(0, 123, 255, 0.2);
            outline: none;
        }
        .btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 12px 0;
            border-radius: 8px;
            width: 100%;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: background 0.3s, transform 0.2s;
        }
        .btn:hover {
            background: #0056b3;
            transform: translateY(-2px);
        }
        .error, .success {
            padding: 12px;
            border-radius: 8px;
            margin-top: 15px;
            font-size: 14px;
            text-align: center;
        }
        .error {
            background: #fde2e1;
            color: #d93025;
        }
        .success {
            background: #d4edda;
            color: #155724;
        }
        .login-footer {
            margin-top: 20px;
            font-size: 12px;
            color: #888;
        }
        @media(max-width: 420px) {
            .register-container { width: 90%; padding: 30px 20px; }
        }
    </style>
</head>
<body class="register-body">
    <div class="register-container">
        <h2>PulseWork</h2>
        <p class="tagline">Create your HR account</p>

        <form method="POST" action="">
            <div class="input-group">
                <label>Full Name</label>
                <input type="text" name="full_name" placeholder="Enter full name" required>
            </div>
            <div class="input-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="Choose a username" required>
            </div>
            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter password" required>
            </div>
            <div class="input-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" placeholder="Confirm password" required>
            </div>
            <div class="input-group">
                <label>Role</label>
                <select name="role" required>
                    <option value="HR Staff" selected>HR Staff</option>
                    <option value="Admin">Admin</option>
                </select>
            </div>
            <button type="submit" class="btn">Register</button>
        </form>

        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <?php if ($success): ?>
            <p class="success"><?php echo $success; ?></p>
        <?php endif; ?>

        <div class="login-footer">
            &copy; <?php echo date("Y"); ?> PulseWork. All rights reserved. <br>
            <a href="index.php">Back to Login</a>
        </div>
    </div>
</body>
</html>
