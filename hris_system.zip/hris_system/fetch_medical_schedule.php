<?php
session_start();
include('includes/db.php');

header('Content-Type: application/json');

$events = [];

// Check if a date is passed (YYYY-MM-DD)
$date = isset($_GET['date']) ? $_GET['date'] : null;

if ($date) {
    // Prepare statement to fetch schedules for that specific date
    $stmt = $conn->prepare("
        SELECT ms.*, m.full_name
        FROM medical_schedules ms
        JOIN medical_staff m ON ms.staff_id = m.staff_id
        WHERE ms.duty_date = ?
        ORDER BY ms.start_time ASC
    ");
    $stmt->bind_param("s", $date);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    // Fetch all schedules for FullCalendar
    $sql = "
        SELECT ms.*, m.full_name
        FROM medical_schedules ms
        JOIN medical_staff m ON ms.staff_id = m.staff_id
        ORDER BY ms.duty_date ASC, ms.start_time ASC
    ";
    $result = $conn->query($sql);
}

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $events[] = [
            'title' => $row['full_name'] . ' (' . substr($row['start_time'],0,5) . '-' . substr($row['end_time'],0,5) . ')',
            'start' => $row['duty_date'] . 'T' . $row['start_time'],
            'end'   => $row['duty_date'] . 'T' . $row['end_time'],
            'id'    => $row['schedule_id']
        ];
    }
}

echo json_encode($events);
