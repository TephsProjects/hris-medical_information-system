<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid Position ID.");
}

$position_id = $_GET['id'];

$delete = $conn->prepare("DELETE FROM positions WHERE position_id = ?");
$delete->bind_param("i", $position_id);

if ($delete->execute()) {
    header("Location: position_list.php");
    exit();
} else {
    die("Error deleting position.");
}
