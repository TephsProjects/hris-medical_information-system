<?php
header('Content-Type: application/json');

// Get year from query string, default to current year
$year = $_GET['year'] ?? date('Y');

/**
 * Calculate Easter Sunday for a given year
 */
function easterDate($year) {
    $base = new DateTime("$year-03-21");
    $days = easter_days($year);
    return $base->modify("+$days days");
}

// Array to hold all events
$events = [];

/* =========================
   FIXED HOLIDAYS
========================= */
$fixedHolidays = [
    '01-01' => "New Year's Day",
    '04-09' => "Araw ng Kagitingan",
    '05-01' => "Labor Day",
    '06-12' => "Independence Day",
    '11-30' => "Bonifacio Day",
    '12-25' => "Christmas Day",
    '12-30' => "Rizal Day"
];

foreach ($fixedHolidays as $md => $name) {
    $events[] = [
        'title' => $name,
        'start' => "$year-$md",
        'allDay' => true,
        'color' => '#e63946'
    ];
}

/* =========================
   HOLY WEEK (based on Easter)
========================= */
$easter = easterDate($year);

$holyWeek = [
    'Maundy Thursday' => (clone $easter)->modify('-3 days'),
    'Good Friday'     => (clone $easter)->modify('-2 days'),
    'Black Saturday'  => (clone $easter)->modify('-1 day'),
];

foreach ($holyWeek as $name => $date) {
    $events[] = [
        'title' => "✝️ $name",
        'start' => $date->format('Y-m-d'),
        'allDay' => true,
        'color' => '#6a4c93'
    ];
}

/* =========================
   NATIONAL HEROES' DAY
========================= */
$heroesDay = new DateTime("last monday of august $year");
$events[] = [
    'title' => "National Heroes' Day",
    'start' => $heroesDay->format('Y-m-d'),
    'allDay' => true,
    'color' => '#e63946'
];

/* =========================
   SPECIAL DAYS
========================= */
$specialDays = [
    '02-25' => "EDSA People Power Anniversary",
    '08-21' => "Ninoy Aquino Day",
    '11-01' => "All Saints' Day",
    '12-08' => "Immaculate Conception",
    '12-24' => "Christmas Eve",
    '12-31' => "New Year's Eve"
];

foreach ($specialDays as $md => $name) {
    $events[] = [
        'title' => $name,
        'start' => "$year-$md",
        'allDay' => true,
        'color' => '#f4a261'
    ];
}

/* =========================
   VARIABLE HOLIDAYS (if any)
========================= */
$variableHolidays = [
    // Example (adjust yearly):
    // "$year-02-10" => "Chinese New Year",
    // "$year-04-10" => "Eid'l Fitr",
];

foreach ($variableHolidays as $date => $name) {
    $events[] = [
        'title' => "🌙 $name",
        'start' => $date,
        'allDay' => true,
        'color' => '#2a9d8f'
    ];
}

// Output JSON
echo json_encode($events, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
