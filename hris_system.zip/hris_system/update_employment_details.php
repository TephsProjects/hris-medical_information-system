<?php
session_start();
include 'includes/db.php';

if (!isset($_POST['emp_id'])) {
    exit('Invalid request');
}

$emp_id = (int) $_POST['emp_id'];

// ==========================
// Handle contract file upload
// ==========================
$contract_file_path = null;

if (!empty($_FILES['contract_file']['name'])) {

    $upload_dir = 'uploads/contracts/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $file_name = time() . '_' . basename($_FILES['contract_file']['name']);
    $target_path = $upload_dir . $file_name;

    $allowed_types = ['pdf', 'doc', 'docx'];
    $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed_types)) {
        exit('Invalid file type. Only PDF, DOC, DOCX allowed.');
    }

    if (!move_uploaded_file($_FILES['contract_file']['tmp_name'], $target_path)) {
        exit('Failed to upload contract file.');
    }

    $contract_file_path = $target_path;
}

// ==========================
// Build dynamic UPDATE query
// ==========================
$sql = "
    UPDATE employees SET
        tax_status = ?,
        date_hired = ?,
        regularization_date = ?,
        contract_end_date = ?,
        employment_status = ?,
        employment_type = ?,
        work_schedule = ?
";

$params = [
    $_POST['tax_status'],
    $_POST['date_hired'],
    $_POST['regularization_date'] ?: null,
    $_POST['contract_end_date'] ?: null,
    $_POST['employment_status'],
    $_POST['employment_type'],
    $_POST['work_schedule']
];

$types = "sssssss";

// Only update contract_file if a new one was uploaded
if ($contract_file_path !== null) {
    $sql .= ", contract_file = ?";
    $params[] = $contract_file_path;
    $types .= "s";
}

$sql .= " WHERE emp_id = ?";
$params[] = $emp_id;
$types .= "i";

// ==========================
// Execute statement
// ==========================
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();

// ==========================
// Redirect back
// ==========================
header("Location: employee_employment.php?id=$emp_id&updated=1");
exit();
