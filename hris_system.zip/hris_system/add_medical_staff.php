<?php
session_start();
include('includes/db.php');
header('Content-Type: application/json');

if(!isset($_SESSION['user_id'])){
    echo json_encode(['success'=>false, 'message'=>'Unauthorized']);
    exit;
}

$full_name = $_POST['full_name'] ?? '';
$role = $_POST['role'] ?? '';
$organization = $_POST['organization'] ?? '';
$schedule = $_POST['schedule'] ?? '';
$status = $_POST['status'] ?? '';

if(!$full_name || !$role || !$status){
    echo json_encode(['success'=>false, 'message'=>'Please fill required fields']);
    exit;
}

$stmt = $conn->prepare("INSERT INTO medical_staff (full_name, role, organization, schedule, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
$stmt->bind_param("sssss", $full_name, $role, $organization, $schedule, $status);

if($stmt->execute()){
    echo json_encode(['success'=>true]);
} else {
    echo json_encode(['success'=>false, 'message'=>'Database error']);
}
?>
