<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid Department ID.");
}

$department_id = $_GET['id'];

$delete = $conn->prepare("DELETE FROM departments WHERE department_id = ?");
$delete->bind_param("i", $department_id);

if ($delete->execute()) {
    header("Location: department_list.php");
    exit();
} else {
    die("Error deleting department.");
}
