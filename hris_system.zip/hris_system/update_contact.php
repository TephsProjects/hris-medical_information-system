<?php
session_start();
include 'includes/db.php';

if (!isset($_POST['emp_id'])) {
    exit('Invalid request');
}

$emp_id = $_POST['emp_id'];

$stmt = $conn->prepare("
    UPDATE employees SET
        mobile_number = ?,
        secondary_mobile = ?,
        email = ?,
        personal_email = ?,
        contact_person = ?,
        emergency_contact = ?,
        emergency_contact_relationship = ?,
        emergency_contact_address = ?
    WHERE emp_id = ?
");

$stmt->bind_param(
    "ssssssssi",
    $_POST['mobile_number'],
    $_POST['secondary_mobile'],
    $_POST['email'],
    $_POST['personal_email'],
    $_POST['contact_person'],
    $_POST['emergency_contact'],
    $_POST['emergency_contact_relationship'],
    $_POST['emergency_contact_address'],
    $emp_id
);

$stmt->execute();

header("Location: employee_contact.php?id=$emp_id&updated=1");
exit();
