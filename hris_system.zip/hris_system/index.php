<?php
session_start();
include('includes/db.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];

            if ($user['role'] === 'Admin') {
                header("Location: dashboard.php");
            } else {
                header("Location: dashboard.php"); 
            }
            exit();
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "User not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PulseWork Login</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/index.css">
    <style>
        body.login-body {
            background: linear-gradient(135deg, #076fe9, #cbcbcb);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .login-container {
            background: #ffffff;
            padding: 40px 35px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            width: 380px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .login-container:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }

        .login-container h2 {
            margin-bottom: 5px;
            font-size: 28px;
            color: #333;
        }
        .tagline {
            font-size: 14px;
            color: #777;
            margin-bottom: 25px;
        }

        .input-group {
            margin-bottom: 18px;
            text-align: left;
        }
        .input-group label {
            font-weight: 600;
            margin-bottom: 6px;
            display: block;
            color: #555;
        }
        .input-group input {
            width: 93%;
            padding: 10px 12px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 15px;
            transition: border-color 0.3s, box-shadow 0.3s;
        }
        .input-group input:focus {
            border-color: #007bff;
            box-shadow: 0 0 8px rgba(0, 123, 255, 0.2);
            outline: none;
        }

        .btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 12px 0;
            border-radius: 8px;
            width: 100%;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: background 0.3s, transform 0.2s;
        }
        .btn:hover {
            background: #0056b3;
            transform: translateY(-2px);
        }

        .error {
            background: #fde2e1;
            color: #d93025;
            padding: 12px;
            border-radius: 8px;
            margin-top: 15px;
            font-size: 14px;
            text-align: center;
        }

        .login-footer {
            margin-top: 20px;
            font-size: 12px;
            color: #888;
        }

        @media(max-width: 420px) {
            .login-container {
                width: 90%;
                padding: 30px 20px;
            }
        }

        .login-logo {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .login-logo img {
            width: 180px; 
            height: auto;
            border-radius: 8px; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transition: transform 0.2s ease;
        }

        .login-logo img:hover {
            transform: scale(1.05);
        }

    </style>
</head>
<body class="login-body">
    <div class="login-logo">
        <img src="assets/images/PulseWork-logo.png" alt="PulseWork Logo">
    </div>

    <div class="login-container">
        <h2>PulseWork</h2>
        <p class="tagline">Smart HR Management</p>

        <form method="POST" action="">
            <div class="input-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="Enter your username" required>
            </div>
            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter your password" required>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>

        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <div class="login-footer">
            &copy; <?php echo date("Y"); ?> PulseWork. All rights reserved.
        </div>
    </div>
</body>
</html>