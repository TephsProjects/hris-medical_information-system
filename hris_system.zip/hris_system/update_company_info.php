<?php
session_start();
include('includes/db.php');

// Access check
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Make sure we have POST data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $company_name = trim($_POST['company_name'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $postal_code = trim($_POST['postal_code'] ?? ''); // NEW
    $contact_number = trim($_POST['contact_number'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $website = trim($_POST['website'] ?? '');

    // Validate required fields
    if (empty($company_name)) {
        header("Location: company_info.php?error=Company+name+is+required");
        exit();
    }

    if ($id) {
        // Update existing row
        $stmt = $conn->prepare("
            UPDATE company_info 
            SET company_name = ?, address = ?, postal_code = ?, contact_number = ?, email = ?, website = ? 
            WHERE id = ?
        ");
        $stmt->bind_param("ssssssi", $company_name, $address, $postal_code, $contact_number, $email, $website, $id);
        $stmt->execute();
    } else {
        // Insert a new row if ID not set (just in case)
        $stmt = $conn->prepare("
            INSERT INTO company_info (company_name, address, postal_code, contact_number, email, website) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("ssssss", $company_name, $address, $postal_code, $contact_number, $email, $website);
        $stmt->execute();
    }

    // Redirect back with success
    header("Location: company_info.php?updated=1");
    exit();
}

// If accessed directly, redirect
header("Location: company_info.php");
exit();
?>
