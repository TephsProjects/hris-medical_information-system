<?php
session_start();
include('includes/db.php');
header('Content-Type: application/json');

if(!isset($_SESSION['user_id'])){
    echo json_encode(['success'=>false, 'message'=>'Unauthorized']);
    exit;
}

// Get POST data
$action = $_POST['action'] ?? '';
$schedule_id = $_POST['schedule_id'] ?? '';
$staff_id = $_POST['staff_id'] ?? '';
$duty_date = $_POST['duty_date'] ?? '';
$start_time = $_POST['start_time'] ?? '';
$end_time = $_POST['end_time'] ?? '';
$remarks = $_POST['remarks'] ?? '';

try {
    if(!$action){
        throw new Exception('Action is required');
    }

    if($action === 'add' || $action === 'edit'){
        if(!$staff_id || !$duty_date || !$start_time || !$end_time){
            throw new Exception('Please fill all required fields');
        }
    }

    if($action === 'add'){
        $stmt = $conn->prepare("
            INSERT INTO medical_schedules (staff_id, duty_date, start_time, end_time, remarks, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param("issss", $staff_id, $duty_date, $start_time, $end_time, $remarks);
        if(!$stmt->execute()){
            throw new Exception('Database error: '.$stmt->error);
        }
        echo json_encode(['success'=>true]);

    } elseif($action === 'edit') {
        if(!$schedule_id){
            throw new Exception('Schedule ID is required for edit');
        }
        $stmt = $conn->prepare("
            UPDATE medical_schedules
            SET staff_id=?, duty_date=?, start_time=?, end_time=?, remarks=?
            WHERE schedule_id=?
        ");
        $stmt->bind_param("issssi", $staff_id, $duty_date, $start_time, $end_time, $remarks, $schedule_id);
        if(!$stmt->execute()){
            throw new Exception('Database error: '.$stmt->error);
        }
        echo json_encode(['success'=>true]);

    } elseif($action === 'delete') {
        if(!$schedule_id){
            throw new Exception('Schedule ID is required for delete');
        }
        $stmt = $conn->prepare("DELETE FROM medical_schedules WHERE schedule_id=?");
        $stmt->bind_param("i", $schedule_id);
        if(!$stmt->execute()){
            throw new Exception('Database error: '.$stmt->error);
        }
        echo json_encode(['success'=>true]);

    } else {
        throw new Exception('Invalid action');
    }

} catch(Exception $e){
    echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
}
