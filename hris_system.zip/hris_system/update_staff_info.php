<?php
session_start();
include('includes/db.php');
header('Content-Type: application/json');

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success'=>false, 'message'=>'Unauthorized']);
    exit;
}

// Get POST data
$staff_id = intval($_POST['staff_id'] ?? 0);
$role = trim($_POST['role'] ?? '');
$organization = trim($_POST['organization'] ?? '');
$status = trim($_POST['status'] ?? '');

$date_of_birth = trim($_POST['date_of_birth'] ?? '');
$contact_number = trim($_POST['contact_number'] ?? '');
$email = trim($_POST['email'] ?? '');
$address = trim($_POST['address'] ?? '');
$emergency_contact_name = trim($_POST['emergency_contact_name'] ?? '');
$emergency_contact_number = trim($_POST['emergency_contact_number'] ?? '');
$medical_license = trim($_POST['medical_license'] ?? '');
$qualifications = trim($_POST['qualifications'] ?? '');
$notes = trim($_POST['notes'] ?? '');

// Basic validation
if($staff_id <= 0){
    echo json_encode(['success'=>false, 'message'=>'Invalid staff ID']);
    exit;
}

$conn->begin_transaction();
try {
    // Update medical_staff (basic info)
    if($role || $organization || $status){
        $stmt = $conn->prepare("UPDATE medical_staff SET role=?, organization=?, status=? WHERE staff_id=?");
        $stmt->bind_param("sssi", $role, $organization, $status, $staff_id);
        $stmt->execute();
        $stmt->close();
    }

    // Check if personal info exists
    $stmt = $conn->prepare("SELECT id FROM medical_staff_info WHERE staff_id=?");
    $stmt->bind_param("i", $staff_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $exists = $res->num_rows > 0;
    $stmt->close();

    if($exists){
        // Update existing personal info
        $stmt = $conn->prepare("
            UPDATE medical_staff_info 
            SET date_of_birth=?, contact_number=?, email=?, address=?, emergency_contact_name=?, emergency_contact_number=?, medical_license=?, qualifications=?, notes=? 
            WHERE staff_id=?
        ");
        $stmt->bind_param(
            "sssssssssi",
            $date_of_birth, $contact_number, $email, $address,
            $emergency_contact_name, $emergency_contact_number,
            $medical_license, $qualifications, $notes, $staff_id
        );
        $stmt->execute();
        $stmt->close();
    } else {
        // Insert new personal info
        $stmt = $conn->prepare("
            INSERT INTO medical_staff_info 
            (staff_id, date_of_birth, contact_number, email, address, emergency_contact_name, emergency_contact_number, medical_license, qualifications, notes) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            "isssssssss",
            $staff_id, $date_of_birth, $contact_number, $email, $address,
            $emergency_contact_name, $emergency_contact_number,
            $medical_license, $qualifications, $notes
        );
        $stmt->execute();
        $stmt->close();
    }

    $conn->commit();
    echo json_encode(['success'=>true]);

} catch(Exception $e){
    $conn->rollback();
    echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
}
?>
