<?php
session_start();
include('includes/db.php');

// Access check
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Fetch company info (assuming only one row)
$stmt = $conn->prepare("SELECT * FROM company_info LIMIT 1");
$stmt->execute();
$result = $stmt->get_result();
$company = $result->fetch_assoc();

// Set default date
$today = date('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PhilHealth Form ER2</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <style>
        .main-content {
            padding: 40px 20px;
            display: flex;
            justify-content: center;
        }

        .info-section {
            background: #fff;
            border-radius: 12px;
            padding: 35px 40px;
            max-width: 800px;
            width: 100%;
            box-shadow: 0 6px 18px rgba(0,0,0,0.1);
            transition: transform 0.2s ease;
        }

        .info-section:hover { transform: translateY(-3px); }

        .info-section h3 {
            text-align: center;
            font-size: 1.7rem;
            color: #333;
            margin-bottom: 25px;
            font-weight: 600;
        }

        .form-row { margin-bottom: 18px; }

        .form-row label {
            font-weight: 600;
            display: block;
            margin-bottom: 6px;
            color: #555;
        }

        .form-control, select {
            width: 95%;
            padding: 11px 14px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 15px;
            transition: 0.2s;
        }

        .form-control:focus, select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0,123,255,0.3);
            outline: none;
        }

        .update-btn {
            display: block;
            width: 100%;
            padding: 12px 0;
            font-size: 1rem;
            font-weight: 600;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 25px;
            transition: background 0.2s;
        }

        .update-btn:hover { background-color: #0056b3; }
    </style>
</head>
<body>

<div class="navbar">
    <h2>PulseWork: HR Information System</h2>
    <div class="user-info">
        <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<nav class="sub-navbar">
        <ul class="nav-menu">
            <li><a href="dashboard.php" class="active">Dashboard</a></li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_leave.php">Leave Form</a></li>
                    <li><a href="leave_requests.php">Leave Requests</a></li>
                </ul>
            </li>

            <!-- <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_payroll.php">Add Payroll</a></li>
                    <li><a href="payroll.php">Payroll List</a></li>
                    <li><a href="add_benefits.php">Add Benefits</a></li>
                    <li><a href="benefits_list.php">Benefits List</a></li>
                </ul>
            </li> -->

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
                <ul class="dropdown-content">
                    <li><a href="reports.php">Reports</a></li>
                    <li><a href="accounts.php">Accounts</a></li>
                    <li><a href="add_employee.php">Add Employee</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_job.php">Job Opening</a></li>
                    <li><a href="job_list.php">Job List</a></li>
                    <li><a href="add_candidate.php">Add Candidate</a></li>
                    <li><a href="candidate_list.php">Candidates</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
                <ul class="dropdown-content">
                    <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                    <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                    <li><a href="training_list.php">Trainings</a></li>
                    <li><a href="add_training.php">Add Training</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_performance.php">Add Evaluation</a></li>
                    <li><a href="performance_list.php">Evaluation List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)" class="active">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php" class="active">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
        </ul>
    </nav>

<div class="main-content">
    <div class="info-section">
        <h3>PhilHealth Form ER2 Pre-Fill</h3>

        <form method="POST" action="generate_philhealth_er2_pdf.php" target="_blank">

            <div class="form-row">
                <label>Name of Employer:</label>
                <input type="text" name="employer_name"
                       class="form-control"
                       value="<?= htmlspecialchars($company['company_name'] ?? '') ?>"
                       required>
            </div>

            <div class="form-row">
                <label>PhilHealth Employer Number:</label>
                <input type="text" name="employer_number"
                       class="form-control"
                       required>
            </div>

            <div class="form-row">
                <label>Employer Address:</label>
                <input type="text" name="address"
                       class="form-control"
                       value="<?= htmlspecialchars($company['address'] ?? '') ?>"
                       required>
            </div>

            <div class="form-row">
                <label>Email Address:</label>
                <input type="email" name="email_address"
                       class="form-control"
                       value="<?= htmlspecialchars($company['email'] ?? '') ?>">
            </div>

            <div class="form-row">
                <label>Hire Date From:</label>
                <input type="date" name="start_date" class="form-control" value="<?= $today ?>" required>
            </div>

            <div class="form-row">
                <label>Hire Date To:</label>
                <input type="date" name="end_date" class="form-control" value="<?= $today ?>" required>
            </div>

            <div class="form-row">
                <label>Signatory:</label>
                <input type="text" name="signatory"
                       class="form-control"
                       required>
            </div>

            <div class="form-row">
                <label>Date:</label>
                <input type="date" name="report_date"
                       class="form-control"
                       value="<?= $today ?>"
                       required>
            </div>

            <button type="submit" class="update-btn">💾 Generate PDF</button>
        </form>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.preventDefault();
    document.querySelectorAll('.dropdown').forEach(d => {
        if (!d.contains(event.target)) d.classList.remove('active');
    });
    event.target.closest('.dropdown').classList.toggle('active');
}

const logoutBtn = document.getElementById('logoutBtn');
logoutBtn.onclick = function(e){
    e.preventDefault();
    alert('Logout function here');
}
</script>

</body>
</html>
