<?php
header('Content-Type: application/json');
include 'includes/db.php';

$month = (int)($_GET['month'] ?? date('m'));
$year  = (int)($_GET['year'] ?? date('Y'));

$events = [];

/* =========================
   EMPLOYEE BIRTHDAYS
========================= */
$birthdaySql = "
    SELECT 
        CONCAT(first_name, ' ', last_name) AS title,
        DATE_FORMAT(date_of_birth, '%m-%d') AS event_date
    FROM employees
    WHERE MONTH(date_of_birth) = ?
";

$stmt = $conn->prepare($birthdaySql);
$stmt->bind_param("i", $month);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $events[] = [
        'date' => $year . '-' . $row['event_date'],
        'title' => '🎂 ' . $row['title'] . "'s Birthday"
    ];
}

/* =========================
   PH HOLIDAYS (SAFE INCLUDE)
========================= */
ob_start();
$_GET['year'] = $year;   // pass year to holidays_ph.php
include 'holidays_ph.php';
$holidayJson = ob_get_clean();

$holidays = json_decode($holidayJson, true);

if (is_array($holidays)) {
    foreach ($holidays as $holiday) {
        if ((int)date('m', strtotime($holiday['start'])) === $month) {
            $events[] = [
                'date' => $holiday['start'],
                'title' => '🇵🇭 ' . $holiday['title']
            ];
        }
    }
}

/* Sort by date */
usort($events, function ($a, $b) {
    return strtotime($a['date']) - strtotime($b['date']);
});

echo json_encode($events);
