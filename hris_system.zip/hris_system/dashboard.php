<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$search = '';
$employment_status = '';
$employment_type = '';
$birthday = '';

$query = "SELECT e.*, d.department_name, p.position_name, b.branch_name
          FROM employees e
          LEFT JOIN departments d ON e.department_id = d.department_id
          LEFT JOIN positions p ON e.position_id = p.position_id
          LEFT JOIN branches b ON e.branch_id = b.branch_id
          WHERE 1=1";
$params = [];
$types = "";

if (!empty($_GET['search'])) {
    $search = $_GET['search'];
    $search_query = "%$search%";
    $query .= " AND (e.first_name LIKE ? OR e.last_name LIKE ? OR d.department_name LIKE ? OR p.position_name LIKE ?)";
    $types .= "ssss";
    array_push($params, $search_query, $search_query, $search_query, $search_query);
}

if (!empty($_GET['employment_status'])) {
    $employment_status = $_GET['employment_status'];
    $query .= " AND employment_status = ?";
    $types .= "s";
    array_push($params, $employment_status);
}

if (!empty($_GET['employment_type'])) {
    $employment_type = $_GET['employment_type'];
    $query .= " AND employment_type = ?";
    $types .= "s";
    array_push($params, $employment_type);
}

if (!empty($_GET['birthday'])) {
    $birthday = $_GET['birthday'];
    $query .= " AND date_of_birth = ?";
    $types .= "s";
    array_push($params, $birthday);
}

$limit = 10; 
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

$sort_column = $_GET['sort_column'] ?? 'employee_no'; 
$sort_order = $_GET['sort_order'] ?? 'ASC'; 
$allowed_columns = ['employee_no', 'first_name', 'last_name'];
$sort_column = in_array($sort_column, $allowed_columns) ? $sort_column : 'employee_no';
$sort_order = strtoupper($sort_order) === 'DESC' ? 'DESC' : 'ASC';

$count_query = "SELECT COUNT(*) as total FROM employees WHERE 1=1";
if (!empty($params)) {
    $count_stmt = $conn->prepare($count_query . substr($query, strpos($query, " AND"))); 
    $count_stmt->bind_param($types, ...$params);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total_rows = $count_result->fetch_assoc()['total'];
} else {
    $count_result = $conn->query($count_query);
    $total_rows = $count_result->fetch_assoc()['total'];
}

$total_pages = ceil($total_rows / $limit);

$query .= " ORDER BY $sort_column $sort_order LIMIT ?, ?";
$types .= "ii";
array_push($params, $offset, $limit);

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$employees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
    <style>
    .controls-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 15px;
    }
    .filter-form {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        align-items: center;
    }

    .filter-form input {
        padding: 8px 12px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 14px;
    }

    .filter-btn {
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 6px;
        padding: 8px 15px;
        cursor: pointer;
        transition: 0.3s;
    }
    .filter-btn:hover {
        background-color: #0056b3;
    }

    .filter-form select {
        padding: 8px 12px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 14px;
        background-color: #fff;
        color: #333;
        transition: 0.3s;
        cursor: pointer;
    }

    .filter-form select:focus {
        border-color: #007bff;
        box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.2);
        outline: none;
    }

    .filter-form select option {
        padding: 5px;
    }

    .filter-form select::-ms-expand {
        display: none; 
    }

    .filter-form select {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20width%3D'14'%20height%3D'8'%20viewBox%3D'0%200%2014%208'%20xmlns%3D'http%3A//www.w3.org/2000/svg'%3E%3Cpath%20d%3D'M1%201l6%206%206-6'%20stroke%3D'%23333'%20stroke-width%3D'2'%20fill%3D'none'%20fill-rule%3D'evenodd'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 10px center;
        background-size: 12px 12px;
    }

    .clear-btn {
        background-color: #6c757d;
        color: #fff;
        border: none;
        border-radius: 6px;
        padding: 8px 15px;
        text-decoration: none;
        display: inline-block;
    }
    .clear-btn:hover {
        background-color: #5a6268;
    }

    .export-buttons {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .export-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 14px;
        font-size: 14px;
        font-weight: 600;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        color: #fff;
        transition: 0.3s;
        box-shadow: 0 2px 5px rgba(0,0,0,0.15);
    }

    .csv-btn {
        background-color: #28a745;
    }
    .csv-btn:hover {
        background-color: #218838;
        transform: translateY(-1px);
    }

    .excel-btn {
        background-color: #007bff;
    }
    .excel-btn:hover {
        background-color: #0056b3;
        transform: translateY(-1px);
    }

    @media(max-width: 900px) {
        .controls-container {
            flex-direction: column;
            align-items: stretch;
        }
        .filter-form, .export-buttons {
            justify-content: flex-start;
        }
    }

    .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 10px;
        margin-top: 15px;
    }

    .pagination-btn {
        background-color: #007bff;
        color: #fff;
        padding: 6px 12px;
        border-radius: 6px;
        text-decoration: none;
        transition: 0.3s;
    }

    .pagination-btn:hover {
        background-color: #0056b3;
    }

    .sortable-header {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        text-decoration: none;
        color: #ffffffff;
        font-weight: 600;
        cursor: pointer;
        transition: color 0.3s;
    }

    .sortable-header:hover {
        color: #007bff;
    }

    .sort-arrow {
        font-size: 12px;
        display: inline-block;
        transition: transform 0.3s, color 0.3s;
        color: #ccc; 
    }

    .sort-arrow.asc {
        transform: rotate(0deg);
        color: #28a745;
    }

    .sort-arrow.desc {
        transform: rotate(180deg);
        color: #dc3545; 
    }
    .calendar-events {
        margin-top: 15px;
        background: #fff;
        border-radius: 8px;
        padding: 12px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.08);
    }

    .calendar-events h3 {
        margin-bottom: 10px;
        font-size: 16px;
    }

    .calendar-events ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .calendar-events li {
        padding: 6px 8px;
        border-bottom: 1px solid #eee;
        font-size: 14px;
    }

    .calendar-events li:last-child {
        border-bottom: none;
    }

    </style>
</head>
<body>
    <div class="navbar">
        <h2>PulseWork: HR Information System</h2>
        <div class="user-info">
            <div class="notification-wrapper">
                <button id="notificationBtn" class="notification-btn">
                    🔔
                    <span class="notification-badge" id="notificationCount">0</span>
                </button>
            </div>

            <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?></span>
            <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
        </div>

    </div>

    <nav class="sub-navbar">
        <ul class="nav-menu">
            <li><a href="dashboard.php" class="active">Dashboard</a></li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_leave.php">Leave Form</a></li>
                    <li><a href="leave_requests.php">Leave Requests</a></li>
                </ul>
            </li>

            <!-- <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_payroll.php">Add Payroll</a></li>
                    <li><a href="payroll.php">Payroll List</a></li>
                    <li><a href="add_benefits.php">Add Benefits</a></li>
                    <li><a href="benefits_list.php">Benefits List</a></li>
                </ul>
            </li> -->

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
                <ul class="dropdown-content">
                    <li><a href="reports.php">Reports</a></li>
                    <li><a href="accounts.php">Accounts</a></li>
                    <li><a href="add_employee.php">Add Employee</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_job.php">Job Opening</a></li>
                    <li><a href="job_list.php">Job List</a></li>
                    <li><a href="add_candidate.php">Add Candidate</a></li>
                    <li><a href="candidate_list.php">Candidates</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
                <ul class="dropdown-content">
                    <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                    <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                    <li><a href="training_list.php">Trainings</a></li>
                    <li><a href="add_training.php">Add Training</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_performance.php">Add Evaluation</a></li>
                    <li><a href="performance_list.php">Evaluation List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
        </ul>

        <div class="dashboard-switch">
            <a href="medical_dashboard.php" class="switch-btn">
                🏥 Medical Dashboard
            </a>
        </div>
    </nav>
    <div class="main-content">
        <?php if (isset($_GET['deleted'])): ?>
            <div style="
                padding: 10px; 
                background: #d4edda; 
                color: #155724; 
                border: 1px solid #c3e6cb; 
                border-radius: 5px; 
                margin-bottom: 15px;
                font-weight: bold;
            ">
                ✅ Employee deleted successfully!
            </div>
        <?php endif; ?>

        <h3>Employee List</h3>

        <div class="dashboard-grid">
            <div class="employee-list">
                <div class="controls-container">
                    <form method="GET" action="dashboard.php" class="filter-form">
                        <input type="text" name="search" placeholder="Search employee..." value="<?= htmlspecialchars($search) ?>">

                        <select name="employment_status">
                            <option value="">-- Employment Status --</option>
                            <?php 
                            $statuses = ["Active", "Seasonal", "Probationary", "Resigned", "Terminated", "AWOL", "End of Contract"];
                            foreach ($statuses as $st): ?>
                                <option value="<?= $st ?>" <?= ($employment_status == $st) ? 'selected' : '' ?>><?= $st ?></option>
                            <?php endforeach; ?>
                        </select>

                        <select name="employment_type">
                            <option value="">-- Employment Type --</option>
                            <?php 
                            $typesArr = ["Full-time", "Part-time", "Contractual", "Project-based", "Probationary"];
                            foreach ($typesArr as $tp): ?>
                                <option value="<?= $tp ?>" <?= ($employment_type == $tp) ? 'selected' : '' ?>><?= $tp ?></option>
                            <?php endforeach; ?>
                        </select>

                        <input type="date" name="birthday" value="<?= htmlspecialchars($birthday) ?>">

                        <button type="submit" class="btn filter-btn">🔍 Filter</button>
                        <?php if ($search || $employment_status || $employment_type || $birthday): ?>
                            <a href="dashboard.php" class="btn clear-btn">❌ Clear</a>
                        <?php endif; ?>
                    </form>

                    <div class="export-buttons">
                        <button onclick="exportCSV()" class="btn export-btn csv-btn">
                            📄 Export CSV
                        </button>
                        <button onclick="openImportModal()" class="btn export-btn excel-btn">
                            📥 Import CSV / Excel
                        </button>
                    </div>
                </div>

                <div class="table-container">
                    <table id="visibleTable">
                        <thead>
                            <tr>
                                <th>
                                    <a href="?<?= http_build_query(array_merge($_GET, [
                                        'sort_column' => 'employee_no',
                                        'sort_order' => ($sort_column=='employee_no' && $sort_order=='ASC') ? 'DESC' : 'ASC',
                                        'page' => 1
                                    ])) ?>" class="sortable-header">
                                        Employee No
                                        <span class="sort-arrow <?= ($sort_column=='employee_no') ? strtolower($sort_order) : '' ?>">&#9650;</span>
                                    </a>
                                </th>
                                <th>
                                    <a href="?<?= http_build_query(array_merge($_GET, [
                                        'sort_column' => 'first_name',
                                        'sort_order' => ($sort_column=='first_name' && $sort_order=='ASC') ? 'DESC' : 'ASC',
                                        'page' => 1
                                    ])) ?>" class="sortable-header">
                                        Full Name
                                        <span class="sort-arrow <?= ($sort_column=='first_name') ? strtolower($sort_order) : '' ?>">&#9650;</span>
                                    </a>
                                </th>
                                <th>Department</th>
                                <th>Position</th>
                                <th>Civil Status</th>
                                <th>Gender</th>
                                <th>Date Hired</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($employees as $row): ?>
                            <tr onclick="window.location='employee_view.php?id=<?php echo $row['emp_id']; ?>'" style="cursor:pointer;">
                                <td><?= htmlspecialchars($row['employee_no']) ?></td>
                                <td><?= htmlspecialchars($row['first_name'].' '.$row['last_name']) ?></td>
                                <td><?= htmlspecialchars($row['department_name']) ?></td>
                                <td><?= htmlspecialchars($row['position_name']) ?></td>
                                <td><?= htmlspecialchars($row['civil_status']) ?></td>
                                <td><?= htmlspecialchars($row['gender']) ?></td>
                                <td><?= htmlspecialchars($row['date_hired']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page'=>$page-1])) ?>" class="pagination-btn">← Previous</a>
                    <?php endif; ?>

                    <span>Page <?= $page ?> of <?= $total_pages ?></span>

                    <?php if ($page < $total_pages): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page'=>$page+1])) ?>" class="pagination-btn">Next →</a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="dashboard-calendar">
                <h2>Calendar</h2>
                <div id="calendar"></div>

                <div class="calendar-events">
                <h3>📅 Events This Month</h3>
                <ul id="eventList">
                    <li>Loading events...</li>
                </ul>
            </div>
            </div>

        </div>

        <table id="exportTable">
            <thead>
                <tr>
                    <th>Employee No</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Address</th>
                    <th>Age</th>
                    <th>Date of Birth</th>
                    <th>Branch / Location</th>
                    <th>Department</th>
                    <th>Position</th>
                    <th>Civil Status</th>
                    <th>Tax Status</th>
                    <th>TIN</th>
                    <th>SSS</th>
                    <th>PhilHealth</th>
                    <th>Nationality</th>
                    <th>Gender</th>
                    <th>Mobile</th>
                    <th>Email</th>
                    <th>Contact Person</th>
                    <th>Emergency Contact No</th>
                    <th>Date Hired</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($employees as $row): ?>
                <tr>
                    <td><?= htmlspecialchars($row['employee_no']) ?></td>
                    <td><?= htmlspecialchars($row['first_name']) ?></td>
                    <td><?= htmlspecialchars($row['last_name']) ?></td>
                    <td><?= htmlspecialchars($row['address']) ?></td>
                    <td><?= htmlspecialchars($row['age']) ?></td>
                    <td><?= htmlspecialchars($row['date_of_birth']) ?></td>
                    <td><?= htmlspecialchars($row['branch_name']) ?></td>
                    <td><?= htmlspecialchars($row['department_name']) ?></td>
                    <td><?= htmlspecialchars($row['position_name']) ?></td>
                    <td><?= htmlspecialchars($row['civil_status']) ?></td>
                    <td><?= htmlspecialchars($row['tax_status']) ?></td>
                    <td><?= htmlspecialchars($row['tin_no']) ?></td>
                    <td><?= htmlspecialchars($row['sss_no']) ?></td>
                    <td><?= htmlspecialchars($row['philhealth_no']) ?></td>
                    <td><?= htmlspecialchars($row['nationality']) ?></td>
                    <td><?= htmlspecialchars($row['gender']) ?></td>
                    <td><?= htmlspecialchars($row['mobile_number']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td><?= htmlspecialchars($row['contact_person']) ?></td>
                    <td><?= htmlspecialchars($row['emergency_contact']) ?></td>
                    <td><?= htmlspecialchars($row['date_hired']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div id="notificationModal" class="modal">
        <div class="modal-content" style="max-width:600px; max-height:70vh; overflow-y:auto; padding:20px;">
            <span class="close" onclick="closeNotificationModal()">&times;</span>
            <h3>🔔 Notifications</h3>

            <div id="notificationContent">
                <p style="color:gray;">Loading notifications...</p>
            </div>
        </div>
    </div>


    <div id="importModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeImportModal()">&times;</span>
            <h3>Import Employees</h3>

            <form action="import_employees.php" method="POST" enctype="multipart/form-data">
                <p>
                    <strong>Accepted formats:</strong> CSV, XLSX<br>
                    <small>Column order must match the template.</small>
                </p>

                <input type="file" name="import_file" accept=".csv,.xlsx" required>

                <div class="modal-buttons" style="margin-top:15px;">
                    <button type="submit" class="btn filter-btn">Upload & Import</button>
                    <button type="button" class="btn" onclick="closeImportModal()" style="background:#ccc;color:#333;">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div id="logoutModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Confirm Logout</h3>
            <p>Are you sure you want to logout?</p>
            <div class="modal-buttons">
                <button id="confirmLogout" class="btn">Yes, Logout</button>
                <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
            </div>
        </div>
    </div>

<script>
    const notificationBtn = document.getElementById('notificationBtn');
    const notificationModal = document.getElementById('notificationModal');
    const notificationContent = document.getElementById('notificationContent');
    const notificationCount = document.getElementById('notificationCount');

    notificationBtn.onclick = function () {
        notificationModal.style.display = 'block';
        loadNotifications();
    };

    function loadNotifications() {
        fetch('fetch_notifications.php')
            .then(res => res.json())
            .then(data => {
                notificationContent.innerHTML = '';
                let total = 0;

                for (const section in data) {
                    if (!data[section].length) continue;

                    // Section title
                    const title = document.createElement('div');
                    title.className = 'notification-group-title';
                    title.textContent = section;
                    notificationContent.appendChild(title);

                    data[section].forEach(item => {
                        total++;

                        // Create notification div
                        const div = document.createElement('div');
                        div.className = 'notification-item';
                        div.innerHTML = item.text;

                        // Mark unread notifications
                        if (!item.read) {
                            div.classList.add('unread'); // style this in CSS
                            const dot = document.createElement('span');
                            dot.className = 'unread-dot';
                            div.appendChild(dot);
                        }

                        // Click to mark as read
                        div.onclick = () => markAsRead(item.id, div);

                        notificationContent.appendChild(div);
                    });
                }

                notificationCount.textContent = total || 0;

                if (total === 0) {
                    notificationContent.innerHTML = '<p style="color:gray;">No notifications today 🎉</p>';
                }
            })
            .catch(() => {
                notificationContent.innerHTML = '<p style="color:red;">Error loading notifications</p>';
            });
    }

    // Mark notification as read
    function markAsRead(id, element) {
        fetch('mark_notification_read.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        })
        .then(res => res.json())
        .then(resp => {
            if (resp.success) {
                element.classList.remove('unread');
                const dot = element.querySelector('.unread-dot');
                if (dot) dot.remove();
            }
        });
    }

    // ✅ Make all modal close buttons work
    document.querySelectorAll('.modal .close').forEach(btn => {
        btn.onclick = function() {
            this.closest('.modal').style.display = 'none';
        }
    });

    // Close modal when clicking outside
    window.onclick = function(event) {
        document.querySelectorAll('.modal').forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    };

    function exportCSV() {
        const params = new URLSearchParams(window.location.search); 
        fetch('export_employees.php?' + params.toString())
            .then(response => response.blob())
            .then(blob => {
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = 'employees.csv';
                link.click();
            });
    }

    function openImportModal() {
        document.getElementById('importModal').style.display = 'block';
    }
    function closeImportModal() {
        document.getElementById('importModal').style.display = 'none';
    }
    
    function toggleDropdown(event) {
        event.preventDefault();
        const parent = event.target.closest('.dropdown');
        parent.classList.toggle('active');
    }

    document.addEventListener('DOMContentLoaded', function () {
        const calendarEl = document.getElementById('calendar');
        const eventList = document.getElementById('eventList');

        function loadMonthlyEvents(year, month) {
            const urls = [`birthdays.php`, `holidays_ph.php?year=${year}`];
            const ul = document.getElementById('eventList');
            ul.innerHTML = '<li>Loading events...</li>';

            Promise.all(urls.map(url => fetch(url).then(r => r.json())))
                .then(results => {
                    const data = results.flat(); // merge birthdays + holidays
                    const monthEvents = data.filter(ev => ev.start.startsWith(`${year}-${month}`));

                    ul.innerHTML = '';
                    if (!monthEvents.length) {
                        ul.innerHTML = '<li>No events this month</li>';
                        return;
                    }

                    monthEvents.forEach(event => {
                        const li = document.createElement('li');
                        li.textContent = `${event.start} – ${event.title}`;
                        ul.appendChild(li);
                    });
                })
                .catch(err => {
                    ul.innerHTML = '<li>Error loading events</li>';
                    console.error(err);
                });
        }

        const calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            initialDate: new Date(),  // <-- ensure current month
            height: 'auto',
            dayMaxEventRows: 2,
            fixedWeekCount: false,

            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: ''
            },

            datesSet: function(info) {
                const currentStart = info.view.currentStart;
                const year = currentStart.getFullYear();
                const month = String(currentStart.getMonth() + 1).padStart(2, '0');
                loadMonthlyEvents(year, month);
            },

            eventSources: [
                {
                    url: 'birthdays.php',
                    color: '#38bdf8',
                    className: 'birthday'
                },
                {
                    events: function(fetchInfo, successCallback, failureCallback) {
                        const year = fetchInfo.start.getFullYear();
                        fetch('holidays_ph.php?year=' + year)
                            .then(res => res.json())
                            .then(data => {
                                data.forEach(e => e.className = 'holiday');
                                successCallback(data);
                            })
                            .catch(err => failureCallback(err));
                    }
                }
            ],

            eventDidMount: function(info) {
                info.el.title = info.event.title;
            }
        });

        calendar.render();

    });

    const logoutBtn = document.getElementById('logoutBtn');
    const logoutModal = document.getElementById('logoutModal');
    const closeModal = document.querySelector('.close');
    const cancelLogout = document.getElementById('cancelLogout');
    const confirmLogout = document.getElementById('confirmLogout');

    logoutBtn.onclick = function(e) {
        e.preventDefault();
        logoutModal.style.display = 'block';
    }

    cancelLogout.onclick = function() {
        logoutModal.style.display = 'none';
    }

    confirmLogout.onclick = function() {
        window.location.href = 'logout.php';
    }

    window.onclick = function(event) {
        if (event.target == logoutModal) {
            logoutModal.style.display = 'none';
        }
    }
</script>
</body>
</html>