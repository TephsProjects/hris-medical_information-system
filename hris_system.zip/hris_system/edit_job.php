<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$message = '';
$messageClass = '';

if (!isset($_GET['job_id']) || !is_numeric($_GET['job_id'])) {
    header("Location: job_list.php");
    exit();
}

$job_id = intval($_GET['job_id']);

$stmt = $conn->prepare("SELECT * FROM job_openings WHERE job_id = ?");
$stmt->bind_param("i", $job_id);
$stmt->execute();
$result = $stmt->get_result();
$job = $result->fetch_assoc();

if (!$job) {
    $message = "❌ Job not found.";
    $messageClass = "error";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $department = trim($_POST['department']);
    $description = trim($_POST['description']);
    $requirements = trim($_POST['requirements']);
    $status = $_POST['status'];

    if (empty($title) || empty($department)) {
        $message = "⚠️ Please fill in all required fields.";
        $messageClass = "error";
    } else {
        $update = $conn->prepare("UPDATE job_openings SET title=?, department=?, description=?, requirements=?, status=? WHERE job_id=?");
        $update->bind_param("sssssi", $title, $department, $description, $requirements, $status, $job_id);

        if ($update->execute()) {
            $message = "✅ Job details updated successfully!";
            $messageClass = "success";

            $stmt->execute();
            $result = $stmt->get_result();
            $job = $result->fetch_assoc();
        } else {
            $message = "❌ Error updating job: " . $conn->error;
            $messageClass = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Job Opening</title>
<link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
<link rel="stylesheet" href="assets/css/style.css">
<style>
.main-content {
    padding: 40px 20px;
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
}

.job-card {
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    max-width: 600px;
    width: 100%;
}
.job-card h3 {
    text-align: center;
    color: #007bff;
    margin-bottom: 25px;
}

.message {
    padding: 12px 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-weight: 600;
    text-align: center;
    animation: fadein 0.5s;
}
.message.success { background-color: #d4edda; color: #155724; }
.message.error { background-color: #f8d7da; color: #721c24; }
@keyframes fadein { from {opacity:0;} to {opacity:1;} }

form {
    display: grid;
    grid-template-columns: 1fr;
    gap: 18px;
}

form label {
    font-weight: 600;
    color: #333;
}

form input, form textarea, form select {
    width: 100%;
    padding: 10px 12px;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 14px;
    transition: 0.2s;
}

form input:focus, form select:focus, form textarea:focus {
    border-color: #007bff;
    outline: none;
}

textarea { resize: vertical; min-height: 80px; }

button {
    padding: 12px;
    border: none;
    border-radius: 8px;
    background: #007bff;
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.2s;
}
button:hover { background: #0056b3; }

.back-btn {
    display: inline-block;
    margin-top: 10px;
    padding: 10px 16px;
    border-radius: 8px;
    background-color: #6c757d;
    color: #fff;
    text-decoration: none;
    font-size: 14px;
    transition: 0.2s;
}
.back-btn:hover { background-color: #5a6268; }

@media(max-width: 650px) {
    .main-content { padding: 20px 10px; }
}
</style>
</head>
<body>
<div class="navbar">
    <h2>PulseWork: HR Information System</h2>
    <div class="user-info">
        <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<nav class="sub-navbar">
    <ul class="nav-menu">
        <li><a href="dashboard.php">Dashboard</a></li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>
            
        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_leave.php">Leave Form</a></li>
                <li><a href="leave_requests.php">Leave Request Lists</a></li>
            </ul>
        </li>

        <!-- <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_payroll.php">Add Payroll</a></li>
                <li><a href="payroll.php">Payroll List</a></li>
                <li><a href="add_benefits.php">Add Benefits</a></li>
                <li><a href="benefits_list.php">Benefits List</a></li>
            </ul>
        </li> -->

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
            <ul class="dropdown-content">
                <li><a href="reports.php">Reports</a></li>
                <li><a href="accounts.php">Accounts</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
            </ul>
        </li>

        <li class="dropdown active">
            <a href="#" class="active" onclick="toggleDropdown(event)">Recruitment ▾</a>
            <ul class="dropdown-content" style="display:block;">
                <li><a href="add_job.php">Add Job Opening</a></li>
                <li><a href="job_list.php" class="active">Job Openings</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Onboarding & Training ▾</a>
            <ul class="dropdown-content">
                <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                <li><a href="training_list.php">Trainings</a></li>
                <li><a href="add_training.php">Add Training</a></li>
            </ul>
        </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_performance.php">Add Evaluation</a></li>
                <li><a href="performance_list.php">Evaluation List</a></li>
            </ul>
        </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
    </ul>
</nav>

<div class="main-content">
    <div class="job-card">
        <h3>Edit Job</h3>
        <?php if ($message): ?>
            <p class="message <?= $messageClass ?>"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>

        <?php if ($job): ?>
        <form method="POST">
            <label>Job Title:</label>
            <input type="text" name="title" value="<?= htmlspecialchars($job['title']) ?>" required maxlength="100">

            <label>Department:</label>
            <input type="text" name="department" value="<?= htmlspecialchars($job['department']) ?>" required maxlength="100">

            <label>Description:</label>
            <textarea name="description"><?= htmlspecialchars($job['description']) ?></textarea>

            <label>Requirements:</label>
            <textarea name="requirements"><?= htmlspecialchars($job['requirements']) ?></textarea>

            <label>Status:</label>
            <select name="status">
                <option value="Open" <?= $job['status'] == 'Open' ? 'selected' : '' ?>>Open</option>
                <option value="Closed" <?= $job['status'] == 'Closed' ? 'selected' : '' ?>>Closed</option>
            </select>

            <button type="submit">Update Job</button>
        </form>
        <a href="job_list.php" class="back-btn">← Back to Job List</a>
        <?php endif; ?>
    </div>
</div>

<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.preventDefault();
    document.querySelectorAll('.sub-navbar .dropdown').forEach(drop => {
        if (!drop.contains(event.target)) drop.classList.remove('active');
    });
    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}
</script>
</body>
</html>