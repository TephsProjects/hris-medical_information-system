<?php
session_start();
include 'includes/db.php';

$today = date('Y-m-d');
$notifications = [];


/* 🎂 Birthdays Today */
$q = $conn->query("
    SELECT n.id AS notification_id, e.first_name, e.last_name, n.read_status
    FROM notifications n
    JOIN employees e ON n.emp_id = e.emp_id
    WHERE n.type = 'birthday' AND DATE_FORMAT(e.date_of_birth, '%m-%d') = DATE_FORMAT(CURDATE(), '%m-%d')
    ORDER BY n.created_at DESC
");
if (!$q) { die("Birthdays query failed: " . $conn->error); }

$notifications['🎂 Birthdays Today'] = [];
while ($r = $q->fetch_assoc()) {
    $notifications['🎂 Birthdays Today'][] = [
        'id' => $r['notification_id'],
        'text' => "<strong>{$r['first_name']} {$r['last_name']}</strong> has a birthday today 🎉",
        'read' => (bool)$r['read_status']
    ];
}

/* 🆕 Newly Hired (Last 7 days) */
$q = $conn->query("
    SELECT n.id AS notification_id, e.first_name, e.last_name, e.date_hired, n.read_status
    FROM notifications n
    JOIN employees e ON n.emp_id = e.emp_id
    WHERE n.type = 'new_hire'
    ORDER BY n.created_at DESC
");
if (!$q) { die("New Employees query failed: " . $conn->error); }

$notifications['🆕 New Employees'] = [];
while ($r = $q->fetch_assoc()) {
    $notifications['🆕 New Employees'][] = [
        'id' => $r['notification_id'],
        'text' => "<strong>{$r['first_name']} {$r['last_name']}</strong> was hired on {$r['date_hired']}",
        'read' => (bool)$r['read_status']
    ];
}

/* ⏰ Expired Contracts */
$q = $conn->query("
    SELECT n.id AS notification_id, e.first_name, e.last_name, e.contract_end_date, n.read_status
    FROM notifications n
    JOIN employees e ON n.emp_id = e.emp_id
    WHERE n.type = 'expired_contract'
    ORDER BY n.created_at DESC
");
if (!$q) { die("Expired Contracts query failed: " . $conn->error); }

$notifications['⏰ Expired Contracts'] = [];
while ($r = $q->fetch_assoc()) {
    $notifications['⏰ Expired Contracts'][] = [
        'id' => $r['notification_id'],
        'text' => "<strong>{$r['first_name']} {$r['last_name']}</strong> contract expired on {$r['contract_end_date']}",
        'read' => (bool)$r['read_status']
    ];
}

/* 📝 Leave Requests (Pending) */
$q = $conn->query("
    SELECT n.id AS notification_id, e.first_name, e.last_name, l.leave_type, n.read_status
    FROM notifications n
    JOIN leaves l ON n.emp_id = l.emp_id
    JOIN employees e ON l.emp_id = e.emp_id
    WHERE n.type = 'leave_pending'
    ORDER BY n.created_at DESC
");
if (!$q) { die("Pending Leaves query failed: " . $conn->error); }

$notifications['📝 Leave Requests'] = [];
while ($r = $q->fetch_assoc()) {
    $notifications['📝 Leave Requests'][] = [
        'id' => $r['notification_id'],
        'text' => "<strong>{$r['first_name']} {$r['last_name']}</strong> applied for {$r['leave_type']}",
        'read' => (bool)$r['read_status']
    ];
}

/* 🏥 Medical Notifications */
$q = $conn->query("
    SELECT id, type, message, read_status
    FROM notifications
    WHERE type LIKE 'medical_%'
    ORDER BY created_at DESC
");

$notifications['🏥 Medical'] = [];
while ($r = $q->fetch_assoc()) {

    // Decide redirect page based on type
    $target = 'medical_dashboard.php'; // default
    if ($r['type'] == 'medical_today' || $r['type'] == 'medical_upcoming') {
        $target = 'medical_schedule.php';
    } elseif ($r['type'] == 'medical_missing') {
        $target = 'medical_staff.php';
    }

    $notifications['🏥 Medical'][] = [
        'id' => $r['id'],
        'text' => $r['message'],
        'read' => (bool)$r['read_status'],
        'target_page' => $target
    ];
}

/* Output JSON */
header('Content-Type: application/json');
echo json_encode($notifications);
exit;
