<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$staff_id = $_GET['staff_id'] ?? 0;

// Fetch basic staff info
$staffSql = "SELECT * FROM medical_staff WHERE staff_id = ?";
$stmt = $conn->prepare($staffSql);
$stmt->bind_param("i", $staff_id);
$stmt->execute();
$staff = $stmt->get_result()->fetch_assoc();

// Fetch personal info
$infoSql = "SELECT * FROM medical_staff_info WHERE staff_id = ?";
$stmt2 = $conn->prepare($infoSql);
$stmt2->bind_param("i", $staff_id);
$stmt2->execute();
$info = $stmt2->get_result()->fetch_assoc();

// Fetch staff documents
$docSql = "SELECT * FROM medical_staff_documents WHERE staff_id = ?";
$stmt3 = $conn->prepare($docSql);
$stmt3->bind_param("i", $staff_id);
$stmt3->execute();
$documents = $stmt3->get_result()->fetch_all(MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Staff Info</title>
<link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/dashboard.css">
<link rel="stylesheet" href="assets/css/medical_staff_view.css">
</head>
<body>

<!-- TOP NAVBAR (reuse exactly) -->
<div class="navbar">
    <h2>PulseWork: Medical Information System</h2>
    <div class="user-info">
        <div class="notification-wrapper">
            <button id="notificationBtn" class="notification-btn">
                🔔
                <span class="notification-badge" id="notificationCount">0</span>
            </button>
        </div>

        <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<!-- MEDICAL SUB NAVBAR (simplified) -->
<nav class="sub-navbar">
    <ul class="nav-menu">
        <li><a href="medical_dashboard.php" class="active">Dashboard</a></li>
        <li><a href="medical_staff.php">Medical Staff</a></li>
        <li><a href="medical_schedule.php">Schedules</a></li>
        <li><a href="medical_reports.php">Reports</a></li>
    </ul>

    <div class="dashboard-switch">
        <a href="dashboard.php" class="switch-btn">
            👥 HR Dashboard
        </a>
    </div>
</nav>

<div class="main-content">
    <h2>👩‍⚕️ <?= htmlspecialchars($staff['full_name']); ?></h2>
    
    <div class="staff-info-grid">
        <!-- Basic Info Card -->
        <div class="info-card">
            <div class="info-header">
                <h3>Basic Info</h3>
                <button class="edit-btn" onclick="openEditModal('basic')">✏️ Edit</button>
            </div>
            <p><strong>Role:</strong> <span id="roleText"><?= htmlspecialchars($staff['role']); ?></span></p>
            <p><strong>Organization:</strong> <span id="orgText"><?= htmlspecialchars($staff['organization']); ?></span></p>
            <p><strong>Status:</strong> <span id="statusText"><?= htmlspecialchars($staff['status']); ?></span></p>
        </div>

        <!-- Personal Info Card -->
        <div class="info-card">
            <div class="info-header">
                <h3>Personal Info</h3>
                <button class="edit-btn" onclick="openEditModal('personal')">✏️ Edit</button>
            </div>
            <p><strong>Date of Birth:</strong> <span id="dobText"><?= htmlspecialchars($info['date_of_birth'] ?? '-'); ?></span></p>
            <p><strong>Contact Number:</strong> <span id="contactText"><?= htmlspecialchars($info['contact_number'] ?? '-'); ?></span></p>
            <p><strong>Email:</strong> <span id="emailText"><?= htmlspecialchars($info['email'] ?? '-'); ?></span></p>
            <p><strong>Address:</strong> <span id="addressText"><?= htmlspecialchars($info['address'] ?? '-'); ?></span></p>
            <p><strong>Emergency Contact:</strong> <span id="emergencyText"><?= htmlspecialchars($info['emergency_contact_name'] ?? '-') ?> (<?= htmlspecialchars($info['emergency_contact_number'] ?? '-') ?>)</span></p>
            <p><strong>Medical License:</strong> <span id="licenseText"><?= htmlspecialchars($info['medical_license'] ?? '-') ?></span></p>
            <p><strong>Qualifications:</strong> <span id="qualText"><?= htmlspecialchars($info['qualifications'] ?? '-') ?></span></p>
            <p><strong>Notes:</strong> <span id="notesText"><?= htmlspecialchars($info['notes'] ?? '-') ?></span></p>
        </div>

        <div class="info-card">
            <div class="info-header">
                <h3>Documents & Certifications</h3>
                <button class="edit-btn" onclick="openEditModal('documents')">✏️ Edit</button>
            </div>
            <?php if(!empty($documents)): ?>
                <ul class="doc-list">
                <?php foreach($documents as $doc): ?>
                    <li>
                        <strong><?= htmlspecialchars($doc['document_type']); ?>:</strong> 
                        <a href="<?= htmlspecialchars($doc['file_path']); ?>" target="_blank"><?= htmlspecialchars($doc['document_name']); ?></a>
                        <?php if($doc['expiry_date']): ?>
                            <span class="doc-expiry">(Expires: <?= htmlspecialchars($doc['expiry_date']); ?>)</span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No documents uploaded.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeEditModal()">&times;</span>
        <h3>Edit Staff Info</h3>
        <form id="editForm" class="enhanced-form">
            <input type="hidden" name="staff_id" value="<?= $staff_id ?>">

            <!-- Tabs -->
            <div class="modal-tabs">
                <div id="basicTab" class="modal-tab active" onclick="showTab('basic')">Basic Info</div>
                <div id="personalTab" class="modal-tab" onclick="showTab('personal')">Personal Info</div>
                <div id="documentsTab" class="modal-tab" onclick="showTab('documents')">Documents</div>
            </div>

            <!-- Basic Info Section -->
            <div class="form-section" id="basicSection">
                <div class="form-row">
                    <label for="roleInput">Role:</label>
                    <input type="text" name="role" id="roleInput" placeholder="Enter role">
                </div>
                <div class="form-row">
                    <label for="orgInput">Organization:</label>
                    <input type="text" name="organization" id="orgInput" placeholder="Enter organization">
                </div>
                <div class="form-row">
                    <label for="statusInput">Status:</label>
                    <select name="status" id="statusInput">
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>
            </div>

            <!-- Personal Info Section -->
            <div class="form-section" id="personalSection">
                <div class="form-row">
                    <label for="dobInput">Date of Birth:</label>
                    <input type="date" name="date_of_birth" id="dobInput">
                </div>
                <div class="form-row">
                    <label for="contactInput">Contact Number:</label>
                    <input type="text" name="contact_number" id="contactInput" placeholder="09xxxxxxxxx">
                </div>
                <div class="form-row">
                    <label for="emailInput">Email:</label>
                    <input type="email" name="email" id="emailInput" placeholder="example@email.com">
                </div>
                <div class="form-row">
                    <label for="addressInput">Address:</label>
                    <textarea name="address" id="addressInput" placeholder="Enter address"></textarea>
                </div>
                <div class="form-row">
                    <label for="emergencyNameInput">Emergency Contact Name:</label>
                    <input type="text" name="emergency_contact_name" id="emergencyNameInput" placeholder="Full name">
                </div>
                <div class="form-row">
                    <label for="emergencyNumberInput">Emergency Contact Number:</label>
                    <input type="text" name="emergency_contact_number" id="emergencyNumberInput" placeholder="09xxxxxxxxx">
                </div>
                <div class="form-row">
                    <label for="licenseInput">Medical License:</label>
                    <input type="text" name="medical_license" id="licenseInput" placeholder="License number">
                </div>
                <div class="form-row">
                    <label for="qualInput">Qualifications:</label>
                    <textarea name="qualifications" id="qualInput" placeholder="List qualifications"></textarea>
                </div>
                <div class="form-row">
                    <label for="notesInput">Notes:</label>
                    <textarea name="notes" id="notesInput" placeholder="Additional notes"></textarea>
                </div>
            </div>
            
            <!-- Documents Section -->
            <div class="form-section" id="documentsSection" style="display:none;">
                <h4>📄 Documents & Certifications</h4>

                <!-- Existing Documents -->
                <div id="existingDocs">
                    <?php if(!empty($documents)): ?>
                        <ul class="doc-list">
                        <?php foreach($documents as $doc): ?>
                            <li data-doc-id="<?= $doc['id']; ?>">
                                <strong><?= htmlspecialchars($doc['document_type']); ?>:</strong>
                                <a href="<?= htmlspecialchars($doc['file_path']); ?>" target="_blank"><?= htmlspecialchars($doc['document_name']); ?></a>
                                <?php if($doc['expiry_date']): ?>
                                    <span class="doc-expiry">(Expires: <?= htmlspecialchars($doc['expiry_date']); ?>)</span>
                                <?php endif; ?>
                                <button type="button" class="btn small-btn" onclick="removeDocument(this, <?= $doc['id']; ?>)">❌ Remove</button>
                            </li>
                        <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p>No documents uploaded.</p>
                    <?php endif; ?>
                </div>

                <!-- Add New Document -->
                <div class="form-row">
                    <label for="document_type">Document Type <span style="color:red;">*</span></label>
                    <input type="text" name="document_type" id="document_type" placeholder="e.g., Medical License, Certification">
                </div>
                <div class="form-row">
                    <label for="document_name">Document Name <span style="color:red;">*</span></label>
                    <input type="text" name="document_name" id="document_name" placeholder="Full document name">
                </div>
                <div class="form-row">
                    <label for="document_file">Upload File <span style="color:red;">*</span></label>
                    <input type="file" name="document_file" id="document_file" accept=".pdf,.jpg,.png">
                </div>
                <div class="form-row">
                    <label for="issued_date">Issued Date</label>
                    <input type="date" name="issued_date" id="issued_date">
                </div>
                <div class="form-row">
                    <label for="expiry_date">Expiry Date</label>
                    <input type="date" name="expiry_date" id="expiry_date">
                </div>
                <div class="form-row">
                    <button type="button" class="btn add-doc-btn" onclick="addDocument()">➕ Add Document</button>
                </div>
            </div>

            <!-- Buttons -->
            <div class="modal-buttons">
                <button type="button" class="btn cancel-btn" onclick="closeEditModal()">Cancel</button>
                <button type="submit" class="btn save-btn">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<!-- NOTIFICATION MODAL -->
<div id="notificationModal" class="modal">
    <div class="modal-content" style="max-width:600px; max-height:70vh; overflow-y:auto; padding:20px;">
        <span class="close" onclick="closeNotificationModal()">&times;</span>
        <h3>🔔 Notifications</h3>
        <div id="notificationContent">
            <p style="color:gray;">Loading notifications...</p>
        </div>
    </div>
</div>

<!-- LOGOUT MODAL -->
<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>
<script>
    // --- Tab Switching ---
function showTab(tab) {
    document.getElementById('basicSection').style.display = tab === 'basic' ? 'block' : 'none';
    document.getElementById('personalSection').style.display = tab === 'personal' ? 'block' : 'none';
    document.getElementById('documentsSection').style.display = tab === 'documents' ? 'block' : 'none';

    document.getElementById('basicTab').classList.toggle('active', tab === 'basic');
    document.getElementById('personalTab').classList.toggle('active', tab === 'personal');
    document.getElementById('documentsTab').classList.toggle('active', tab === 'documents');
}

// --- Open Modal & Populate ---
function openEditModal(section){
    document.getElementById('editModal').style.display = 'block';
    showTab(section);

    // Populate fields
    const fields = {
        role: 'roleText',
        organization: 'orgText',
        status: 'statusText',
        date_of_birth: 'dobText',
        contact_number: 'contactText',
        email: 'emailText',
        address: 'addressText',
        emergency_contact_name: 'emergencyText',
        emergency_contact_number: 'emergencyText',
        medical_license: 'licenseText',
        qualifications: 'qualText',
        notes: 'notesText'
    };

    document.getElementById('roleInput').value = document.getElementById(fields.role).textContent;
    document.getElementById('orgInput').value = document.getElementById(fields.organization).textContent;
    document.getElementById('statusInput').value = document.getElementById(fields.status).textContent;

    document.getElementById('dobInput').value = document.getElementById(fields.date_of_birth).textContent;
    document.getElementById('contactInput').value = document.getElementById(fields.contact_number).textContent;
    document.getElementById('emailInput').value = document.getElementById(fields.email).textContent;
    document.getElementById('addressInput').value = document.getElementById(fields.address).textContent;
    const emergencyText = document.getElementById(fields.emergency_contact_name).textContent.split('(');
    document.getElementById('emergencyNameInput').value = emergencyText[0].trim();
    document.getElementById('emergencyNumberInput').value = emergencyText[1]?.replace(')','') || '';
    document.getElementById('licenseInput').value = document.getElementById(fields.medical_license).textContent;
    document.getElementById('qualInput').value = document.getElementById(fields.qualifications).textContent;
    document.getElementById('notesInput').value = document.getElementById(fields.notes).textContent;
}

// --- Close Modal ---
function closeEditModal() { document.getElementById('editModal').style.display = 'none'; }

// --- AJAX Save with Highlight Changes ---
document.getElementById('editForm').addEventListener('submit', function(e){
    e.preventDefault();
    const formData = new FormData(this);
    
    fetch('update_staff_info.php', { method:'POST', body:formData })
        .then(res => res.json())
        .then(data => {
            if(data.success){
                alert('Changes saved successfully!');
                // Highlight changed fields
                for(const key in data.updated_fields){
                    const el = document.getElementById(key + 'Text');
                    if(el){
                        el.style.transition = 'background-color 0.4s';
                        el.style.backgroundColor = '#ffff99'; // highlight yellow
                        setTimeout(()=>{ el.style.backgroundColor = ''; }, 1200);
                        el.textContent = data.updated_fields[key]; // update text immediately
                    }
                }
                closeEditModal();
            } else {
                alert('Error: ' + data.message);
            }
        }).catch(()=>alert('Request failed'));
});

function addDocument() {
    const type = document.getElementById('document_type').value.trim();
    const name = document.getElementById('document_name').value.trim();
    const fileInput = document.getElementById('document_file');
    const issued = document.getElementById('issued_date').value;
    const expiry = document.getElementById('expiry_date').value;

    if(!type || !name || !fileInput.files.length){
        alert('Please fill in all required fields and select a file.');
        return;
    }

    const formData = new FormData();
    formData.append('staff_id', <?= $staff_id ?>);
    formData.append('document_type', type);
    formData.append('document_name', name);
    formData.append('document_file', fileInput.files[0]);
    formData.append('issued_date', issued);
    formData.append('expiry_date', expiry);

    fetch('add_staff_document.php', { method: 'POST', body: formData })
        .then(res => res.json())
        .then(data => {
            if(data.success){
                alert('Document added!');
                // Append to existing list dynamically
                const ul = document.querySelector('#existingDocs ul') || document.createElement('ul');
                if(!ul.parentNode) document.getElementById('existingDocs').innerHTML = ''; 
                const li = document.createElement('li');
                li.innerHTML = `<strong>${type}:</strong> <a href="${data.file_path}" target="_blank">${name}</a>
                    ${expiry ? `<span class="doc-expiry">(Expires: ${expiry})</span>` : ''}
                    <button type="button" class="btn small-btn" onclick="removeDocument(this, ${data.doc_id})">❌ Remove</button>`;
                ul.appendChild(li);
                document.getElementById('existingDocs').appendChild(ul);

                // Reset inputs
                document.getElementById('document_type').value = '';
                document.getElementById('document_name').value = '';
                document.getElementById('document_file').value = '';
                document.getElementById('issued_date').value = '';
                document.getElementById('expiry_date').value = '';
            } else {
                alert('Error: ' + data.message);
            }
        });
}

function removeDocument(button, docId){
    if(!confirm('Are you sure you want to remove this document?')) return;
    fetch('remove_staff_document.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({doc_id: docId})
    })
    .then(res => res.json())
    .then(data => {
        if(data.success){
            button.closest('li').remove();
        } else {
            alert('Error removing document.');
        }
    });
}

// Notifications and logout logic (same as before)
const notificationBtn = document.getElementById('notificationBtn');
const notificationModal = document.getElementById('notificationModal');
const notificationContent = document.getElementById('notificationContent');
const notificationCount = document.getElementById('notificationCount');

notificationBtn.onclick = function () {
    notificationModal.style.display = 'block';
    loadNotifications();
};

function loadNotifications() {
    fetch('fetch_notifications.php')
        .then(res => res.json())
        .then(data => {
            notificationContent.innerHTML = '';
            let total = 0;
            for (const section in data) {
                if (!data[section].length) continue;
                const title = document.createElement('div');
                title.className = 'notification-group-title';
                title.textContent = section;
                notificationContent.appendChild(title);
                data[section].forEach(item => {
                    total++;
                    const div = document.createElement('div');
                    div.className = 'notification-item';
                    div.innerHTML = item.text;
                    if (!item.read) {
                        div.classList.add('unread');
                        const dot = document.createElement('span');
                        dot.className = 'unread-dot';
                        div.appendChild(dot);
                    }
                    div.onclick = () => markAsRead(item.id, div);
                    notificationContent.appendChild(div);
                });
            }
            notificationCount.textContent = total || 0;
            if (total === 0) notificationContent.innerHTML = '<p style="color:gray;">No notifications today 🎉</p>';
        })
        .catch(() => notificationContent.innerHTML = '<p style="color:red;">Error loading notifications</p>');
}

// Mark notification as read AND redirect
function markAsReadAndRedirect(id, element, redirectPage) {
    fetch('mark_notification_read.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
    })
    .then(res => res.json())
    .then(resp => {
        if(resp.success){
            element.classList.remove('unread');
            const dot = element.querySelector('.unread-dot');
            if(dot) dot.remove();
            if(redirectPage) window.location.href = redirectPage;
        }
    });
}

// Make all modal close buttons work
document.querySelectorAll('.modal .close').forEach(btn => {
    btn.onclick = function() {
        this.closest('.modal').style.display = 'none';
    }
});

// Close modal when clicking outside
window.onclick = function(event) {
    document.querySelectorAll('.modal').forEach(modal => {
        if(event.target === modal) modal.style.display = 'none';
    });
};

// Logout modal logic
const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e){
    e.preventDefault();
    logoutModal.style.display = 'block';
}
cancelLogout.onclick = function(){ logoutModal.style.display = 'none'; }
confirmLogout.onclick = function(){ window.location.href = 'logout.php'; }
</script>
</body>
</html>
