<?php
session_start();
include 'includes/db.php';

if (!isset($_POST['emp_id'])) {
    header("Location: dashboard.php");
    exit();
}

$emp_id = $_POST['emp_id'];
$department_id = $_POST['department_id'] ?: null; // allow empty
$position_id = $_POST['position_id'] ?: null;

$stmt = $conn->prepare("UPDATE employees SET department_id = ?, position_id = ? WHERE emp_id = ?");
$stmt->bind_param("iii", $department_id, $position_id, $emp_id);

if ($stmt->execute()) {
    header("Location: employee_view.php?id=$emp_id&updated=1");
} else {
    echo "❌ Error updating department/position: " . $conn->error;
}
