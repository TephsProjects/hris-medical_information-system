<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$employees = $conn->query("SELECT emp_id, CONCAT(first_name, ' ', last_name) AS full_name FROM employees ORDER BY first_name ASC");

$where = "";
if (isset($_GET['emp_ids']) && !empty($_GET['emp_ids'])) {
    $emp_ids = array_map('intval', $_GET['emp_ids']);
    $where = "WHERE o.emp_id IN (" . implode(',', $emp_ids) . ")";
}

$sql = "
    SELECT o.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name
    FROM onboarding_tasks o
    LEFT JOIN employees e ON o.emp_id = e.emp_id
    $where
    ORDER BY o.due_date ASC
";
$tasks = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Onboarding Tasks</title>
<link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
<link rel="stylesheet" href="assets/css/style.css">
<style>
/* ---------- Filter Card ---------- */
.filter-card {
    background: #fff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    max-width: 400px;
    margin-bottom: 25px;
}

.filter-card h4 {
    margin-bottom: 15px;
    color: #007bff;
    font-weight: 600;
}

/* ---------- Employee Filter Search ---------- */
.employee-filter-container {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-bottom: 8px;
}

.employee-filter-container input {
    padding: 10px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

/* ---------- Employee Select List ---------- */
.employee-select-list {
    max-height: 150px;
    overflow-y: auto;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 6px;
    background: #fafafa;
}

.employee-select-list option {
    padding: 4px;
}

/* ---------- Filter Buttons ---------- */
.filter-buttons {
    margin-top: 15px;
    display: flex;
    gap: 10px;
}

.filter-buttons button, .filter-buttons .btn-clear {
    flex: 1;
    padding: 10px;
    border-radius: 8px;
    border: none;
    font-weight: 600;
    cursor: pointer;
}

.filter-buttons button {
    background-color: #007bff;
    color: #fff;
}

.filter-buttons button:hover {
    background-color: #0056b3;
}

.filter-buttons .btn-clear {
    text-align: center;
    background-color: #6c757d;
    color: #fff;
    text-decoration: none;
}

.filter-buttons .btn-clear:hover {
    background-color: #5a6268;
}

/* ---------- Onboarding Table ---------- */
.onboarding-table {
    width: 100%;
    border-collapse: collapse;
    overflow-x: auto;
}

.onboarding-table th, .onboarding-table td {
    padding: 12px 15px;
    border-bottom: 1px solid #e0e0e0;
    text-align: left;
}

.onboarding-table tr:hover {
    background-color: #f8f9fa;
}

.status-select {
    padding: 6px;
    border-radius: 6px;
    border: 1px solid #ccc;
}

/* ---------- Row Highlight Colors ---------- */
.done { background-color: #d4edda; }
.overdue { background-color: #f8d7da; }
.due-soon { background-color: #fff3cd; }

/* ---------- Message ---------- */
#msg {
    margin: 10px 0;
    padding: 12px;
    font-weight: bold;
    display: none;
    border-radius: 8px;
    text-align: center;
}

#msg.success { background-color: #d4edda; color: #155724; }
#msg.error { background-color: #f8d7da; color: #721c24; }

/* ---------- Responsive Table ---------- */
@media (max-width: 768px) {
    .onboarding-table, .onboarding-table thead, .onboarding-table tbody, .onboarding-table th, .onboarding-table td, .onboarding-table tr {
        display: block;
    }
    .onboarding-table th {
        display: none;
    }
    .onboarding-table td {
        position: relative;
        padding-left: 50%;
        margin-bottom: 10px;
    }
    .onboarding-table td::before {
        content: attr(data-label);
        position: absolute;
        left: 15px;
        font-weight: bold;
    }
}
</style>
</head>
<body>
<div class="navbar">
    <h2>PulseWork: HR Information System</h2>
    <div class="user-info">
        <span>Welcome, <?= $_SESSION['full_name']; ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<div class="sub-navbar">
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>
            
        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_leave.php">Leave Form</a></li>
                <li><a href="leave_requests.php">Leave Requests</a></li>
            </ul>
        </li>

        <!-- Payroll 
        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_payroll.php">Add Payroll</a></li>
                <li><a href="payroll.php">Payroll List</a></li>
                <li><a href="add_benefits.php">Add Benefits</a></li>
                <li><a href="benefits_list.php">Benefits List</a></li>
            </ul>
        </li> -->

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
            <ul class="dropdown-content">
                <li><a href="reports.php">Reports</a></li>
                <li><a href="accounts.php">Accounts</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_job.php">Add Job Opening</a></li>
                <li><a href="job_list.php">Job Openings</a></li>
                <li><a href="add_candidate.php">Add Candidate</a></li>
                <li><a href="candidate_list.php">Candidates</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" class="active" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
            <ul class="dropdown-content">
                <li><a href="onboarding_list.php" class="active">Onboarding Tasks</a></li>
                <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                <li><a href="training_list.php">Trainings</a></li>
                <li><a href="add_training.php">Add Training</a></li>
            </ul>
        </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_performance.php">Add Evaluation</a></li>
                <li><a href="performance_list.php">Evaluations</a></li>
            </ul>
        </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
    </ul>
</div>

<div class="main-content">
    <h3>Onboarding Tasks</h3>
    <div id="msg"></div>

    <!-- ---------- Filter Card ---------- -->
    <div class="filter-card">
        <h4>Filter by Employee</h4>
        <form method="GET" id="filterForm">
            <div class="employee-filter-container">
                <input type="text" id="employeeFilterSearch" placeholder="Search employee..." onkeyup="filterEmployeeOptions()">
                <select name="emp_ids[]" multiple class="employee-select-list">
                    <?php $employees->data_seek(0); ?>
                    <?php while ($emp = $employees->fetch_assoc()): ?>
                        <option value="<?= $emp['emp_id']; ?>" <?= (isset($emp_ids) && in_array($emp['emp_id'], $emp_ids)) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($emp['full_name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="filter-buttons">
                <button type="submit">Apply Filter</button>
                <a href="onboarding_list.php" class="btn-clear">Clear</a>
            </div>
        </form>
    </div>

    <!-- ---------- Onboarding Table ---------- -->
    <table class="onboarding-table">
        <thead>
            <tr>
                <th>Employee</th>
                <th>Task</th>
                <th>Due Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($task = $tasks->fetch_assoc()): 
                $due_date = $task['due_date'];
                $today = date('Y-m-d');
                $row_class = '';
                if ($task['status'] === 'Completed') $row_class = 'done';
                elseif ($due_date < $today) $row_class = 'overdue';
                elseif ($due_date === date('Y-m-d', strtotime('+1 day')) || $due_date === $today) $row_class = 'due-soon';
            ?>
            <tr class="<?= $row_class; ?>">
                <td data-label="Employee"><?= htmlspecialchars($task['employee_name']); ?></td>
                <td data-label="Task"><?= htmlspecialchars($task['task_name']); ?></td>
                <td data-label="Due Date"><?= htmlspecialchars($task['due_date']); ?></td>
                <td data-label="Status">
                    <select class="status-select" onchange="updateTaskStatus(<?= $task['task_id']; ?>, this.value)">
                        <option value="Pending" <?= $task['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="Completed" <?= $task['status'] === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                    </select>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<script>
function filterEmployeeOptions() {
    const input = document.getElementById('employeeFilterSearch').value.toLowerCase();
    const options = document.querySelectorAll('.employee-select-list option');
    options.forEach(opt => {
        opt.style.display = opt.text.toLowerCase().includes(input) ? '' : 'none';
    });
}

function toggleDropdown(e) {
    e.preventDefault();
    e.target.closest('.dropdown').classList.toggle('active');
}

function updateTaskStatus(taskId, newStatus) {
    fetch('update_task_status.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'task_id=' + taskId + '&status=' + encodeURIComponent(newStatus)
    })
    .then(r => r.text())
    .then(data => {
        const msg = document.getElementById('msg');
        msg.style.display = 'block';
        if (data === 'success') {
            msg.className = 'success';
            msg.textContent = 'Task status updated!';
            setTimeout(() => location.reload(), 800);
        } else {
            msg.className = 'error';
            msg.textContent = 'Error updating task status.';
        }
        setTimeout(() => msg.style.display = 'none', 2000);
    });
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}
</script>
</body>
</html>