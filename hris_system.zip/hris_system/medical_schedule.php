<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

include 'generate_medical_notifications.php';

// Fetch schedules
$schedules = $conn->query("
    SELECT ms.schedule_id, ms.duty_date, ms.start_time, ms.end_time, ms.remarks,
           m.staff_id, m.full_name, m.role
    FROM medical_schedules ms
    JOIN medical_staff m ON ms.staff_id = m.staff_id
    ORDER BY ms.duty_date ASC, ms.start_time ASC
");

// Fetch all medical staff for dropdown
$staffList = $conn->query("SELECT staff_id, full_name, role FROM medical_staff ORDER BY full_name ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Medical Schedules</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
</head>
<style>
    /* ===== MODAL BASE STYLE ===== */
.modal {
    display: none; /* Hidden by default */
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto; /* Enable scroll if needed */
    background-color: rgba(0,0,0,0.5); /* Dark overlay */
    transition: opacity 0.3s ease;
}

/* Modal content box */
.modal-content {
    background-color: #fff;
    margin: 5% auto; /* Center vertically */
    border-radius: 10px;
    padding: 20px;
    width: 90%;
    max-width: 500px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.3);
    animation: slideDown 0.4s ease;
    position: relative;
}

/* Slide down animation */
@keyframes slideDown {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

/* Close button */
.modal .close {
    position: absolute;
    top: 10px;
    right: 15px;
    font-size: 25px;
    font-weight: bold;
    color: #333;
    cursor: pointer;
    transition: color 0.2s ease;
}

.modal .close:hover {
    color: #e74c3c;
}

/* Modal header */
.modal-content h3 {
    margin-top: 0;
    margin-bottom: 15px;
    font-size: 1.3em;
    color: #222;
    text-align: center;
}

/* Inputs and select fields inside modal */
.modal-content input[type="text"],
.modal-content input[type="date"],
.modal-content input[type="time"],
.modal-content select {
    width: 100%;
    padding: 8px 10px;
    margin-bottom: 12px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 0.95em;
    transition: border 0.2s ease, box-shadow 0.2s ease;
}

.modal-content input:focus,
.modal-content select:focus {
    border-color: #378006;
    box-shadow: 0 0 5px rgba(55,128,6,0.3);
    outline: none;
}

/* Buttons inside modal */
.modal-content .btn {
    padding: 8px 15px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 0.95em;
    transition: background 0.2s ease, transform 0.1s ease;
}

.modal-content .btn:hover {
    transform: translateY(-1px);
    opacity: 0.9;
}

/* Confirm/Cancel buttons */
#confirmScheduleModal .btn {
    min-width: 80px;
    margin-top: 10px;
}

/* Responsive for small screens */
@media (max-width: 480px) {
    .modal-content {
        width: 95%;
        padding: 15px;
    }
    .modal-content h3 {
        font-size: 1.1em;
    }
    .modal-content input, .modal-content select {
        font-size: 0.9em;
    }
}
</style>
<body>

<!-- NAVBARS (same as before) -->
<div class="navbar">
    <h2>PulseWork: Medical Information System</h2>
    <div class="user-info">
        <div class="notification-wrapper">
            <button id="notificationBtn" class="notification-btn">
                🔔 <span class="notification-badge" id="notificationCount">0</span>
            </button>
        </div>
        <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<nav class="sub-navbar">
    <ul class="nav-menu">
        <li><a href="medical_dashboard.php">Dashboard</a></li>
        <li><a href="medical_staff.php">Medical Staff</a></li>
        <li><a href="medical_schedule.php" class="active">Schedules</a></li>
        <li><a href="medical_reports.php">Reports</a></li>
    </ul>
    <div class="dashboard-switch">
        <a href="dashboard.php" class="switch-btn">👥 HR Dashboard</a>
    </div>
</nav>

<div class="main-content">
    <h2>📅 Medical Duty Schedule</h2>

    <div style="margin-bottom:15px;">
        <button id="addScheduleBtn" class="btn" style="background:#378006;color:#fff;">➕ Add Schedule</button>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Staff</th>
                <th>Role</th>
                <th>Time</th>
                <th>Remarks</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if ($schedules && $schedules->num_rows > 0): ?>
            <?php while ($row = $schedules->fetch_assoc()): ?>
                <tr data-id="<?= $row['schedule_id'] ?>">
                    <td><?= $row['duty_date'] ?></td>
                    <td><?= htmlspecialchars($row['full_name']) ?></td>
                    <td><?= $row['role'] ?></td>
                    <td>
                        <?= date("h:i A", strtotime($row['start_time'])) ?> – <?= date("h:i A", strtotime($row['end_time'])) ?>
                    </td>
                    <td><?= $row['remarks'] ?: '-' ?></td>
                    <td>
                        <button class="edit-btn btn" style="background:#0066cc;color:#fff;">Edit</button>
                        <button class="delete-btn btn" style="background:#cc0000;color:#fff;">Delete</button>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="6" style="text-align:center;color:gray;">No schedules assigned</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- ADD / EDIT SCHEDULE MODAL -->
<div id="scheduleFormModal" class="modal">
    <div class="modal-content" style="max-width:500px;padding:20px;">
        <span class="close" onclick="closeScheduleFormModal()">&times;</span>
        <h3 id="scheduleFormTitle">Add Schedule</h3>
        <form id="scheduleForm">
            <input type="hidden" name="schedule_id" value="">
            
            <label>Staff:</label>
            <select name="staff_id" required style="width:100%;margin-bottom:10px;padding:5px;">
                <option value="">Select Staff</option>
                <?php while($staff = $staffList->fetch_assoc()): ?>
                    <option value="<?= $staff['staff_id'] ?>"><?= htmlspecialchars($staff['full_name'].' ('.$staff['role'].')') ?></option>
                <?php endwhile; ?>
            </select>

            <label>Duty Date:</label>
            <input type="date" name="duty_date" required style="width:100%;margin-bottom:10px;padding:5px;">

            <label>Start Time:</label>
            <div style="display:flex; gap:5px;">
                <input type="time" name="start_time" required style="flex:1; margin-bottom:10px; padding:5px;">
                <select name="start_ampm" style="padding:5px;">
                    <option value="AM">AM</option>
                    <option value="PM">PM</option>
                </select>
            </div>

            <label>End Time:</label>
            <div style="display:flex; gap:5px;">
                <input type="time" name="end_time" required style="flex:1; margin-bottom:10px; padding:5px;">
                <select name="end_ampm" style="padding:5px;">
                    <option value="AM">AM</option>
                    <option value="PM">PM</option>
                </select>
            </div>

            <label>Remarks:</label>
            <input type="text" name="remarks" style="width:100%;margin-bottom:10px;padding:5px;" placeholder="Optional">

            <button type="button" id="submitScheduleBtn" class="btn" style="background:#378006;color:#fff;">Submit</button>
        </form>
    </div>
</div>

<!-- CONFIRM MODAL -->
<div id="confirmScheduleModal" class="modal">
    <div class="modal-content" style="max-width:400px;padding:20px;text-align:center;">
        <span class="close" onclick="closeConfirmScheduleModal()">&times;</span>
        <h3>Confirm Action</h3>
        <p id="confirmScheduleText">Are you sure?</p>
        <button id="confirmScheduleBtn" class="btn" style="background:#378006;color:#fff;margin-right:10px;">Yes</button>
        <button id="cancelScheduleBtn" class="btn" style="background:#ccc;color:#333;">Cancel</button>
    </div>
</div>

<!-- NOTIFICATION & LOGOUT MODALS SAME AS BEFORE -->
<!-- ... reuse your notificationModal and logoutModal code ... -->

<script>
const addScheduleBtn = document.getElementById('addScheduleBtn');
const scheduleFormModal = document.getElementById('scheduleFormModal');
const scheduleFormTitle = document.getElementById('scheduleFormTitle');
const scheduleForm = document.getElementById('scheduleForm');
const submitScheduleBtn = document.getElementById('submitScheduleBtn');

const confirmScheduleModal = document.getElementById('confirmScheduleModal');
const confirmScheduleText = document.getElementById('confirmScheduleText');
const confirmScheduleBtn = document.getElementById('confirmScheduleBtn');
const cancelScheduleBtn = document.getElementById('cancelScheduleBtn');

let currentAction = 'add'; // add, edit, delete
let currentScheduleId = null;

// Open add modal
addScheduleBtn.onclick = () => {
    scheduleForm.reset();
    scheduleFormTitle.textContent = 'Add Schedule';
    currentAction = 'add';
    currentScheduleId = null;
    scheduleFormModal.style.display = 'block';
}

// Close modals
function closeScheduleFormModal() { scheduleFormModal.style.display = 'none'; }
function closeConfirmScheduleModal() { confirmScheduleModal.style.display = 'none'; }

// Submit form → show confirmation modal
submitScheduleBtn.onclick = () => {
    currentAction = scheduleForm.schedule_id.value ? 'edit' : 'add';
    currentScheduleId = scheduleForm.schedule_id.value || null;
    confirmScheduleText.textContent = currentAction === 'add' ? 'Add this schedule?' : 'Save changes to this schedule?';
    confirmScheduleModal.style.display = 'block';
}

// Confirm action
confirmScheduleBtn.onclick = () => {
    const formData = new FormData(scheduleForm);

    // Convert AM/PM to 24-hour format
    let startTime = scheduleForm.start_time.value;
    let startAMPM = scheduleForm.start_ampm.value;
    let endTime = scheduleForm.end_time.value;
    let endAMPM = scheduleForm.end_ampm.value;

    function to24Hour(time, ampm){
        let [h, m] = time.split(':').map(Number);
        if(ampm === 'PM' && h < 12) h += 12;
        if(ampm === 'AM' && h === 12) h = 0;
        return (h.toString().padStart(2,'0')) + ':' + m.toString().padStart(2,'0') + ':00';
    }

    formData.set('start_time', to24Hour(startTime, startAMPM));
    formData.set('end_time', to24Hour(endTime, endAMPM));

    formData.append('action', currentAction);
    if(currentAction === 'delete') formData.append('schedule_id', currentScheduleId);

    fetch('manage_medical_schedule.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success){
            alert('Schedule updated successfully!');
            location.reload();
        } else {
            alert('Error: ' + data.message);
        }
    });

    closeConfirmScheduleModal();
    closeScheduleFormModal();
}

// Cancel confirmation
cancelScheduleBtn.onclick = closeConfirmScheduleModal;

// Edit / Delete buttons in table
document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.onclick = function() {
        const tr = this.closest('tr');
        const cells = tr.children;
        scheduleFormTitle.textContent = 'Edit Schedule';
        scheduleForm.schedule_id.value = tr.dataset.id;
        scheduleForm.staff_id.value = tr.dataset.staff_id || '';
        scheduleForm.duty_date.value = cells[0].textContent;
        scheduleForm.start_time.value = cells[3].textContent.split(' – ')[0];
        scheduleForm.end_time.value = cells[3].textContent.split(' – ')[1];
        scheduleForm.remarks.value = cells[4].textContent === '-' ? '' : cells[4].textContent;
        currentAction = 'edit';
        currentScheduleId = tr.dataset.id;
        scheduleFormModal.style.display = 'block';
    }
});

document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.onclick = function() {
        const tr = this.closest('tr');
        currentScheduleId = tr.dataset.id;
        currentAction = 'delete';
        confirmScheduleText.textContent = 'Are you sure you want to delete this schedule?';
        confirmScheduleModal.style.display = 'block';
    }
});
</script>

</body>
</html>
