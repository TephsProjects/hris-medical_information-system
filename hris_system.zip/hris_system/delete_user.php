<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['id'])) {
    $user_id = intval($_GET['id']);

    // Use correct column name: id
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();

        // Redirect with success flag
        header("Location: accounts.php?deleted=1");
        exit();
    } else {
        // Debug-safe error
        die("Prepare failed: " . $conn->error);
    }
}

// Fallback redirect
header("Location: accounts.php");
exit();
