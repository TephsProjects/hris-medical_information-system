<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_FILES['import_file'])) {
    die("No file uploaded.");
}

$file = $_FILES['import_file']['tmp_name'];
$ext = strtolower(pathinfo($_FILES['import_file']['name'], PATHINFO_EXTENSION));

if ($ext !== 'csv') {
    die("Only CSV files are supported.");
}

if (($handle = fopen($file, "r")) === false) {
    die("Unable to open file.");
}

$columnMap = [
    'Employee No'        => 'employee_no',
    'First Name'         => 'first_name',
    'Last Name'          => 'last_name',
    'Address'            => 'address',
    'Age'                => 'age',
    'Civil Status'       => 'civil_status',
    'Date of Birth'      => 'date_of_birth',
    'Department'         => 'department',
    'Position'           => 'position',
    'Tax Status'         => 'tax_status',
    'TIN No.'            => 'tin_no',
    'SSS No.'            => 'sss_no',
    'PhilHealth No.'     => 'philhealth_no',
    'PagIBIG No.'        => 'pagibig_no',
    'Nationality'        => 'nationality',
    'Gender'             => 'gender',
    'Mobile Number'      => 'mobile_number',
    'Email'              => 'email',
    'Contact Person'     => 'contact_person',
    'Emergency Contact'  => 'emergency_contact',
    'Employment Status'  => 'employment_status',
    'Employment Type'    => 'employment_type',
    'Branch ID'          => 'branch_id',
    'Date Hired'         => 'date_hired',
    'Contract End Date'  => 'contract_end_date'
];

$requiredColumns = ['employee_no', 'first_name', 'last_name'];

$header = fgetcsv($handle);
if (!$header) die("CSV is empty or invalid.");

$indexes = [];
foreach ($header as $i => $colName) {
    if (isset($columnMap[$colName])) {
        $indexes[$i] = $columnMap[$colName];
    }
}

$missing = array_diff($requiredColumns, $indexes);
if (!empty($missing)) {
    die("Missing required column(s): " . implode(', ', $missing));
}

$columns = array_values($indexes);
$placeholders = implode(',', array_fill(0, count($columns), '?'));
$sql = "INSERT INTO employees (" . implode(',', $columns) . ") VALUES ($placeholders)";
$stmt = $conn->prepare($sql);

$dateColumns = ['date_of_birth', 'date_hired', 'contract_end_date'];

while (($row = fgetcsv($handle)) !== false) {

    if (empty(array_filter($row))) continue;

    $values = [];
    $types = '';

    foreach ($indexes as $csvIndex => $dbColumn) {
        $value = $row[$csvIndex] ?? null;

        if (in_array($dbColumn, $dateColumns) && !empty($value)) {

            if (is_numeric($value)) {
                $value = date('Y-m-d', strtotime('1899-12-30 +' . intval($value) . ' days'));
            } else {
                $formats = ['d/m/Y', 'd-m-Y', 'Y-m-d', 'm/d/Y'];
                $parsed = false;
                foreach ($formats as $format) {
                    $dt = DateTime::createFromFormat($format, $value);
                    if ($dt !== false && $dt->format($format) === $value) {
                        $value = $dt->format('Y-m-d');
                        $parsed = true;
                        break;
                    }
                }

                if (!$parsed) {
                    $timestamp = strtotime($value);
                    $value = $timestamp !== false ? date('Y-m-d', $timestamp) : null;
                }
            }
        }

        $values[] = $value;
        $types .= 's'; 
    }

    $stmt->bind_param($types, ...$values);
    $stmt->execute();
}

fclose($handle);

header("Location: dashboard.php?import=success");
exit();
