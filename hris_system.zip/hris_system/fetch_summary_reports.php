<?php
// fetch_summary_report.php
header('Content-Type: application/json');
include('includes/db.php');

$staff_id   = isset($_GET['staff_id']) && $_GET['staff_id'] !== '' ? intval($_GET['staff_id']) : null;
$start_date = $_GET['start_date'] ?? null;
$end_date   = $_GET['end_date'] ?? null;

if (!$start_date || !$end_date) {
    echo json_encode(['error' => 'Start and end dates are required']);
    exit;
}

// Build staff filter
$staffFilter = $staff_id ? " AND m.staff_id = $staff_id " : "";

// 1️⃣ Staff summary
$summarySql = "
SELECT 
    m.staff_id,
    m.full_name,
    COUNT(ms.schedule_id) AS total_duties,
    IFNULL(SUM(TIMESTAMPDIFF(MINUTE, ms.start_time, ms.end_time))/60,0) AS total_hours,
    IFNULL(MAX(ms.duty_date),'-') AS last_duty
FROM medical_staff m
LEFT JOIN medical_schedules ms 
    ON m.staff_id = ms.staff_id 
    AND ms.duty_date BETWEEN ? AND ?
WHERE 1=1 $staffFilter
GROUP BY m.staff_id
ORDER BY m.full_name ASC
";

$stmt = $conn->prepare($summarySql);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$res = $stmt->get_result();
$staff_summary = [];
while($row = $res->fetch_assoc()){
    $row['total_hours'] = round($row['total_hours'], 2); // Round hours
    $staff_summary[] = $row;
}

// 2️⃣ Daily aggregation
$dailySql = "
SELECT 
    ms.duty_date AS date,
    COUNT(ms.schedule_id) AS duties,
    IFNULL(SUM(TIMESTAMPDIFF(MINUTE, ms.start_time, ms.end_time))/60,0) AS hours
FROM medical_schedules ms
WHERE ms.duty_date BETWEEN ? AND ?
" . ($staff_id ? " AND ms.staff_id = $staff_id " : "") . "
GROUP BY ms.duty_date
ORDER BY ms.duty_date ASC
";
$stmt = $conn->prepare($dailySql);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$res = $stmt->get_result();
$daily = [];
while($row = $res->fetch_assoc()){
    $row['hours'] = round($row['hours'],2);
    $daily[] = $row;
}

// 3️⃣ Weekly aggregation (ISO week)
$weeklySql = "
SELECT 
    YEAR(ms.duty_date) AS year,
    WEEK(ms.duty_date,1) AS week,
    COUNT(ms.schedule_id) AS duties,
    IFNULL(SUM(TIMESTAMPDIFF(MINUTE, ms.start_time, ms.end_time))/60,0) AS hours
FROM medical_schedules ms
WHERE ms.duty_date BETWEEN ? AND ?
" . ($staff_id ? " AND ms.staff_id = $staff_id " : "") . "
GROUP BY YEAR(ms.duty_date), WEEK(ms.duty_date,1)
ORDER BY YEAR(ms.duty_date), WEEK(ms.duty_date,1)
";
$stmt = $conn->prepare($weeklySql);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$res = $stmt->get_result();
$weekly = [];
while($row = $res->fetch_assoc()){
    $row['hours'] = round($row['hours'],2);
    $row['week'] = $row['year'].'-W'.$row['week'];
    $weekly[] = $row;
}

// 4️⃣ Monthly aggregation
$monthlySql = "
SELECT 
    DATE_FORMAT(ms.duty_date,'%Y-%m') AS month,
    COUNT(ms.schedule_id) AS duties,
    IFNULL(SUM(TIMESTAMPDIFF(MINUTE, ms.start_time, ms.end_time))/60,0) AS hours
FROM medical_schedules ms
WHERE ms.duty_date BETWEEN ? AND ?
" . ($staff_id ? " AND ms.staff_id = $staff_id " : "") . "
GROUP BY DATE_FORMAT(ms.duty_date,'%Y-%m')
ORDER BY DATE_FORMAT(ms.duty_date,'%Y-%m')
";
$stmt = $conn->prepare($monthlySql);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$res = $stmt->get_result();
$monthly = [];
while($row = $res->fetch_assoc()){
    $row['hours'] = round($row['hours'],2);
    $monthly[] = $row;
}

// Output JSON
echo json_encode([
    'staff_summary' => $staff_summary,
    'daily'         => $daily,
    'weekly'        => $weekly,
    'monthly'       => $monthly
]);
