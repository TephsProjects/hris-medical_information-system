<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) exit('Not authorized');

// ==============================
// GET FILTERS
// ==============================
$from_date    = $_GET['from_date'] ?? '';
$to_date      = $_GET['to_date'] ?? '';
$role         = $_GET['role'] ?? '';
$organization = $_GET['organization'] ?? '';
$status       = $_GET['status'] ?? '';

// ==============================
// BUILD FILTER CONDITIONS
// ==============================
$whereStaff = [];
$whereSchedule = [];
$params = [];
$types = "";

if ($role) {
    $whereStaff[] = "ms.role = ?";
    $params[] = $role;
    $types .= "s";
}

if ($organization) {
    $whereStaff[] = "ms.organization = ?";
    $params[] = $organization;
    $types .= "s";
}

if ($status) {
    $whereStaff[] = "ms.status = ?";
    $params[] = $status;
    $types .= "s";
}

if ($from_date) {
    $whereSchedule[] = "sch.duty_date >= ?";
    $params[] = $from_date;
    $types .= "s";
}

if ($to_date) {
    $whereSchedule[] = "sch.duty_date <= ?";
    $params[] = $to_date;
    $types .= "s";
}

$whereStaffSql    = $whereStaff ? "WHERE " . implode(" AND ", $whereStaff) : "";
$whereScheduleSql = $whereSchedule ? implode(" AND ", $whereSchedule) : "";

// ==============================
// PREPARE CSV
// ==============================
$filename = 'Medical_Reports_' . date('Ymd_His') . '.csv';
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$out = fopen('php://output', 'w');

// ==============================
// SUMMARY
// ==============================
fputcsv($out, ['Medical Reports Summary']);
fputcsv($out, []);

// Filters info
fputcsv($out, ['Filters Applied']);
fputcsv($out, ['From Date', $from_date ?: 'All']);
fputcsv($out, ['To Date', $to_date ?: 'All']);
fputcsv($out, ['Role', $role ?: 'All']);
fputcsv($out, ['Organization', $organization ?: 'All']);
fputcsv($out, ['Status', $status ?: 'All']);
fputcsv($out, []);

// Totals
function fetchSingleValue($conn, $sql, $types, $params) {
    $stmt = $conn->prepare($sql);
    if ($types) $stmt->bind_param($types, ...$params);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc()['total'] ?? 0;
}

// Total staff
$totalStaff = fetchSingleValue($conn, "SELECT COUNT(*) total FROM medical_staff ms $whereStaffSql", $types, $params);

// Total schedules
$totalSchedules = fetchSingleValue($conn, "
    SELECT COUNT(*) total
    FROM medical_schedules sch
    JOIN medical_staff ms ON sch.staff_id = ms.staff_id
    $whereStaffSql
    " . ($whereScheduleSql ? "AND $whereScheduleSql" : ""), $types, $params);

// Active staff
$activeStaff = fetchSingleValue($conn, "
    SELECT COUNT(*) total
    FROM medical_staff ms
    " . ($whereStaff ? $whereStaffSql . " AND ms.status='Active'" : "WHERE ms.status='Active'"), $types, $params);

// Expired documents
$expiredDocs = fetchSingleValue($conn, "
    SELECT COUNT(*) total
    FROM medical_staff_documents d
    JOIN medical_staff ms ON d.staff_id = ms.staff_id
    " . ($whereStaff ? "WHERE d.status='Expired' AND " . implode(" AND ", $whereStaff) : "WHERE d.status='Expired'"), $types, $params);

fputcsv($out, ['Total Medical Staff', $totalStaff]);
fputcsv($out, ['Total Schedules', $totalSchedules]);
fputcsv($out, ['Active Staff', $activeStaff]);
fputcsv($out, ['Expired Documents', $expiredDocs]);
fputcsv($out, []);

// ==============================
// STAFF BY ROLE
// ==============================
fputcsv($out, ['Staff by Role']);
fputcsv($out, ['Role', 'Total']);

$sql = "SELECT ms.role, COUNT(*) total FROM medical_staff ms $whereStaffSql GROUP BY ms.role";
$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) {
    fputcsv($out, [$r['role'], $r['total']]);
}
fputcsv($out, []);

// ==============================
// STAFF BY ORGANIZATION
// ==============================
fputcsv($out, ['Staff by Organization']);
fputcsv($out, ['Organization', 'Total']);
$sql = "SELECT ms.organization, COUNT(*) total FROM medical_staff ms $whereStaffSql GROUP BY ms.organization";
$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) {
    fputcsv($out, [$r['organization'], $r['total']]);
}
fputcsv($out, []);

// ==============================
// STAFF BY STATUS
// ==============================
fputcsv($out, ['Staff by Status']);
fputcsv($out, ['Status', 'Total']);
$sql = "SELECT ms.status, COUNT(*) total FROM medical_staff ms $whereStaffSql GROUP BY ms.status";
$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) {
    fputcsv($out, [$r['status'], $r['total']]);
}
fputcsv($out, []);

// ==============================
// SCHEDULES PER DAY
// ==============================
fputcsv($out, ['Schedules per Day']);
fputcsv($out, ['Date', 'Total']);
$sql = "
    SELECT sch.duty_date, COUNT(*) total
    FROM medical_schedules sch
    JOIN medical_staff ms ON sch.staff_id = ms.staff_id
    $whereStaffSql
    " . ($whereScheduleSql ? "AND $whereScheduleSql" : "") . "
    GROUP BY sch.duty_date
    ORDER BY sch.duty_date
";
$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) {
    fputcsv($out, [$r['duty_date'], $r['total']]);
}
fputcsv($out, []);

// ==============================
// STAFF SCHEDULE SUMMARY
// ==============================
fputcsv($out, ['Staff Schedule Summary']);
fputcsv($out, ['Name', 'Role', 'Total Schedules']);
$sql = "
    SELECT ms.full_name, ms.role, COUNT(sch.schedule_id) total
    FROM medical_staff ms
    LEFT JOIN medical_schedules sch ON ms.staff_id = sch.staff_id
    $whereStaffSql
    GROUP BY ms.staff_id
    ORDER BY total DESC
";
$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) {
    fputcsv($out, [$r['full_name'], $r['role'], $r['total']]);
}
fputcsv($out, []);

// ==============================
// STAFF WITHOUT SCHEDULES
// ==============================
fputcsv($out, ['Staff Without Schedules']);
fputcsv($out, ['Name', 'Role', 'Organization']);
$sql = "
    SELECT ms.full_name, ms.role, ms.organization
    FROM medical_staff ms
    LEFT JOIN medical_schedules sch ON ms.staff_id = sch.staff_id
    $whereStaffSql
    AND sch.schedule_id IS NULL
";
$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) {
    fputcsv($out, [$r['full_name'], $r['role'], $r['organization']]);
}

fclose($out);
exit;
?>
