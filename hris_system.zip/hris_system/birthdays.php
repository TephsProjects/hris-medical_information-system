<?php
header('Content-Type: application/json');
include('includes/db.php'); // your DB connection

// Get year from query string, default to current year
$year = $_GET['year'] ?? date('Y');

// Query employees with a date of birth
$sql = "
    SELECT 
        CONCAT(first_name, ' ', last_name) AS name,
        date_of_birth
    FROM employees
    WHERE date_of_birth IS NOT NULL
";

$result = $conn->query($sql);
$events = [];

while ($row = $result->fetch_assoc()) {
    $dob = date('m-d', strtotime($row['date_of_birth']));
    $events[] = [
        'title' => "🎂 " . $row['name'] . "'s Birthday",
        'start' => "$year-$dob",   // make it full YYYY-MM-DD
        'allDay' => true,
        'color' => '#38bdf8'
    ];
}

// Output JSON
echo json_encode($events, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
