<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$report_type = isset($_GET['report_type']) ? $_GET['report_type'] : 'overview';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

$conditions = [];
$params = [];
$types = "";

// Join tables to get proper names
$joins = "
    LEFT JOIN departments d ON e.department_id = d.department_id
    LEFT JOIN positions p ON e.position_id = p.position_id
    LEFT JOIN branches b ON e.branch_id = b.branch_id
";

// Date filter
if (!empty($date_from) && !empty($date_to)) {
    $conditions[] = "e.date_hired BETWEEN ? AND ?";
    $types .= "ss";
    $params[] = $date_from;
    $params[] = $date_to;
}

// Employment status filter
if (!empty($_GET['employment_status'])) {
    $conditions[] = "e.employment_status = ?";
    $types .= "s";
    $params[] = $_GET['employment_status'];
}

// Department filter
if (!empty($_GET['department_id'])) {
    $conditions[] = "e.department_id = ?";
    $types .= "i";
    $params[] = $_GET['department_id'];
}

// Position filter
if (!empty($_GET['position_id'])) {
    $conditions[] = "e.position_id = ?";
    $types .= "i";
    $params[] = $_GET['position_id'];
}

// Branch filter
if (!empty($_GET['branch_id'])) {
    $conditions[] = "e.branch_id = ?";
    $types .= "i";
    $params[] = $_GET['branch_id'];
}

$where_clause = $conditions ? "WHERE " . implode(" AND ", $conditions) : "";

switch ($report_type) {
    case 'department':
        $sql = "SELECT d.department_name AS label, COUNT(*) AS total
                FROM employees e
                $joins
                $where_clause
                GROUP BY d.department_id
                ORDER BY total DESC";
        break;

    case 'position':
        $sql = "SELECT p.position_name AS label, COUNT(*) AS total
                FROM employees e
                $joins
                $where_clause
                GROUP BY p.position_id
                ORDER BY total DESC";
        break;

    case 'branch':
        $sql = "SELECT b.branch_name AS label, COUNT(*) AS total
                FROM employees e
                $joins
                $where_clause
                GROUP BY b.branch_id
                ORDER BY total DESC";
        break;

    case 'gender':
        $sql = "SELECT e.gender AS label, COUNT(*) AS total
                FROM employees e
                $joins
                $where_clause
                GROUP BY e.gender";
        break;

    case 'civil_status':
        $sql = "SELECT e.civil_status AS label, COUNT(*) AS total
                FROM employees e
                $joins
                $where_clause
                GROUP BY e.civil_status";
        break;

    default: // overview
        $sql = "SELECT COUNT(*) AS total_employees
                FROM employees e
                $joins
                $where_clause";
        break;
}

$stmt = $conn->prepare($sql);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$empSql = "
SELECT e.emp_id, e.employee_no, e.first_name, e.last_name,
       d.department_name AS department,
       p.position_name AS position,
       b.branch_name AS branch,
       e.employment_status, e.date_hired
FROM employees e
$joins
$where_clause
ORDER BY e.last_name ASC
";

$empStmt = $conn->prepare($empSql);
if (!empty($params)) $empStmt->bind_param($types, ...$params);
$empStmt->execute();
$empResult = $empStmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reports</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/reports.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="navbar">
        <h2>PulseWork: HR Information System</h2>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
            <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
        </div>
    </div>

    <div class="sub-navbar">
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>
            
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_leave.php">Leave Form</a></li>
                    <li><a href="leave_requests.php">Leave Requests</a></li>
                </ul>
            </li>

            <!-- <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_payroll.php">Add Payroll</a></li>
                    <li><a href="payroll.php">Payroll List</a></li>
                    <li><a href="add_benefits.php">Add Benefits</a></li>
                    <li><a href="benefits_list.php">Benefits List</a></li>
                </ul>
            </li> -->

            <li class="dropdown">
                <a href="#" class="active" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
                <ul class="dropdown-content">
                    <li><a href="reports.php" class="active">Reports</a></li>
                    <li><a href="accounts.php">Accounts</a></li>
                    <li><a href="add_employee.php">Add Employee</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_job.php">Add Job Opening</a></li>
                    <li><a href="job_list.php">Job Openings</a></li>
                    <li><a href="add_candidate.php">Add Candidate</a></li>
                    <li><a href="candidate_list.php">Candidates</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
                <ul class="dropdown-content">
                    <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                    <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                    <li><a href="training_list.php">Trainings</a></li>
                    <li><a href="add_training.php">Add Training</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_performance.php">Add Evaluation</a></li>
                    <li><a href="performance_list.php">Evaluations</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
        </ul>
    </div>

    <div class="main-content">
        <h3>HR Reports</h3>

        <form method="GET" class="filter-form">
            <label for="report_type"><strong>Report Type:</strong></label>
            <select name="report_type" id="report_type">
                <option value="overview" <?= $report_type == 'overview' ? 'selected' : '' ?>>Employee Overview</option>
                <option value="department" <?= $report_type == 'department' ? 'selected' : '' ?>>By Department</option>
                <option value="gender" <?= $report_type == 'gender' ? 'selected' : '' ?>>By Gender</option>
                <option value="civil_status" <?= $report_type == 'civil_status' ? 'selected' : '' ?>>By Civil Status</option>
            </select>

            <label><strong>Status:</strong></label>
            <select name="employment_status">
                <option value="">All</option>
                <?php
                $statuses = ['Active','Probationary','Resigned','Terminated','AWOL','End of Contract'];
                foreach ($statuses as $st):
                ?>
                    <option value="<?= $st ?>" <?= ($_GET['employment_status'] ?? '') == $st ? 'selected' : '' ?>>
                        <?= $st ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label><strong>Department:</strong></label>
            <select name="department_id">
                <option value="">All</option>
                <?php
                $deptQ = $conn->query("SELECT * FROM departments ORDER BY department_name ASC");
                while ($d = $deptQ->fetch_assoc()):
                ?>
                    <option value="<?= $d['department_id'] ?>"
                        <?= ($_GET['department_id'] ?? '') == $d['department_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($d['department_name']) ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label><strong>Position:</strong></label>
            <select name="position_id">
                <option value="">All</option>
                <?php
                $posQ = $conn->query("SELECT * FROM positions ORDER BY position_name ASC");
                while ($p = $posQ->fetch_assoc()):
                ?>
                    <option value="<?= $p['position_id'] ?>"
                        <?= ($_GET['position_id'] ?? '') == $p['position_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($p['position_name']) ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label><strong>Branch:</strong></label>
            <select name="branch_id">
                <option value="">All</option>
                <?php
                $branchQ = $conn->query("SELECT * FROM branches ORDER BY branch_name ASC");
                while ($b = $branchQ->fetch_assoc()):
                ?>
                    <option value="<?= $b['branch_id'] ?>"
                        <?= ($_GET['branch_id'] ?? '') == $b['branch_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($b['branch_name']) ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label><strong>From:</strong></label>
            <input type="date" name="date_from" value="<?= htmlspecialchars($date_from) ?>">

            <label><strong>To:</strong></label>
            <input type="date" name="date_to" value="<?= htmlspecialchars($date_to) ?>">

            <button type="submit" class="btn apply-btn">Apply</button>
            <a href="reports.php" class="btn reset-btn">Reset</a>
        </form>

        <div class="report-container">
            <?php if ($report_type == 'overview'): ?>
                <?php $row = $result->fetch_assoc(); ?>
                <div class="report-card" style="text-align:center;">
                    <h4>Total Employees</h4>
                    <p style="font-size:2rem; color:#007bff;"><?php echo htmlspecialchars($row['total_employees']); ?></p>
                </div>
            <?php else: ?>
                <table id="reportTable">
                    <thead>
                        <tr>
                            <th><?php echo ucfirst(str_replace('_', ' ', $report_type)); ?></th>
                            <th>Total Employees</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $labels = [];
                        $values = [];
                        while ($row = $result->fetch_assoc()):
                            $labels[] = $row['label'];
                            $values[] = $row['total'];
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['label']); ?></td>
                            <td><?php echo htmlspecialchars($row['total']); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <div class="chart-container">
                    <canvas id="reportChart"></canvas>
                </div>

                <h4 style="margin-top:30px;">Employee List</h4>

                <table class="report-table">
                    <thead>
                        <tr>
                            <th>Employee No</th>
                            <th>Name</th>
                            <th>Department</th>
                            <th>Position</th>
                            <th>Status</th>
                            <th>Date Hired</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($emp = $empResult->fetch_assoc()): ?>
                        <tr onclick="window.location='employee_view.php?id=<?= $emp['emp_id'] ?>'"
                            style="cursor:pointer;">
                            <td><?= htmlspecialchars($emp['employee_no']) ?></td>
                            <td><?= htmlspecialchars($emp['first_name'].' '.$emp['last_name']) ?></td>
                            <td><?= htmlspecialchars($emp['department']) ?></td>
                            <td><?= htmlspecialchars($emp['position']) ?></td>
                            <td><?= htmlspecialchars($emp['employment_status']) ?></td>
                            <td><?= htmlspecialchars($emp['date_hired']) ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <div class="export-btns">
                    <button type="button" onclick="exportToExcel()">Export to Excel</button>
                    <button type="button" onclick="exportToPDF()">Export to PDF</button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div id="logoutModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Confirm Logout</h3>
            <p>Are you sure you want to logout?</p>
            <div class="modal-buttons">
                <button id="confirmLogout" class="btn">Yes, Logout</button>
                <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
            </div>
        </div>
    </div>

    <script>
        <?php if ($report_type != 'overview'): ?>
        const labels = <?php echo json_encode($labels); ?>;
        const data = <?php echo json_encode($values); ?>;

        const ctx = document.getElementById('reportChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Total Employees',
                    data: data,
                    backgroundColor: 'rgba(0, 123, 255, 0.6)',
                    borderColor: '#007bff',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
        <?php endif; ?>

        function exportToExcel() {
            const table = document.getElementById("reportTable").outerHTML;
            const blob = new Blob([table], { type: "application/vnd.ms-excel" });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "HR_Report.xls";
            link.click();
        }

        function exportToPDF() {
            const printWindow = window.open('', '', 'height=700,width=900');
            printWindow.document.write('<html><head><title>HR Report</title></head><body>');
            printWindow.document.write('<h3>HR Report - <?php echo ucfirst($report_type); ?></h3>');
            printWindow.document.write(document.getElementById("reportTable").outerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        }

        function toggleDropdown(event) {
            event.preventDefault();
            document.querySelectorAll('.dropdown').forEach(drop => {
                if (!drop.contains(event.target)) drop.classList.remove('active');
            });
            const parent = event.target.closest('.dropdown');
            parent.classList.toggle('active');
        }

        const logoutBtn = document.getElementById('logoutBtn');
        const logoutModal = document.getElementById('logoutModal');
        const closeModal = document.querySelector('.close');
        const cancelLogout = document.getElementById('cancelLogout');
        const confirmLogout = document.getElementById('confirmLogout');

        logoutBtn.onclick = function(e) {
            e.preventDefault();
            logoutModal.style.display = 'block';
        }

        closeModal.onclick = function() {
            logoutModal.style.display = 'none';
        }

        cancelLogout.onclick = function() {
            logoutModal.style.display = 'none';
        }

        confirmLogout.onclick = function() {
            window.location.href = 'logout.php';
        }

        window.onclick = function(event) {
            if (event.target == logoutModal) {
                logoutModal.style.display = 'none';
            }
        }
    </script>
</body>
</html>