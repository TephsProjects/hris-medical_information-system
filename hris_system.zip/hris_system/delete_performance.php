<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: performance_list.php");
    exit();
}

$perf_id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM performance WHERE perf_id = ?");
$stmt->bind_param("i", $perf_id);

if ($stmt->execute()) {
    $_SESSION['message'] = "✅ Performance evaluation deleted successfully!";
} else {
    $_SESSION['message'] = "❌ Failed to delete evaluation: " . $conn->error;
}

header("Location: performance_list.php");
exit();
