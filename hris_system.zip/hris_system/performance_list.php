<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$query = "
    SELECT p.perf_id, p.evaluation_period, p.evaluator, p.rating, 
           e.emp_id, e.employee_no, e.first_name, e.last_name
    FROM performance p
    JOIN employees e ON p.emp_id = e.emp_id
    ORDER BY p.created_at DESC
";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Performance Evaluations</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="navbar">
        <h2>PulseWork: HR Information System</h2>
        <div class="user-info">
            <span>Welcome, <?php echo $_SESSION['full_name']; ?></span>
            <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
        </div>
    </div>

    <div class="sub-navbar">
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>
            
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_leave.php">Leave Form</a></li>
                    <li><a href="leave_requests.php">Leave Request Lists</a></li>
                </ul>
            </li>

            <!-- <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_payroll.php">Add Payroll</a></li>
                    <li><a href="payroll.php">Payroll List</a></li>
                    <li><a href="add_benefits.php">Add Benefits</a></li>
                    <li><a href="benefits_list.php">Benefits List</a></li>
                </ul>
            </li> -->

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
                <ul class="dropdown-content">
                    <li><a href="reports.php">Reports</a></li>
                    <li><a href="accounts.php">Accounts</a></li>
                    <li><a href="add_employee.php">Add Employee</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_job.php">Add Job Opening</a></li>
                    <li><a href="job_list.php">Job Openings</a></li>
                    <li><a href="add_candidate.php">Add Candidate</a></li>
                    <li><a href="candidate_list.php">Candidates</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
                <ul class="dropdown-content">
                    <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                    <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                    <li><a href="training_list.php">Trainings</a></li>
                    <li><a href="add_training.php">Add Training</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" class="active" onclick="toggleDropdown(event)">Performance ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_performance.php">Add Evaluation</a></li>
                    <li><a href="performance_list.php" class="active">Evaluation List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
        </ul>
    </div>

    <div class="main-content">
        <h3>Performance Evaluations</h3>

        <table>
            <thead>
                <tr>
                    <th>Employee No.</th>
                    <th>Employee Name</th>
                    <th>Evaluation Period</th>
                    <th>Evaluator</th>
                    <th>Rating</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['employee_no']); ?></td>
                            <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['evaluation_period']); ?></td>
                            <td><?php echo htmlspecialchars($row['evaluator']); ?></td>
                            <td><?php echo htmlspecialchars($row['rating']); ?></td>
                            <td class="actions">
                                <a href="view_performance.php?id=<?php echo $row['perf_id']; ?>" class="btn action-view" title="View Evaluation">👁️ View</a>
                                <a href="edit_performance.php?id=<?php echo $row['perf_id']; ?>" class="btn action-edit" title="Edit Evaluation">✏️ Edit</a>
                                <a href="delete_performance.php?id=<?php echo $row['perf_id']; ?>" class="btn action-delete" title="Delete Evaluation" onclick="return confirm('Are you sure you want to delete this evaluation?');">🗑️ Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No evaluations found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div id="logoutModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Confirm Logout</h3>
            <p>Are you sure you want to logout?</p>
            <div class="modal-buttons">
                <button id="confirmLogout" class="btn">Yes, Logout</button>
                <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
            </div>
        </div>
    </div>

    <script>
    function toggleDropdown(event) {
        event.preventDefault();
        const parent = event.target.closest('.dropdown');
        parent.classList.toggle('active');
    }

    const logoutBtn = document.getElementById('logoutBtn');
    const logoutModal = document.getElementById('logoutModal');
    const closeModal = document.querySelector('.close');
    const cancelLogout = document.getElementById('cancelLogout');
    const confirmLogout = document.getElementById('confirmLogout');

    logoutBtn.onclick = function(e) {
        e.preventDefault();
        logoutModal.style.display = 'block';
    }

    closeModal.onclick = function() {
        logoutModal.style.display = 'none';
    }

    cancelLogout.onclick = function() {
        logoutModal.style.display = 'none';
    }

    confirmLogout.onclick = function() {
        window.location.href = 'logout.php';
    }

    window.onclick = function(event) {
        if (event.target == logoutModal) {
            logoutModal.style.display = 'none';
        }
    }
    </script>
</body>
</html>