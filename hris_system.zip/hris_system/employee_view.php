<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM employees WHERE emp_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Employee not found.";
    exit();
}

$emp = $result->fetch_assoc();

$performance = [];
$perfStmt = $conn->prepare("
    SELECT evaluation_period, evaluator, rating, comments, created_at
    FROM performance
    WHERE emp_id = ?
    ORDER BY created_at DESC
");
$perfStmt->bind_param("i", $id);
$perfStmt->execute();
$perfResult = $perfStmt->get_result();

while ($row = $perfResult->fetch_assoc()) {
    $performance[] = $row;
}

$branches = [];
$branchQuery = $conn->query("SELECT * FROM branches ORDER BY branch_name ASC");
while ($b = $branchQuery->fetch_assoc()) {
    $branches[] = $b;
}

// Fetch departments
$departments = [];
$deptQuery = $conn->query("SELECT * FROM departments ORDER BY department_name ASC");
while ($d = $deptQuery->fetch_assoc()) {
    $departments[] = $d;
}

// Fetch positions
$positions = [];
$posQuery = $conn->query("SELECT * FROM positions ORDER BY position_name ASC");
while ($p = $posQuery->fetch_assoc()) {
    $positions[] = $p;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Details</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/employee_view.css">
</head>
<body>
    <div class="navbar">
        <h2>PulseWork: HR Information System</h2>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
            <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
        </div>
    </div>

    <nav class="sub-navbar">
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>
            
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_leave.php">Leave Form</a></li>
                    <li><a href="leave_requests.php">Leave Requests</a></li>
                </ul>
            </li>

            <!-- <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_payroll.php">Add Payroll</a></li>
                    <li><a href="payroll.php">Payroll List</a></li>
                    <li><a href="add_benefits.php">Add Benefits</a></li>
                    <li><a href="benefits_list.php">Benefits List</a></li>
                </ul>
            </li> -->

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
                <ul class="dropdown-content">
                    <li><a href="reports.php">Reports</a></li>
                    <li><a href="accounts.php">Accounts</a></li>
                    <li><a href="add_employee.php">Add Employee</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_job.php">Job Opening</a></li>
                    <li><a href="job_list.php">Job List</a></li>
                    <li><a href="add_candidate.php">Add Candidate</a></li>
                    <li><a href="candidate_list.php">Candidates</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
                <ul class="dropdown-content">
                    <li><a href="training_list.php">Trainings</a></li>
                    <li><a href="add_training.php">Add Training</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_performance.php">Add Evaluation</a></li>
                    <li><a href="performance_list.php">Evaluation List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <div class="main-content">
        <?php if (isset($_GET['updated'])): ?>
            <div style="padding:10px; background:#d4edda; color:black; border-radius:5px;">
                ✅ Information updated successfully!
            </div>
        <?php endif; ?>
        <div class="employee-profile">
            <div class="employee-header">
                <img src="<?php echo !empty($emp['image']) ? 'uploads/' . htmlspecialchars($emp['image']) : 'assets/images/default.png'; ?>" alt="Employee Image">

                <div class="info">
                    <h2><?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?></h2>
                    <p><strong>Employee No:</strong> <?php echo htmlspecialchars($emp['employee_no']); ?></p>
                    <p><strong><?php echo htmlspecialchars($emp['position']); ?></strong> — <?php echo htmlspecialchars($emp['department']); ?></p>
                    <p>Hired: <?php echo htmlspecialchars($emp['date_hired']); ?></p>
                </div>

                <div class="coe-actions">
                    <a href="generate_coe.php?id=<?php echo $emp['emp_id']; ?>" 
                    class="coe-btn" 
                    target="_blank">
                        📄 Generate COE
                    </a>
                </div>
            </div>

            <div class="employee-body">
                <div class="info-accordion">
                    <button class="accordion-header">
                        Personal Information
                        <span class="accordion-icon">+</span>
                    </button>

                    <div class="accordion-content">
                        <h3>
                            <a href="employee_personal.php?id=<?= $emp['emp_id'] ?>" class="section-link">
                                Personal Information ➤
                            </a>
                        </h3>

                        <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($emp['date_of_birth']); ?></p>
                        <p><strong>Gender:</strong> <?php echo htmlspecialchars($emp['gender']); ?></p>
                        <p><strong>Civil Status:</strong> <?php echo htmlspecialchars($emp['civil_status']); ?></p>
                        <p><strong>Nationality:</strong> <?php echo htmlspecialchars($emp['nationality']); ?></p>
                        <p><strong>Address:</strong> <?php echo htmlspecialchars($emp['address']); ?></p>
                    </div>
                </div>

                <div class="info-accordion">
                    <button class="accordion-header">
                        Contact Information
                        <span class="accordion-icon">+</span>
                    </button>

                    <div class="accordion-content">
                        <h3>
                            <a href="employee_contact.php?id=<?= $emp['emp_id'] ?>" class="section-link">
                                Contact Information ➤
                            </a>
                        </h3>

                        <p><strong>Mobile:</strong> <?= htmlspecialchars($emp['mobile_number']); ?></p>
                        <p><strong>Email:</strong> <?= htmlspecialchars($emp['email']); ?></p>
                        <p><strong>Contact Person:</strong> <?= htmlspecialchars($emp['contact_person']); ?></p>
                        <p><strong>Emergency Contact:</strong> <?= htmlspecialchars($emp['emergency_contact']); ?></p>
                    </div>
                </div>

                <div class="info-accordion">
                    <button class="accordion-header">
                        Employment Details
                        <span class="accordion-icon">+</span>
                    </button>

                    <div class="accordion-content">
                        <h3>
                            <a href="employee_employment.php?id=<?= $emp['emp_id'] ?>" class="section-link">
                                Employment Details ➤
                            </a>
                        </h3>

                        <p><strong>Tax Status:</strong> <?= htmlspecialchars($emp['tax_status']); ?></p>
                        <p><strong>Date Hired:</strong> <?= htmlspecialchars($emp['date_hired']); ?></p>

                        <p><strong>Contract End Date:</strong>
                            <?php 
                                if (!empty($emp['contract_end_date'])) {
                                    echo htmlspecialchars($emp['contract_end_date']);

                                    $today = new DateTime();
                                    $end = new DateTime($emp['contract_end_date']);
                                    $diff = $today->diff($end)->days;

                                    if ($end < $today) {
                                        echo " <span style='color:red;'>(Expired)</span>";
                                    } elseif ($diff <= 30) {
                                        echo " <span style='color:orange;'>(Expiring soon)</span>";
                                    }
                                } else {
                                    echo "<span style='color:gray;'>No contract end date</span>";
                                }
                            ?>
                        </p>

                        <p><strong>Contract File:</strong>
                            <?php if (!empty($emp['contract_file'])): ?>
                                <a href="<?= htmlspecialchars($emp['contract_file']); ?>" target="_blank">
                                    📄 View Contract
                                </a>
                            <?php else: ?>
                                <span style="color:gray;">No file uploaded</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>

                <div class="info-accordion">
                    <button class="accordion-header">
                        Employment Status & Type
                        <span class="accordion-icon">+</span>
                    </button>

                    <div class="accordion-content">
                        <p><strong>Employment Status:</strong>
                            <?= $emp['employment_status'] ?: '<span style="color:gray;">Not set</span>'; ?>
                        </p>

                        <p><strong>Employment Type:</strong>
                            <?= $emp['employment_type'] ?: '<span style="color:gray;">Not set</span>'; ?>
                        </p>

                        <form method="POST" action="update_employment.php" style="margin-top:10px;">
                            <input type="hidden" name="emp_id" value="<?= $emp['emp_id']; ?>">

                            <p><strong>Update Status:</strong></p>
                            <select name="employment_status" class="form-control">
                                <option value="">-- Select Status --</option>
                                <?php foreach (["Active","Seasonal","Probationary","Resigned","Terminated","AWOL","End of Contract"] as $st): ?>
                                    <option value="<?= $st ?>" <?= $emp['employment_status']===$st?'selected':'' ?>>
                                        <?= $st ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <p><strong>Update Employment Type:</strong></p>
                            <select name="employment_type" class="form-control">
                                <option value="">-- Select Type --</option>
                                <?php foreach (["Full-time","Part-time","Contractual","Project-based","Probationary"] as $tp): ?>
                                    <option value="<?= $tp ?>" <?= $emp['employment_type']===$tp?'selected':'' ?>>
                                        <?= $tp ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <button type="submit" class="update-btn">💾 Update Info</button>
                        </form>
                    </div>
                </div>

                <div class="info-accordion">
                    <button class="accordion-header">
                        Government IDs & Documents
                        <span class="accordion-icon">+</span>
                    </button>

                    <div class="accordion-content">
                        <p><strong>TIN No.:</strong> <?= htmlspecialchars($emp['tin_no']); ?></p>
                        <p><strong>SSS No.:</strong> <?= htmlspecialchars($emp['sss_no']); ?></p>
                        <p><strong>PhilHealth No.:</strong> <?= htmlspecialchars($emp['philhealth_no']); ?></p>

                        <hr>

                        <?php
                        $docs = [
                            'SSS File' => ['sss_file','uploads/sss/'],
                            'PhilHealth File' => ['philhealth_file','uploads/philhealth/'],
                            'Pag-IBIG File' => ['pagibig_file','uploads/pagibig/'],
                            'NBI Clearance' => ['nbi_file','uploads/nbi/']
                        ];

                        foreach ($docs as $label => [$field,$path]):
                        ?>
                            <p><strong><?= $label ?>:</strong>
                                <?php if (!empty($emp[$field])): ?>
                                    <a href="<?= $path . htmlspecialchars($emp[$field]); ?>" target="_blank">📄 View File</a>
                                <?php else: ?>
                                    <span style="color:gray;">No file uploaded</span>
                                <?php endif; ?>
                            </p>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="info-accordion">
                    <button class="accordion-header">
                        Branch / Location
                        <span class="accordion-icon">+</span>
                    </button>

                    <div class="accordion-content">
                        <form method="POST" action="update_branch.php">
                            <input type="hidden" name="emp_id" value="<?= $emp['emp_id']; ?>">

                            <p><strong>Assigned Branch:</strong></p>

                            <select name="branch_id" class="form-control" style="max-width:300px;">
                                <option value="">-- Select Branch --</option>
                                <?php foreach ($branches as $br): ?>
                                    <option value="<?= $br['branch_id']; ?>"
                                        <?= ($emp['branch_id'] == $br['branch_id']) ? 'selected' : ''; ?>>
                                        <?= htmlspecialchars($br['branch_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <button type="submit" class="update-btn">
                                💾 Update Branch
                            </button>
                        </form>
                    </div>
                </div>

                <div class="info-accordion">
                    <button class="accordion-header">
                        Department & Position
                        <span class="accordion-icon">+</span>
                    </button>

                    <div class="accordion-content">
                        <form method="POST" action="update_department_position.php">
                            <input type="hidden" name="emp_id" value="<?= $emp['emp_id']; ?>">

                            <p><strong>Assigned Department:</strong></p>
                            <select name="department_id" class="form-control" style="max-width:300px;">
                                <option value="">-- Select Department --</option>
                                <?php foreach ($departments as $dept): ?>
                                    <option value="<?= $dept['department_id']; ?>"
                                        <?= ($emp['department_id'] == $dept['department_id']) ? 'selected' : ''; ?>>
                                        <?= htmlspecialchars($dept['department_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <p><strong>Assigned Position:</strong></p>
                            <select name="position_id" class="form-control" style="max-width:300px;">
                                <option value="">-- Select Position --</option>
                                <?php foreach ($positions as $pos): ?>
                                    <option value="<?= $pos['position_id']; ?>"
                                        <?= ($emp['position_id'] == $pos['position_id']) ? 'selected' : ''; ?>>
                                        <?= htmlspecialchars($pos['position_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <button type="submit" class="update-btn">
                                💾 Update Department & Position
                            </button>
                        </form>
                    </div>
                </div>

                <div class="info-accordion">
                    <button class="accordion-header">
                        Performance Evaluations
                        <span class="accordion-icon">+</span>
                    </button>

                    <div class="accordion-content">
                        <?php if (!empty($performance)): ?>
                            <div class="performance-list">

                                <?php foreach ($performance as $perf): ?>
                                    <div class="performance-card">
                                        <div class="performance-header">
                                            <strong><?= htmlspecialchars($perf['evaluation_period']); ?></strong>
                                            <span class="performance-date">
                                                <?= date('M d, Y', strtotime($perf['created_at'])); ?>
                                            </span>
                                        </div>

                                        <p><strong>Evaluator:</strong> <?= htmlspecialchars($perf['evaluator']); ?></p>

                                        <p><strong>Rating:</strong>
                                            <?php
                                                if ($perf['rating'] !== null) {
                                                    $rating = (float)$perf['rating'];
                                                    if ($rating >= 4) {
                                                        $color = '#28a745'; $label = 'Excellent';
                                                    } elseif ($rating >= 3) {
                                                        $color = '#ffc107'; $label = 'Satisfactory';
                                                    } else {
                                                        $color = '#dc3545'; $label = 'Needs Improvement';
                                                    }
                                                    echo "<span class='rating-badge' style='background:$color'>
                                                            $rating – $label
                                                        </span>";
                                                } else {
                                                    echo "<span style='color:gray;'>Not rated</span>";
                                                }
                                            ?>
                                        </p>

                                        <?php if (!empty($perf['comments'])): ?>
                                            <div class="performance-comments">
                                                <strong>Comments:</strong>
                                                <p><?= nl2br(htmlspecialchars($perf['comments'])); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>

                            </div>
                        <?php else: ?>
                            <p style="color:gray;">No performance evaluations recorded.</p>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

            <div class="footer-actions">
                <a href="edit_employee.php?id=<?php echo $emp['emp_id']; ?>" class="back-btn" style="background:#28a745;">✏️ Edit</a>
                <a href="#" class="back-btn" style="background:#dc3545;" id="deleteEmployeeBtn">🗑 Delete</a>
                <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
            </div>
        </div>
    </div>

    <div id="logoutModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Confirm Logout</h3>
            <p>Are you sure you want to logout?</p>
            <div class="modal-buttons">
                <button id="confirmLogout" class="btn">Yes, Logout</button>
                <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
            </div>
        </div>
    </div>

    <div id="deleteModal" class="modal">
        <div class="modal-content enhanced">
            <span class="close-delete">&times;</span>
            <div class="modal-header">
                <span style="font-size:24px; color:#dc3545;">⚠️</span>
                <h3>Confirm Employee Deletion</h3>
            </div>
            <p>To permanently delete this employee, type <strong>confirm delete</strong> in the box below:</p>
            <input type="text" id="deleteConfirmInput" placeholder="Type here..." class="modal-input">
            <div class="modal-buttons">
                <button id="confirmDeleteBtn" class="btn delete-btn" disabled>
                    🗑 Delete Employee
                </button>
                <button id="cancelDeleteBtn" class="btn cancel-btn">
                    Cancel
                </button>
            </div>
        </div>
    </div>

<script>
document.querySelectorAll('.accordion-header').forEach(header => {
    header.addEventListener('click', () => {
        const accordion = header.parentElement;
        accordion.classList.toggle('active');
    });
});

function toggleDropdown(event) {
    event.preventDefault();

    document.querySelectorAll('.dropdown').forEach(drop => {
        if (!drop.contains(event.target)) {
            drop.classList.remove('active');
        }
    });

    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}

// Delete modal logic
const deleteModal = document.getElementById('deleteModal');
const deleteBtn = document.getElementById('deleteEmployeeBtn');
const closeDelete = document.querySelector('.close-delete');
const cancelDelete = document.getElementById('cancelDeleteBtn');
const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
const deleteInput = document.getElementById('deleteConfirmInput');

deleteBtn.onclick = function(e) {
    e.preventDefault();
    deleteModal.style.display = 'block';
    deleteInput.value = '';
    confirmDeleteBtn.disabled = true;
}

// Close modal
closeDelete.onclick = function() {
    deleteModal.style.display = 'none';
}

cancelDelete.onclick = function() {
    deleteModal.style.display = 'none';
}

// Enable delete button if correct phrase is typed
deleteInput.addEventListener('input', function() {
    if (deleteInput.value.toLowerCase() === 'confirm delete') {
        confirmDeleteBtn.disabled = false;
    } else {
        confirmDeleteBtn.disabled = true;
    }
});

// Confirm delete action
confirmDeleteBtn.onclick = function() {
    window.location.href = 'delete_employee.php?id=<?php echo $emp['emp_id']; ?>';
}

// Close modal if clicking outside
window.onclick = function(event) {
    if (event.target == deleteModal) {
        deleteModal.style.display = 'none';
    }
}
</script>
</body>
</html>