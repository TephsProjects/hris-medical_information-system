<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) exit('Not authorized');

$search = $_GET['search'] ?? '';
$employment_status = $_GET['employment_status'] ?? '';
$employment_type = $_GET['employment_type'] ?? '';
$birthday = $_GET['birthday'] ?? '';

// CSV headers
$headers = [
    'Employee ID', 'Employee No', 'First Name', 'Last Name', 'Address', 'Age', 'Date of Birth',
    'Department', 'Position', 'Civil Status', 'Tax Status', 'TIN No.', 'SSS No.',
    'PhilHealth No.', 'Nationality', 'Gender', 'Mobile Number', 'Email',
    'Contact Person', 'Emergency Contact', 'Date Hired', 'Contract End Date',
    'Contract File', 'Image', 'Employment Status', 'Employment Type', 'Branch / Location'
];

// Build query with JOINs
$query = "SELECT 
            e.*, 
            d.department_name, 
            p.position_name, 
            b.branch_name
          FROM employees e
          LEFT JOIN departments d ON e.department_id = d.department_id
          LEFT JOIN positions p ON e.position_id = p.position_id
          LEFT JOIN branches b ON e.branch_id = b.branch_id
          WHERE 1=1";

$params = [];
$types = "";

// Filters
if ($search) {
    $search_query = "%$search%";
    $query .= " AND (e.first_name LIKE ? OR e.last_name LIKE ? OR d.department_name LIKE ? OR p.position_name LIKE ?)";
    $types .= "ssss";
    array_push($params, $search_query, $search_query, $search_query, $search_query);
}

if ($employment_status) {
    $query .= " AND e.employment_status = ?";
    $types .= "s";
    array_push($params, $employment_status);
}

if ($employment_type) {
    $query .= " AND e.employment_type = ?";
    $types .= "s";
    array_push($params, $employment_type);
}

if ($birthday) {
    $query .= " AND e.date_of_birth = ?";
    $types .= "s";
    array_push($params, $birthday);
}

// Execute query
$stmt = $conn->prepare($query);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
$employees = $result->fetch_all(MYSQLI_ASSOC);

// Output CSV
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="employees.csv"');

$out = fopen('php://output', 'w');
fputcsv($out, $headers);

foreach ($employees as $row) {
    $rowData = [
        $row['emp_id'],
        $row['employee_no'],
        $row['first_name'],
        $row['last_name'],
        $row['address'],
        $row['age'],
        $row['date_of_birth'],
        $row['department_name'],   // updated
        $row['position_name'],     // updated
        $row['civil_status'],
        $row['tax_status'],
        $row['tin_no'],
        $row['sss_no'],
        $row['philhealth_no'],
        $row['nationality'],
        $row['gender'],
        $row['mobile_number'],
        $row['email'],
        $row['contact_person'],
        $row['emergency_contact'],
        $row['date_hired'],
        $row['contract_end_date'],
        $row['contract_file'],
        $row['image'],
        $row['employment_status'],
        $row['employment_type'],
        $row['branch_name']        // added
    ];
    fputcsv($out, $rowData);
}

fclose($out);
exit;
?>
