<?php
session_start();
require_once('includes/db.php');
require_once __DIR__ . '/vendor/tecnickcom/tcpdf/tcpdf.php';

// ==========================
// ACCESS CHECK
// ==========================
if (!isset($_SESSION['user_id'])) {
    die('Unauthorized access.');
}

// ==========================
// TCPDF SETUP (LANDSCAPE)
// ==========================
$pdf = new TCPDF('L', 'mm', 'Letter', true, 'UTF-8', false);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->SetCreator('PulseWork HRIS');
$pdf->SetAuthor('PulseWork');
$pdf->SetTitle('PhilHealth ER2');
$pdf->SetMargins(0, 0, 0);
$pdf->SetAutoPageBreak(false);
$pdf->AddPage();

// ==========================
// THICKER BORDERS
// ==========================
$pdf->SetLineWidth(0.5); // 0.5 mm line width for all borders

// ==========================
// PAGE SIZE
// ==========================
$pageW = $pdf->getPageWidth();
$pageH = $pdf->getPageHeight();

// ==========================
// OUTER BORDER
// ==========================
$offset = 8;
$pdf->Rect(
    $offset,
    $offset,
    $pageW - (2 * $offset),
    $pageH - (2 * $offset)
);

$pdf->SetFont('times', '', 10);
$pdf->SetXY($offset, 3); // 4mm from top of the page (outside the main border)
$pdf->Cell($pageW - 2 * $offset, 6, 'PLEASE READ INSTRUCTION AT THE BACK BEFORE ACCOMPLISHING THIS FORM', 0, 1, 'C');

// ==========================
// HEADER BORDER
// ==========================
$headerHeight = 25;
$pdf->Rect(
    $offset,
    $offset,
    $pageW - (2 * $offset),
    $headerHeight
);

// ==========================
// HEADER LEFT SIDE
// ==========================

// Logo
$pdf->Image(
    __DIR__ . '/assets/images/philhealth-icon.png',
    $offset + 4,
    $offset + 6,
    18
);

// Text beside logo
$textX = $offset + 26;

$pdf->SetFont('times', 'B', 18);
$pdf->SetXY($textX, $offset + 8);
$pdf->Cell(120, 8, 'PHILHEALTH', 0, 1, 'L');

$pdf->SetFont('times', '', 11);
$pdf->SetX($textX);
$pdf->Cell(120, 6, 'REPORT OF EMPLOYEE-MEMBERS', 0, 1, 'L');

// ==========================
// HEADER RIGHT SIDE (SAFE + PADDED)
// ==========================

// Inner right padding so ER2 is NOT too close to border
$rightPadding = 14;

// Column width for ER2 + checkboxes
$rightBlockW = 120;

// Anchor X inside header
$rightBlockX = ($pageW - $offset - $rightPadding) - $rightBlockW;

// --- ER2 (slightly DOWN) ---
$pdf->SetFont('times', 'B', 30);
$pdf->SetXY($rightBlockX, $offset + 7.5);
$pdf->Cell($rightBlockW, 10, 'Er2', 0, 1, 'R');

// --- Checkbox label (slightly UP) ---
$pdf->SetFont('times', '', 12);
$pdf->SetXY($rightBlockX, $offset + 7);
$pdf->Cell($rightBlockW, 5, '(CHECK APPLICABLE BOX)', 0, 1, 'L');

// --- Checkboxes (STACKED, INSIDE HEADER, UP) ---
$boxX = $rightBlockX;
$boxY = $offset + 13;

// Initial List
$pdf->Rect($boxX, $boxY, 4, 4);
$pdf->SetXY($boxX + 6, $boxY - 1);
$pdf->Cell(60, 6, 'INITIAL LIST (Attach to PhilHealth Form Er1)', 0, 1);

// Subsequent List
$boxY += 6;

$pdf->Rect($boxX, $boxY, 4, 4);
$pdf->SetXY($boxX + 6, $boxY - 1);
$pdf->Cell(60, 6, 'SUBSEQUENT LIST', 0, 1);

// ==========================
// EMPLOYER INFO BORDER (DIRECTLY BELOW HEADER — NO GAP)
// ==========================

// Position
$infoY      = $offset + $headerHeight;
$infoHeight = 11;

// Draw main info row border
$pdf->Rect(
    $offset,
    $infoY,
    $pageW - (2 * $offset),
    $infoHeight
);

// ==========================
// COLUMN SPLIT (WIDE LEFT, NARROW RIGHT)
// ==========================

// Column widths
$leftColW  = ($pageW - (2 * $offset)) * 0.7; // 70% width
$rightColW = ($pageW - (2 * $offset)) * 0.3; // 30% width

// Vertical divider (single line, no overlap)
$pdf->Line(
    $offset + $leftColW,
    $infoY,
    $offset + $leftColW,
    $infoY + $infoHeight
);

// ==========================
// COLUMN LABELS WITH ACTUAL DATA — SIDE BY SIDE
// ==========================

// LEFT COLUMN — Name of Employer / Firm
$employerName   = $_POST['employer_name'] ?? '';
$employerNumber = $_POST['employer_number'] ?? '';
$address        = $_POST['address'] ?? '';
$email          = $_POST['email_address'] ?? '';

// Set font for labels
$pdf->SetFont('times', 'B', 10);

// LEFT — Name of Employer / Firm
$pdf->SetXY($offset + 4, $infoY + 3);
$labelWidth = 55; // width reserved for the label
$pdf->Cell($labelWidth, 6, 'NAME OF EMPLOYER / FIRM:', 0, 0, 'L');

// Set font for actual employer name
$pdf->SetFont('times', 'B', 10);

// Print employer name **beside the label on the same line**
$pdf->Cell($leftColW - $labelWidth - 4, 6, $employerName, 0, 0, 'L');

// RIGHT — Employer Number
$pdf->SetFont('times', 'B', 10);
$pdf->SetXY($offset + $leftColW + 4, $infoY + 3);
$pdf->Cell(30, 6, 'EMPLOYER NO.', 0, 0, 'L'); // 30 mm for label width

$pdf->SetFont('times', 'B', 10);
$pdf->Cell($rightColW - 34, 6, $employerNumber, 0, 0, 'L');

// ==========================
// ADDRESS & EMAIL BORDER (DIRECTLY BELOW EMPLOYER INFO — NO GAP)
// ==========================

// Previous row's Y + height
$prevY      = $infoY;
$prevHeight = $infoHeight;

// New row position
$addressY      = $prevY + $prevHeight;
$addressHeight = 11;

// Draw the border for Address / Email
$pdf->Rect(
    $offset,
    $addressY,
    $pageW - (2 * $offset),
    $addressHeight
);

// Column widths for 60/40 split
$leftColW  = ($pageW - (2 * $offset)) * 0.6; // 60%
$rightColW = ($pageW - (2 * $offset)) * 0.4; // 40%

// Vertical divider
$pdf->Line(
    $offset + $leftColW,
    $addressY,
    $offset + $leftColW,
    $addressY + $addressHeight
);

// ==========================
// ADDRESS & EMAIL BORDER — SIDE BY SIDE
// ==========================

// Draw the border for Address / Email
$addressY      = $infoY + $infoHeight;
$addressHeight = 11;
$pdf->Rect($offset, $addressY, $pageW - (2 * $offset), $addressHeight);

// Column widths for 60/40 split
$leftColW  = ($pageW - (2 * $offset)) * 0.6; // 60%
$rightColW = ($pageW - (2 * $offset)) * 0.4; // 40%

// Vertical divider
$pdf->Line(
    $offset + $leftColW,
    $addressY,
    $offset + $leftColW,
    $addressY + $addressHeight
);

// LEFT — Address
$pdf->SetFont('times', 'B', 10);
$pdf->SetXY($offset + 4, $addressY + 3);
$pdf->Cell(25, 6, 'ADDRESS:', 0, 0, 'L'); // 25 mm for label

$pdf->SetFont('times', 'B', 10);
$pdf->Cell($leftColW - 29, 6, $address, 0, 0, 'L'); // remaining width

// RIGHT — Email
$pdf->SetFont('times', 'B', 10);
$pdf->SetXY($offset + $leftColW + 4, $addressY + 3);
$pdf->Cell(35, 6, 'EMAIL ADDRESS:', 0, 0, 'L'); // 35 mm for label

$pdf->SetFont('times', 'B', 10);
$pdf->Cell($rightColW - 39, 6, $email, 0, 0, 'L'); // remaining width

// ==========================
// EMPLOYEE TABLE HEADER BORDER (DIRECTLY BELOW ADDRESS / EMAIL — NO GAP)
// ==========================

// Previous row's Y + height
$prevY        = $addressY;
$prevHeight   = $addressHeight;

// New row position
$tableY       = $prevY + $prevHeight;
$tableHeight  = 15; // Height of the header row

// Draw main border for employee table header
$pdf->Rect(
    $offset,
    $tableY,
    $pageW - (2 * $offset),
    $tableHeight
);

// ==========================
// COLUMN WIDTHS
// ==========================
// Approximate percentages of total width (adjust if needed)
$colWidths = [
    0.15, // PhilHealth / SSS/GSIS No. - 15%
    0.25, // Name of Employee - 25%
    0.15, // Position - 15%
    0.10, // Salary - 10%
    0.15, // Date of Employment - 15%
    0.10, // Eff. Date of Coverage (DO NOT FILL) - 10%
    0.10  // Previous Employer (if any) - 10%
];

// Convert percentages to mm
$totalWidth = $pageW - (2 * $offset);
$colWidthsMM = [];
foreach ($colWidths as $w) {
    $colWidthsMM[] = $w * $totalWidth;
}

// ==========================
// DRAW VERTICAL DIVIDERS
// ==========================
$currentX = $offset;
for ($i = 0; $i < count($colWidthsMM) - 1; $i++) {
    $currentX += $colWidthsMM[$i];
    $pdf->Line(
        $currentX,
        $tableY,
        $currentX,
        $tableY + $tableHeight
    );
}

// ==========================
// COLUMN LABELS
// ==========================
$pdf->SetFont('times', 'B', 9);

$labels = [
    'PHILHEALTH / SSS / GSIS NO.',
    'NAME OF EMPLOYEE',
    'POSITION',
    'SALARY',
    'DATE OF EMPLOYMENT',
    'EFF. DATE OF COVERAGE',
    'PREVIOUS EMPLOYER (IF ANY)'
];

$currentX = $offset;
for ($i = 0; $i < count($labels); $i++) {
    $pdf->SetXY($currentX + 1, $tableY + 3); // +1 mm padding
    $pdf->MultiCell($colWidthsMM[$i] - 2, 6, $labels[$i], 0, 'C', false);
    $currentX += $colWidthsMM[$i];
}

// ==========================
// FETCH EMPLOYEES WITH HIRE DATE FILTER
// ==========================
$start_date = $_POST['start_date'] ?? '';
$end_date   = $_POST['end_date'] ?? '';

$query = "
    SELECT e.*, p.position_name
    FROM employees e
    LEFT JOIN positions p ON e.position_id = p.position_id
    WHERE e.employment_status='Active'
      AND e.philhealth_no IS NOT NULL
";

$params = [];
$types = '';

if (!empty($start_date) && !empty($end_date)) {
    $query .= " AND e.date_hired BETWEEN ? AND ?";
    $params[] = $start_date;
    $params[] = $end_date;
    $types .= 'ss';
}

$query .= " ORDER BY e.last_name, e.first_name";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$employees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// ==========================
// EMPLOYEE TABLE BODY
// ==========================

$prevY      = $tableY;
$prevHeight = $tableHeight;

$bodyY      = $prevY + $prevHeight;
$bottomHeight = 15; // bottom border height
$bodyHeight   = ($pageH - $offset) - $bottomHeight - $bodyY;

$bodyX = $offset;
$bodyW = $pageW - 2 * $offset;

// Draw the outer rectangle for the body
$pdf->Rect($bodyX, $bodyY, $bodyW, $bodyHeight);

// Draw vertical dividers
$currentX = $bodyX;
for ($i = 0; $i < count($colWidthsMM) - 1; $i++) {
    $currentX += $colWidthsMM[$i];
    $pdf->Line($currentX, $bodyY, $currentX, $bodyY + $bodyHeight);
}

// Fill employee rows
$pdf->SetFont('times', '', 9);
$lineHeight = 6;
$currentY = $bodyY + 1;

foreach ($employees as $emp) {
    if ($currentY + $lineHeight > $bodyY + $bodyHeight) break;

    $currentX = $bodyX;

    // PHILHEALTH No.
    $pdf->SetXY($currentX + 1, $currentY);
    $pdf->Cell($colWidthsMM[0]-2, $lineHeight, $emp['philhealth_no'], 0, 0, 'C');
    $currentX += $colWidthsMM[0];

    // Name of Employee
    $full_name = $emp['first_name'].' '.($emp['middle_name'] ? $emp['middle_name'].' ' : '').$emp['last_name'].($emp['name_suffix'] ? ', '.$emp['name_suffix'] : '');
    $pdf->SetXY($currentX + 1, $currentY);
    $pdf->Cell($colWidthsMM[1]-2, $lineHeight, $full_name, 0, 0, 'C');
    $currentX += $colWidthsMM[1];

    // Position — from positions table
    $positionName = $emp['position_name'] ?? '';
    $pdf->SetXY($currentX + 1, $currentY);
    $pdf->Cell($colWidthsMM[2]-2, $lineHeight, $positionName, 0, 0, 'C');
    $currentX += $colWidthsMM[2];

    // Salary (optional)
    $pdf->SetXY($currentX + 1, $currentY);
    $pdf->Cell($colWidthsMM[3]-2, $lineHeight, $emp['salary'] ?? '', 0, 0, 'C');
    $currentX += $colWidthsMM[3];

    // Date of Employment
    $pdf->SetXY($currentX + 1, $currentY);
    $pdf->Cell($colWidthsMM[4]-2, $lineHeight, $emp['date_hired'], 0, 0, 'C');
    $currentX += $colWidthsMM[4];

    // Eff. Date of Coverage (leave blank)
    $pdf->SetXY($currentX + 1, $currentY);
    $pdf->Cell($colWidthsMM[5]-2, $lineHeight, '', 0, 0, 'C');
    $currentX += $colWidthsMM[5];

    // Previous Employer (leave blank)
    $pdf->SetXY($currentX + 1, $currentY);
    $pdf->Cell($colWidthsMM[6]-2, $lineHeight, '', 0, 0, 'C');

    $currentY += $lineHeight;
}

// ==========================
// BOTTOM BORDER (3 COLUMNS: TOTAL / PAGE / SIGNATURE)
// ==========================

// Position — directly below the table body
$bottomY = $bodyY + $bodyHeight;

// Draw the outer rectangle for bottom section
$pdf->Rect(
    $offset,
    $bottomY,
    $pageW - 2 * $offset,
    $bottomHeight
);

// Column widths
$totalWidth   = $pageW - 2 * $offset;
$middleColW   = $totalWidth * 0.2;  // middle column smaller (20%)
$remainingW   = $totalWidth - $middleColW;
$sideColW     = $remainingW / 2;    // left and right columns equal

// Column X positions
$leftX   = $offset;
$middleX = $leftX + $sideColW;
$rightX  = $middleX + $middleColW;

// Vertical dividers
$pdf->Line($middleX, $bottomY, $middleX, $bottomY + $bottomHeight);
$pdf->Line($rightX, $bottomY, $rightX, $bottomY + $bottomHeight);

// Column Labels
$pdf->SetFont('times', 'B', 10);

// Left column — total employees
$pdf->SetXY($leftX + 2, $bottomY + 4);
$pdf->Cell($sideColW - 4, 6, 'TOTAL NO. LISTED ABOVE: '.count($employees), 0, 0, 'L');

// Middle column — page placeholder
$pdf->SetXY($middleX, $bottomY + 7);
$pdf->Cell($middleColW, 6, 'PAGE __ OF __ SHEETS', 0, 0, 'C');

// Right column — signature
$signatureLabel = 'SIGNATURE OVER PRINTED NAME:'; // the label under the line
$actualName = $_POST['signatory'] ?? '';         // the actual name above the line

$pdf->SetFont('times', 'B', 10);

// Measure widths
$labelWidth = $pdf->GetStringWidth($signatureLabel);
$nameWidth  = $pdf->GetStringWidth($actualName);

// X positions (centered inside right column)
$labelX = $rightX + ($sideColW - $labelWidth) / 2;
$nameX  = $rightX + ($sideColW - $nameWidth) / 2;

// Vertical positions inside the bottom border
$paddingTop = 2; // space from top of bottom border
$lineY      = $bottomY + $paddingTop + 6; // underline 6mm from top of bottom border
$nameY      = $lineY - 5;                 // actual name slightly above the line
$labelY     = $lineY + 1;                 // label slightly below the line

// Draw underline
$pdf->Line($labelX, $lineY, $labelX + $labelWidth, $lineY);

// Print the actual name above the underline
$pdf->SetXY($nameX, $nameY);
$pdf->Cell($nameWidth, 5, $actualName, 0, 0, 'C');

// Print the label below the underline
$pdf->SetXY($labelX, $labelY);
$pdf->Cell($labelWidth, 5, $signatureLabel, 0, 0, 'C');

$pdf->SetFont('times', 'B', 10);
$pdf->SetXY($offset, $pageH - 6); // 4mm from bottom of the page (outside the main border)
$pdf->Cell($pageW - 2 * $offset, 6, 'TO BE ACCOMPLISHED IN DUPLICATE', 0, 1, 'C');

// ==========================
// OUTPUT
// ==========================
$pdf->Output('PhilHealth_ER2_Header.pdf', 'I');
