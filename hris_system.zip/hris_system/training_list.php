<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$employees = $conn->query("SELECT emp_id, CONCAT(first_name, ' ', last_name) AS full_name FROM employees ORDER BY first_name ASC");

$where = "";
if (isset($_GET['emp_ids']) && !empty($_GET['emp_ids'])) {
    $emp_ids = array_map('intval', $_GET['emp_ids']);
    $where = "WHERE t.emp_id IN (" . implode(',', $emp_ids) . ")";
}

$sql = "
    SELECT t.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name
    FROM trainings t
    LEFT JOIN employees e ON t.emp_id = e.emp_id
    $where
    ORDER BY t.completion_date ASC, t.progress DESC
";
$trainings = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Training List</title>
<link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
<link rel="stylesheet" href="assets/css/style.css">
<style>
    .progress-bar {
        width: 100%;
        background: #eee;
        border-radius: 10px;
        height: 20px;
        position: relative;
    }
    .progress-fill {
        height: 100%;
        border-radius: 10px;
        text-align: center;
        color: white;
        font-size: 12px;
        line-height: 20px;
    }
    .progress-low { background: #dc3545; }
    .progress-mid { background: #ffc107; }
    .progress-high { background: #28a745; }

    .completed-row { background: #d4edda; }

    .filter-box {
        margin-bottom: 15px;
        background: #f1f1f1;
        padding: 10px;
        border-radius: 8px;
    }

    .progress-input {
        width: 60px;
        text-align: center;
        padding: 5px;
    }

    #msg {
        margin: 10px 0;
        padding: 10px;
        font-weight: bold;
        display: none;
        border-radius: 5px;
    }
    #msg.success {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    #msg.error {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }

    .filter-box {
        background: #ffffff;
        border-radius: 12px;
        padding: 16px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.08);
        margin-bottom: 20px;
    }

    .filter-form {
        display: flex;
        gap: 20px;
        align-items: flex-end;
        flex-wrap: wrap;
    }

    .filter-group {
        display: flex;
        flex-direction: column;
    }

    .filter-group label {
        font-weight: 600;
        margin-bottom: 6px;
    }

    .filter-group select {
        width: 260px;
        border-radius: 8px;
        padding: 6px;
    }

    .filter-group small {
        color: #666;
        font-size: 12px;
        margin-top: 4px;
    }

    .filter-actions {
        display: flex;
        gap: 10px;
    }

    .btn-primary {
        background: #007bff;
        color: #fff;
        border: none;
        padding: 8px 14px;
        border-radius: 8px;
        cursor: pointer;
    }

    .btn-primary:hover {
        background: #0069d9;
    }

    .btn-secondary {
        background: #e0e0e0;
        color: #333;
        padding: 8px 14px;
        border-radius: 8px;
        text-decoration: none;
    }

    .action-cell {
        text-align: center;
    }

    .action-controls {
        display: flex;
        gap: 6px;
        justify-content: center;
        align-items: center;
    }

    .btn-update {
        background: #28a745;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 12px;
    }

    .btn-update:hover {
        background: #218838;
    }

    .badge-complete {
        background: #28a745;
        color: #fff;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
    }

    .employee-search-box {
        display: flex;
        flex-direction: column;
        gap: 8px; /* space between search and list */
    }

    .employee-search-input input {
        width: 100%; /* full width of container */
        padding: 8px 10px;
        border-radius: 8px;
        border: 1px solid #ccc;
        box-sizing: border-box;
    }

    .employee-list {
        width: 350px; /* set specific width */
        max-height: 180px;
        overflow-y: auto;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 6px;
        background: #fafafa;
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .employee-item {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 4px 6px;
        cursor: pointer;
        font-size: 14px;
    }

    .employee-item input[type="checkbox"] {
        flex-shrink: 0;
    }

    .employee-item .employee-name {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .employee-item:hover {
        background: #f1f1f1;
        border-radius: 6px;
    }
</style>
</head>
<body>
<div class="navbar">
    <h2>PulseWork: HR Information System</h2>
    <div class="user-info">
        <span>Welcome, <?= $_SESSION['full_name']; ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<div class="sub-navbar">
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>
            
        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_leave.php">Leave Form</a></li>
                <li><a href="leave_requests.php">Leave Request Lists</a></li>
            </ul>
        </li>

        <!-- <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_payroll.php">Add Payroll</a></li>
                <li><a href="payroll.php">Payroll List</a></li>
                <li><a href="add_benefits.php">Add Benefits</a></li>
                <li><a href="benefits_list.php">Benefits List</a></li>
            </ul>
        </li> -->

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
            <ul class="dropdown-content">
                <li><a href="reports.php">Reports</a></li>
                <li><a href="accounts.php">Accounts</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_job.php">Add Job Opening</a></li>
                <li><a href="job_list.php">Job Openings</a></li>
                <li><a href="add_candidate.php">Add Candidate</a></li>
                <li><a href="candidate_list.php">Candidates</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" class="active" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
            <ul class="dropdown-content">
                <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                <li><a href="training_list.php" class="active">Trainings</a></li>
                <li><a href="add_training.php">Add Training</a></li>
            </ul>
        </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_performance.php">Add Evaluation</a></li>
                <li><a href="performance_list.php">Evaluation List</a></li>
            </ul>
        </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
    </ul>
</div>

<div class="main-content">
    <h3>Training List</h3>
    <div id="msg"></div>

    <div class="filter-box">
        <form method="GET" id="filterForm" class="filter-form">
            <div class="filter-group">
                <label>Employees</label>
                <div class="employee-search-box">
                    <!-- Search input -->
                    <div class="employee-search-input">
                        <input type="text"
                            id="employeeSearch"
                            placeholder="Search employee..."
                            onkeyup="filterEmployees()">
                    </div>

                    <!-- Checkbox list -->
                    <div class="employee-list">
                        <?php while ($emp = $employees->fetch_assoc()): ?>
                            <label class="employee-item">
                                <input type="checkbox"
                                    name="emp_ids[]"
                                    value="<?= $emp['emp_id']; ?>"
                                    <?= (isset($emp_ids) && in_array($emp['emp_id'], $emp_ids)) ? 'checked' : ''; ?>>
                                <span class="employee-name"><?= htmlspecialchars($emp['full_name']); ?></span>
                            </label>
                        <?php endwhile; ?>
                    </div>
                </div>
                <small>Hold Ctrl (Windows) or Cmd (Mac) to select multiple</small>
            </div>

            <div class="filter-actions">
                <button type="submit" class="btn-primary">Apply</button>
                <a href="training_list.php" class="btn-secondary">Clear</a>
            </div>
        </form>
    </div>

    <table>
        <tr>
            <th>Employee</th>
            <th>Training Title</th>
            <th>Progress</th>
            <th>Completion Date</th>
            <th>Action</th>
        </tr>
        <?php while ($t = $trainings->fetch_assoc()): 
            $fillClass = 'progress-low';
            if ($t['progress'] >= 70) $fillClass = 'progress-high';
            elseif ($t['progress'] >= 40) $fillClass = 'progress-mid';

            $rowClass = ($t['progress'] >= 100) ? 'completed-row' : '';
        ?>
        <tr class="<?= $rowClass; ?>">
            <td><?= htmlspecialchars($t['employee_name']); ?></td>
            <td><?= htmlspecialchars($t['title']); ?></td>
            <td>
                <div class="progress-bar">
                    <div class="progress-fill <?= $fillClass; ?>" style="width: <?= $t['progress']; ?>%;">
                        <?= $t['progress']; ?>%
                    </div>
                </div>
            </td>
            <td><?= htmlspecialchars($t['completion_date'] ?? '—'); ?></td>
            <td class="action-cell">
                <?php if ($t['progress'] >= 100): ?>
                    <span class="badge-complete">Completed</span>
                <?php else: ?>
                    <div class="action-controls">
                        <input type="number"
                            class="progress-input"
                            min="0"
                            max="100"
                            value="<?= $t['progress']; ?>"
                            id="progress_<?= $t['training_id']; ?>">
                        <button class="btn-update"
                                onclick="updateProgress(<?= $t['training_id']; ?>)">
                            Update
                        </button>
                    </div>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<script>
    function filterEmployees() {
        const input = document.getElementById('employeeSearch').value.toLowerCase();
        const items = document.querySelectorAll('.employee-item');

        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            item.style.display = text.includes(input) ? '' : 'none';
        });
    }

function toggleDropdown(e) {
    e.preventDefault();
    e.target.closest('.dropdown').classList.toggle('active');
}

function updateProgress(trainingId) {
    const progress = document.getElementById('progress_' + trainingId).value;
    fetch('update_training_progress.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'training_id=' + trainingId + '&progress=' + progress
    })
    .then(r => r.text())
    .then(data => {
        const msg = document.getElementById('msg');
        msg.style.display = 'block';
        if (data === 'success') {
            msg.className = 'success';
            msg.textContent = 'Progress updated successfully!';
            setTimeout(() => location.reload(), 800);
        } else {
            msg.className = 'error';
            msg.textContent = 'Error updating progress.';
        }
        setTimeout(() => msg.style.display = 'none', 2000);
    });
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}
</script>
</body>
</html>