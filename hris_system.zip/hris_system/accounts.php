<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    $employer_ss_number = !empty($_POST['employer_ss_number'])
        ? trim($_POST['employer_ss_number'])
        : null;

    $employer_type = !empty($_POST['employer_type'])
        ? $_POST['employer_type']
        : null;

    $e_signature = null;

    if (!empty($_FILES['e_signature']['name'])) {

        if ($_FILES['e_signature']['error'] !== UPLOAD_ERR_OK) {
            $error = "E-signature upload failed.";
        } else {

            $fileTmpPath = $_FILES['e_signature']['tmp_name'];
            $fileName = $_FILES['e_signature']['name'];
            $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

            if ($ext !== 'png') {
                $error = "E-signature must be a PNG file.";
            } else {

                $uploadDir = __DIR__ . '/uploads/esignatures/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }

                $newFileName = uniqid('esign_', true) . '.png';
                $destination = $uploadDir . $newFileName;

                if (move_uploaded_file($fileTmpPath, $destination)) {
                    $e_signature = $newFileName;
                } else {
                    $error = "Failed to save e-signature file.";
                }
            }
        }
    }

    $stmt = $conn->prepare("
    INSERT INTO users 
    (full_name, username, password, role, employer_ss_number, employer_type, e_signature)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "sssssss",
        $full_name,
        $username,
        $password,
        $role,
        $employer_ss_number,
        $employer_type,
        $e_signature
    );

    if ($stmt->execute()) {
        $success = "Account created successfully!";
    } else {
        $error = "Error: " . $conn->error;
    }
}

$result = $conn->query("
    SELECT id, full_name, username, role, employer_ss_number, employer_type, e_signature, created_at
    FROM users
    ORDER BY created_at DESC
");

if (!$result) {
    die("Database query failed: " . $conn->error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Accounts</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/accounts.css">
</head>
<body>
    <div class="navbar">
        <h2>PulseWork: HR Information System</h2>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
            <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
        </div>
    </div>

    <div class="sub-navbar">
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>
            
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_leave.php">Leave Form</a></li>
                    <li><a href="leave_requests.php">Leave Requests</a></li>
                </ul>
            </li>

            <!-- <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_payroll.php">Add Payroll</a></li>
                    <li><a href="payroll.php">Payroll List</a></li>
                    <li><a href="add_benefits.php">Add Benefits</a></li>
                    <li><a href="benefits_list.php">Benefits List</a></li>
                </ul>
            </li> -->

            <li class="dropdown">
                <a href="#" class="active" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
                <ul class="dropdown-content">
                    <li><a href="reports.php">Reports</a></li>
                    <li><a href="accounts.php" class="active">Accounts</a></li>
                    <li><a href="add_employee.php">Add Employee</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_job.php">Add Job Opening</a></li>
                    <li><a href="job_list.php">Job Openings</a></li>
                    <li><a href="add_candidate.php">Add Candidate</a></li>
                    <li><a href="candidate_list.php">Candidates</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
                <ul class="dropdown-content">
                    <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                    <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                    <li><a href="training_list.php">Trainings</a></li>
                    <li><a href="add_training.php">Add Training</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_performance.php">Add Evaluation</a></li>
                    <li><a href="performance_list.php">Evaluations</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
        </ul>

        <div class="dashboard-switch">
            <a href="medical_dashboard.php" class="switch-btn">
                🏥 Medical Dashboard
            </a>
        </div>
    </div>

    <div class="main-content">
    <?php if (isset($_GET['deleted'])): ?>
        <div class="message success">Account deleted successfully.</div>
    <?php endif; ?>

    <?php if (isset($success)): ?>
        <div class="message success"><?php echo $success; ?></div>
    <?php elseif (isset($error)): ?>
        <div class="message error"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="add-account-form">
        <h4>Add New Account</h4>
        <form method="POST" action="" enctype="multipart/form-data">
            <label>Full Name</label>
            <input type="text" name="full_name" required>

            <label>Username</label>
            <input type="text" name="username" required>

            <label>Password</label>
            <input type="password" name="password" required>

            <label>Role</label>
            <select name="role" required>
                <option value="Admin">Admin</option>
                <option value="HR Staff">HR Staff</option>
            </select>

            <label>Employer SSS Number (optional)</label>
            <input type="text" name="employer_ss_number" placeholder="XX-XXXXXXX-X">

            <label>Employer Type (optional)</label>
            <select name="employer_type">
                <option value="">-- Select --</option>
                <option value="regular">Regular</option>
                <option value="household">Household</option>
            </select>

            <label>E-signature (PNG) - optional</label>
                <input type="file" name="e_signature" accept="image/png">

            <button type="submit">Add Account</button>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Username</th>
                <th>Role</th>
                <th>Employer SS No</th>
                <th>Employer Type</th>
                <th>E-Signature</th>
                <th>Date Created</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($user = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($user['id']); ?></td>
                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                <td><?php echo htmlspecialchars($user['username']); ?></td>
                <td><?php echo htmlspecialchars($user['role']); ?></td>
                <td><?= htmlspecialchars($user['employer_ss_number'] ?? '-') ?></td>
                <td><?= htmlspecialchars(ucfirst($user['employer_type'] ?? '-')) ?></td>
                <td>
                    <?php if (!empty($user['e_signature'])): ?>
                        <img src="uploads/esignatures/<?php echo htmlspecialchars($user['e_signature']); ?>" alt="E-signature" style="height:50px;">
                    <?php else: ?>
                        <span style="color:gray;">None</span>
                    <?php endif; ?>
                </td>
                <td><?php echo htmlspecialchars($user['created_at']); ?></td>
                <td>
                    <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn-edit">Edit</a>
                    <a href="#" class="btn-delete" data-user-id="<?php echo $user['id']; ?>" onclick="openDeleteModal(event)">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<div id="deleteUserModal" class="modal">
    <div class="modal-content enhanced">
        <span class="close-delete">&times;</span>
        <div class="modal-header">
            <span style="font-size:24px; color:#dc3545;">⚠️</span>
            <h3>Confirm Account Deletion</h3>
        </div>
        <p>
            This action <strong>cannot be undone</strong>.<br>
            Type <strong>confirm delete</strong> to continue.
        </p>
        <input type="text" id="deleteUserInput" placeholder="Type here..." class="modal-input">
        <div class="modal-buttons">
            <button id="confirmDeleteUserBtn" class="btn delete-btn" disabled>🗑 Delete Account</button>
            <button id="cancelDeleteUserBtn" class="btn cancel-btn">Cancel</button>
        </div>
    </div>
</div>

<script>
const deleteUserModal = document.getElementById('deleteUserModal');
const deleteUserInput = document.getElementById('deleteUserInput');
const confirmDeleteUserBtn = document.getElementById('confirmDeleteUserBtn');
const cancelDeleteUserBtn = document.getElementById('cancelDeleteUserBtn');
let currentUserId = null;

function openDeleteModal(event) {
    event.preventDefault();
    const btn = event.currentTarget;
    currentUserId = btn.getAttribute('data-user-id');
    deleteUserModal.style.display = 'block';
    deleteUserInput.value = '';
    confirmDeleteUserBtn.disabled = true;
}

deleteUserInput.addEventListener('input', function() {
    confirmDeleteUserBtn.disabled = deleteUserInput.value.toLowerCase() !== 'confirm delete';
});

cancelDeleteUserBtn.onclick = function() {
    deleteUserModal.style.display = 'none';
}

document.querySelector('.close-delete').onclick = function() {
    deleteUserModal.style.display = 'none';
}

confirmDeleteUserBtn.onclick = function() {
    if (currentUserId) {
        window.location.href = 'delete_user.php?id=' + currentUserId;
    }
}

window.onclick = function(event) {
    if (event.target == deleteUserModal) {
        deleteUserModal.style.display = 'none';
    }
}

function toggleDropdown(event) {
    event.preventDefault();
    document.querySelectorAll('.dropdown').forEach(drop => {
        if (!drop.contains(event.target)) drop.classList.remove('active');
    });
    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}
</script>
</body>
</html>