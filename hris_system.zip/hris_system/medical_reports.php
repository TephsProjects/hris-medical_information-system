<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

include 'generate_medical_notifications.php';

/**
 * PHASE 1 ONLY
 * - UI
 * - Filters
 * - Placeholders
 * - NO analytics queries yet
 */

// Capture filters (server-side, future use)
$from_date   = $_GET['from_date'] ?? '';
$to_date     = $_GET['to_date'] ?? '';
$role        = $_GET['role'] ?? '';
$organization= $_GET['organization'] ?? '';
$status      = $_GET['status'] ?? '';

// ===============================
// FILTER BUILDER
// ===============================
$whereStaff = [];
$whereSchedule = [];
$params = [];
$types = "";

// Role filter
if (!empty($role)) {
    $whereStaff[] = "ms.role = ?";
    $params[] = $role;
    $types .= "s";
}

// Organization filter
if (!empty($organization)) {
    $whereStaff[] = "ms.organization = ?";
    $params[] = $organization;
    $types .= "s";
}

// Status filter
if (!empty($status)) {
    $whereStaff[] = "ms.status = ?";
    $params[] = $status;
    $types .= "s";
}

// Date filters (for schedules)
if (!empty($from_date)) {
    $whereSchedule[] = "sch.duty_date >= ?";
    $params[] = $from_date;
    $types .= "s";
}

if (!empty($to_date)) {
    $whereSchedule[] = "sch.duty_date <= ?";
    $params[] = $to_date;
    $types .= "s";
}

// Convert to SQL
$whereStaffSql    = $whereStaff ? "WHERE " . implode(" AND ", $whereStaff) : "";
$whereScheduleSql = $whereSchedule ? "WHERE " . implode(" AND ", $whereSchedule) : "";

$sqlTotalStaff = "
    SELECT COUNT(*) AS total
    FROM medical_staff ms
    $whereStaffSql
";

$stmt = $conn->prepare($sqlTotalStaff);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$totalStaff = $stmt->get_result()->fetch_assoc()['total'] ?? 0;

$sqlTotalSchedules = "
    SELECT COUNT(*) AS total
    FROM medical_schedules sch
    JOIN medical_staff ms ON sch.staff_id = ms.staff_id
    $whereStaffSql
    " . ($whereSchedule ? "AND " . implode(" AND ", $whereSchedule) : "");

$stmt = $conn->prepare($sqlTotalSchedules);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$totalSchedules = $stmt->get_result()->fetch_assoc()['total'] ?? 0;

$sqlActiveStaff = "
    SELECT COUNT(*) AS total
    FROM medical_staff ms
    " . ($whereStaff ? $whereStaffSql . " AND ms.status = 'Active'" : "WHERE ms.status = 'Active'");

$stmt = $conn->prepare($sqlActiveStaff);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$activeStaff = $stmt->get_result()->fetch_assoc()['total'] ?? 0;

$sqlExpiredDocs = "
    SELECT COUNT(*) AS total
    FROM medical_staff_documents d
    JOIN medical_staff ms ON d.staff_id = ms.staff_id
    WHERE d.status = 'Expired'
";

if ($whereStaff) {
    $sqlExpiredDocs .= " AND " . implode(" AND ", $whereStaff);
}

$stmt = $conn->prepare($sqlExpiredDocs);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$expiredDocs = $stmt->get_result()->fetch_assoc()['total'] ?? 0;

$staffByRole = [];

$sql = "
    SELECT ms.role, COUNT(*) AS total
    FROM medical_staff ms
    $whereStaffSql
    GROUP BY ms.role
";

$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $staffByRole[] = $row;
}

$staffByOrg = [];

$sql = "
    SELECT ms.organization, COUNT(*) AS total
    FROM medical_staff ms
    $whereStaffSql
    GROUP BY ms.organization
";

$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $staffByOrg[] = $row;
}

$staffByStatus = [];

$sql = "
    SELECT ms.status, COUNT(*) AS total
    FROM medical_staff ms
    $whereStaffSql
    GROUP BY ms.status
";

$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $staffByStatus[] = $row;
}

$schedulesPerDay = [];

$sql = "
    SELECT sch.duty_date, COUNT(*) AS total
    FROM medical_schedules sch
    JOIN medical_staff ms ON sch.staff_id = ms.staff_id
    $whereStaffSql
    " . ($whereSchedule ? "AND " . implode(" AND ", $whereSchedule) : "") . "
    GROUP BY sch.duty_date
    ORDER BY sch.duty_date ASC
";

$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $schedulesPerDay[] = $row;
}

$staffScheduleSummary = [];

$sql = "
    SELECT ms.full_name, ms.role, COUNT(sch.schedule_id) AS total_schedules
    FROM medical_staff ms
    LEFT JOIN medical_schedules sch ON ms.staff_id = sch.staff_id
    $whereStaffSql
    GROUP BY ms.staff_id
    ORDER BY total_schedules DESC
";

$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $staffScheduleSummary[] = $row;
}

$staffNoSchedule = [];

$sql = "
    SELECT ms.full_name, ms.role, ms.organization
    FROM medical_staff ms
    WHERE ms.staff_id NOT IN (
        SELECT DISTINCT staff_id FROM medical_schedules
    )
";

if ($whereStaff) {
    $sql .= " AND " . implode(" AND ", $whereStaff);
}

$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $staffNoSchedule[] = $row;
}

// Fetch document status counts
$docStatus = [];
$sql = "SELECT status, COUNT(*) AS total FROM medical_staff_documents GROUP BY status";
$res = $conn->query($sql);
while($r = $res->fetch_assoc()) {
    $docStatus[] = $r;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Medical Reports</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/medical_reports.css">

    <!-- Chart.js (logic added in Phase 3) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

<!-- TOP NAVBAR (COPIED FROM medical_dashboard.php) -->
<div class="navbar">
    <h2>PulseWork: Medical Information System</h2>
    <div class="user-info">
        <div class="notification-wrapper">
            <button id="notificationBtn" class="notification-btn">
                🔔
                <span class="notification-badge" id="notificationCount">0</span>
            </button>
        </div>

        <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<!-- MEDICAL SUB NAVBAR -->
<nav class="sub-navbar">
    <ul class="nav-menu">
        <li><a href="medical_dashboard.php">Dashboard</a></li>
        <li><a href="medical_staff.php">Medical Staff</a></li>
        <li><a href="medical_schedule.php">Schedules</a></li>
        <li><a href="medical_reports.php" class="active">Reports</a></li>
    </ul>

    <div class="dashboard-switch">
        <a href="dashboard.php" class="switch-btn">
            👥 HR Dashboard
        </a>
    </div>
</nav>

<!-- MAIN CONTENT -->
<div class="main-content">

    <h2>📊 Medical Reports & Analytics</h2>

    <!-- FILTER PANEL -->
    <form method="GET" class="filter-panel" style="margin-bottom:20px;">
        <div class="filter-grid">

            <div>
                <label>From Date</label>
                <input type="date" name="from_date" value="<?= htmlspecialchars($from_date); ?>">
            </div>

            <div>
                <label>To Date</label>
                <input type="date" name="to_date" value="<?= htmlspecialchars($to_date); ?>">
            </div>

            <div>
                <label>Role</label>
                <input type="text" name="role" placeholder="Doctor, Nurse..."
                       value="<?= htmlspecialchars($role); ?>">
            </div>

            <div>
                <label>Organization</label>
                <input type="text" name="organization" placeholder="Hospital / Clinic"
                       value="<?= htmlspecialchars($organization); ?>">
            </div>

            <div>
                <label>Status</label>
                <select name="status">
                    <option value="">All</option>
                    <option value="Active" <?= $status=='Active'?'selected':''; ?>>Active</option>
                    <option value="On Leave" <?= $status=='On Leave'?'selected':''; ?>>On Leave</option>
                    <option value="Inactive" <?= $status=='Inactive'?'selected':''; ?>>Inactive</option>
                </select>
            </div>

            <div class="filter-actions">
                <button type="submit" class="btn">Apply Filters</button>
                <a href="export_medical_reports_excel.php?<?= http_build_query($_GET); ?>"
                   class="btn" style="background:#2e7d32;color:#fff;">
                    Export Excel
                </a>
            </div>
        </div>
    </form>

    <!-- SUMMARY CARDS -->
    <div class="dashboard-cards">

        <div class="card">
            <h3>Total Medical Staff</h3>
            <p class="card-value"><?= number_format($totalStaff); ?></p>
        </div>

        <div class="card">
            <h3>Total Schedules</h3>
            <p class="card-value"><?= number_format($totalSchedules); ?></p>
        </div>

        <div class="card">
            <h3>Active Staff</h3>
            <p class="card-value"><?= number_format($activeStaff); ?></p>
        </div>

        <div class="card">
            <h3>Expired Documents</h3>
            <p class="card-value"><?= number_format($expiredDocs); ?></p>
        </div>

    </div>

    <!-- ANALYTICS GRID -->
    <div class="dashboard-grid">

        <!-- CHART: STAFF BY ROLE -->
        <div class="dashboard-panel">
            <h3>Staff by Role</h3>
            <canvas id="staffByRoleChart" height="200"></canvas>
        </div>

        <!-- CHART: STAFF BY ORGANIZATION -->
        <div class="dashboard-panel">
            <h3>Staff by Organization</h3>
            <canvas id="staffByOrgChart" height="200"></canvas>
        </div>

        <!-- CHART: STAFF STATUS -->
        <div class="dashboard-panel">
            <h3>Staff Status Distribution</h3>
            <canvas id="staffStatusChart" height="200"></canvas>
        </div>

        <!-- CHART: SCHEDULES PER DAY -->
        <div class="dashboard-panel">
            <h3>Schedules per Day</h3>
            <canvas id="schedulePerDayChart" height="200"></canvas>
        </div>

        <div class="dashboard-panel">
            <h3>Medical Documents Status</h3>
            <canvas id="docStatusChart" height="200"></canvas>
        </div>
    </div>

    <!-- TABLE PLACEHOLDERS -->
    <div class="dashboard-panel">
        <h3>Staff Schedule Summary</h3>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Total Schedules</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($staffScheduleSummary): ?>
                    <?php foreach ($staffScheduleSummary as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['full_name']); ?></td>
                            <td><?= htmlspecialchars($row['role']); ?></td>
                            <td><?= $row['total_schedules']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="3" style="text-align:center;color:gray;">No data found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="dashboard-panel">
        <h3>Staff With No Assigned Schedules</h3>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Organization</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($staffNoSchedule): ?>
                    <?php foreach ($staffNoSchedule as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['full_name']); ?></td>
                            <td><?= htmlspecialchars($row['role']); ?></td>
                            <td><?= htmlspecialchars($row['organization']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="3" style="text-align:center;color:gray;">All staff have schedules 🎉</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<!-- NOTIFICATION MODAL -->
<div id="notificationModal" class="modal">
    <div class="modal-content" style="max-width:600px; max-height:70vh; overflow-y:auto; padding:20px;">
        <span class="close">&times;</span>
        <h3>🔔 Notifications</h3>
        <div id="notificationContent">
            <p style="color:gray;">Loading notifications...</p>
        </div>
    </div>
</div>

<!-- LOGOUT MODAL -->
<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<!-- SCRIPTS (COPIED, UNCHANGED) -->
<script>
const staffByRole = <?= json_encode($staffByRole); ?>;
const staffByOrg = <?= json_encode($staffByOrg); ?>;
const staffByStatus = <?= json_encode($staffByStatus); ?>;
const schedulesPerDay = <?= json_encode($schedulesPerDay); ?>;
const docStatus = <?= json_encode($docStatus); ?>;

new Chart(document.getElementById('docStatusChart'), {
    type: 'pie',
    data: {
        labels: docStatus.map(i => i.status),
        datasets: [{ data: docStatus.map(i => i.total) }]
    }
});

// STAFF BY ROLE
new Chart(document.getElementById('staffByRoleChart'), {
    type: 'pie',
    data: {
        labels: staffByRole.map(i => i.role),
        datasets: [{ data: staffByRole.map(i => i.total) }]
    }
});

// STAFF BY ORG
new Chart(document.getElementById('staffByOrgChart'), {
    type: 'bar',
    data: {
        labels: staffByOrg.map(i => i.organization),
        datasets: [{ data: staffByOrg.map(i => i.total) }]
    }
});

// STAFF STATUS
new Chart(document.getElementById('staffStatusChart'), {
    type: 'pie',
    data: {
        labels: staffByStatus.map(i => i.status),
        datasets: [{ data: staffByStatus.map(i => i.total) }]
    }
});

// SCHEDULES PER DAY
new Chart(document.getElementById('schedulePerDayChart'), {
    type: 'line',
    data: {
        labels: schedulesPerDay.map(i => i.duty_date),
        datasets: [{ data: schedulesPerDay.map(i => i.total), tension: 0.3 }]
    }
});

// Notifications
const notificationBtn = document.getElementById('notificationBtn');
const notificationModal = document.getElementById('notificationModal');
const notificationContent = document.getElementById('notificationContent');
const notificationCount = document.getElementById('notificationCount');

notificationBtn.onclick = function () {
    notificationModal.style.display = 'block';
    loadNotifications();
};

function loadNotifications() {
    fetch('fetch_notifications.php')
        .then(res => res.json())
        .then(data => {
            notificationContent.innerHTML = '';
            let totalUnread = 0;

            for (const section in data) {
                if (!data[section].length) continue;

                const title = document.createElement('div');
                title.className = 'notification-group-title';
                title.textContent = section;
                notificationContent.appendChild(title);

                data[section].forEach(item => {
                    const div = document.createElement('div');
                    div.className = 'notification-item';
                    div.dataset.id = item.id;
                    div.dataset.type = item.type;
                    div.dataset.staffId = item.staff_id;

                    // Create inner span for text
                    const textSpan = document.createElement('span');
                    textSpan.textContent = item.text;
                    div.appendChild(textSpan);

                    if (!item.read) {
                        div.classList.add('unread');
                        totalUnread++;

                        const dot = document.createElement('span');
                        dot.className = 'unread-dot';
                        div.appendChild(dot);
                    }

                    // Click to mark as read and redirect
                    div.addEventListener('click', function(e) {
                        e.stopPropagation(); // prevent bubbling to modal
                        if (!this.classList.contains('unread')) {
                            handleRedirect(this.dataset.type, this.dataset.staffId);
                            return;
                        }

                        fetch('mark_notification_read.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ id: this.dataset.id })
                        })
                        .then(res => res.json())
                        .then(resp => {
                            if (resp.success) {
                                this.classList.remove('unread');
                                // Remove dot if exists
                                const dot = this.querySelector('.unread-dot');
                                if(dot) dot.remove();
                                totalUnread--;
                                notificationCount.textContent = totalUnread;
                                handleRedirect(this.dataset.type, this.dataset.staffId);
                            }
                        });
                    });

                    notificationContent.appendChild(div);
                });
            }

            notificationCount.textContent = totalUnread;
            if (totalUnread === 0) {
                notificationContent.innerHTML = '<p style="color:gray;">No notifications today 🎉</p>';
            }
        });
}

// Redirect logic depending on type
function handleRedirect(type, staffId) {
    switch(type) {
        case 'medical_today':
        case 'medical_upcoming':
            // Go to the staff schedule page with staff ID
            window.location.href = `medical_schedule.php?staff_id=${staffId}`;
            break;

        case 'medical_missing':
            // Go to staff page to assign schedule
            window.location.href = `medical_staff.php?staff_id=${staffId}`;
            break;

        default:
            console.log('No redirect for type:', type);
    }
}

// Modal close logic
document.querySelectorAll('.modal .close').forEach(btn => {
    btn.onclick = function() {
        this.closest('.modal').style.display = 'none';
    }
});

window.onclick = function(event) {
    document.querySelectorAll('.modal').forEach(modal => {
        if(event.target === modal) modal.style.display = 'none';
    });
};

// Logout
const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e){
    e.preventDefault();
    logoutModal.style.display = 'block';
}
cancelLogout.onclick = function(){ logoutModal.style.display = 'none'; }
confirmLogout.onclick = function(){ window.location.href = 'logout.php'; }
</script>

</body>
</html>
