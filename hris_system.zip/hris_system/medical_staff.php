<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

include 'generate_medical_notifications.php';

$result = $conn->query("
    SELECT staff_id, full_name, role, organization, schedule, status
    FROM medical_staff
    ORDER BY created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Medical Staff</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<style>
    /* =========================
   MODAL OVERLAY
========================= */
.modal {
    display: none;
    position: fixed;
    z-index: 1100;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.55);
    animation: fadeIn 0.25s ease;
}

/* Fade animation */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* =========================
   MODAL CONTENT
========================= */
.modal-content {
    background: #ffffff;
    margin: 5% auto;
    padding: 22px;
    border-radius: 12px;
    width: 92%;
    max-width: 520px;
    box-shadow: 0 12px 30px rgba(0,0,0,0.3);
    position: relative;
    animation: slideDown 0.35s ease;
}

/* Slide animation */
@keyframes slideDown {
    from {
        transform: translateY(-40px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

/* =========================
   MODAL HEADER
========================= */
.modal-content h3 {
    margin: 0 0 15px;
    text-align: center;
    font-size: 1.3em;
    color: #1f2937;
}

/* =========================
   CLOSE BUTTON
========================= */
.modal .close {
    position: absolute;
    top: 12px;
    right: 15px;
    font-size: 26px;
    color: #555;
    cursor: pointer;
    transition: color 0.2s ease, transform 0.15s ease;
}

.modal .close:hover {
    color: #dc3545;
    transform: scale(1.1);
}

/* =========================
   FORM FIELDS
========================= */
.modal-content label {
    font-size: 0.85em;
    font-weight: 600;
    color: #374151;
    margin-bottom: 4px;
    display: block;
}

.modal-content input,
.modal-content select {
    width: 100%;
    padding: 8px 10px;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    font-size: 0.95em;
    margin-bottom: 12px;
    transition: border-color 0.2s, box-shadow 0.2s;
}

.modal-content input:focus,
.modal-content select:focus {
    border-color: #378006;
    box-shadow: 0 0 0 2px rgba(55,128,6,0.25);
    outline: none;
}

/* =========================
   BUTTONS
========================= */
.modal-content .btn {
    padding: 9px 16px;
    border-radius: 6px;
    border: none;
    font-size: 0.95em;
    cursor: pointer;
    transition: background 0.2s ease, transform 0.15s ease;
}

.modal-content .btn:hover {
    transform: translateY(-1px);
    opacity: 0.95;
}

/* Center buttons in confirmation modals */
#confirmAddModal .modal-content,
#confirmEditModal .modal-content {
    text-align: center;
}

#confirmAddModal .btn,
#confirmEditModal .btn {
    min-width: 90px;
    margin-top: 10px;
}

/* =========================
   STATUS BADGES (BONUS)
========================= */
.status {
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 0.75em;
    font-weight: 600;
    display: inline-block;
}

.status.active {
    background: #e6f4ea;
    color: #137333;
}

.status.inactive {
    background: #fdecea;
    color: #a50e0e;
}

.status.on-leave {
    background: #fff4e5;
    color: #92400e;
}

/* =========================
   MOBILE FRIENDLY
========================= */
@media (max-width: 480px) {
    .modal-content {
        margin: 10% auto;
        padding: 18px;
    }

    .modal-content h3 {
        font-size: 1.15em;
    }
}
</style>
<body>

<!-- TOP NAVBAR (reuse exactly) -->
<div class="navbar">
    <h2>PulseWork: Medical Information System</h2>
    <div class="user-info">
            <div class="notification-wrapper">
                <button id="notificationBtn" class="notification-btn">
                    🔔
                    <span class="notification-badge" id="notificationCount">0</span>
                </button>
            </div>

            <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?></span>
            <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
        </div>
</div>

<!-- MEDICAL SUB NAVBAR (simplified) -->
<nav class="sub-navbar">
    <ul class="nav-menu">
        <li><a href="medical_dashboard.php">Dashboard</a></li>
        <li><a href="medical_staff.php" class="active">Medical Staff</a></li>
        <li><a href="medical_schedule.php">Schedules</a></li>
        <li><a href="medical_reports.php">Reports</a></li>
    </ul>

     <div class="dashboard-switch">
            <a href="dashboard.php" class="switch-btn">
                👥 HR Dashboard
            </a>
     </div>
</nav>

<div class="main-content">
    <div class="container">
        <h2>🏥 Medical Staff</h2>

        <div style="margin-bottom: 15px;">
            <button id="addStaffBtn" class="btn" style="background:#378006; color:#fff;">➕ Add Medical Staff</button>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Role</th>
                    <th>Organization</th>
                    <th>Schedule</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php $i = 1; while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= htmlspecialchars($row['full_name']) ?></td>
                        <td><?= $row['role'] ?></td>
                        <td><?= $row['organization'] ?: '-' ?></td>
                        <td><?= $row['schedule'] ?: '-' ?></td>
                        <td>
                            <span class="status <?= strtolower(str_replace(' ', '-', $row['status'])) ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td>
                            <button class="btn editStaffBtn" 
                                    data-id="<?= $row['staff_id'] ?>"
                                    data-full_name="<?= htmlspecialchars($row['full_name']) ?>"
                                    data-role="<?= htmlspecialchars($row['role']) ?>"
                                    data-organization="<?= htmlspecialchars($row['organization']) ?>"
                                    data-schedule="<?= htmlspecialchars($row['schedule']) ?>"
                                    data-status="<?= $row['status'] ?>"
                                    style="background:#007BFF; color:#fff; margin-right:5px;">
                                Edit
                            </button>
                            <button class="btn deleteStaffBtn" 
                                    data-id="<?= $row['staff_id'] ?>"
                                    style="background:#dc3545; color:#fff;">
                                Delete
                            </button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" style="text-align:center; color:gray;">
                        No medical staff found
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ADD STAFF MODAL -->
<div id="addStaffModal" class="modal">
    <div class="modal-content" style="max-width:500px; padding:20px;">
        <span class="close" onclick="closeAddStaffModal()">&times;</span>
        <h3>Add Medical Staff</h3>
        <form id="addStaffForm">
            <label>Full Name:</label>
            <input type="text" name="full_name" required style="width:100%; margin-bottom:10px; padding:5px;">

            <label>Role:</label>
            <input type="text" name="role" required style="width:100%; margin-bottom:10px; padding:5px;">

            <label>Organization:</label>
            <input type="text" name="organization" style="width:100%; margin-bottom:10px; padding:5px;">

            <label>Schedule:</label>
            <input type="text" name="schedule" placeholder="Optional" style="width:100%; margin-bottom:10px; padding:5px;">

            <label>Status:</label>
            <select name="status" required style="width:100%; margin-bottom:10px; padding:5px;">
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
            </select>

            <button type="button" id="submitAddStaff" class="btn" style="background:#378006; color:#fff;">Submit</button>
        </form>
    </div>
</div>

<!-- EDIT STAFF MODAL -->
<div id="editStaffModal" class="modal">
    <div class="modal-content" style="max-width:500px; padding:20px;">
        <span class="close" onclick="closeEditStaffModal()">&times;</span>
        <h3>Edit Medical Staff</h3>
        <form id="editStaffForm">
            <input type="hidden" name="staff_id" id="edit_staff_id">

            <label>Full Name:</label>
            <input type="text" name="full_name" id="edit_full_name" required style="width:100%; margin-bottom:10px; padding:5px;">

            <label>Role:</label>
            <input type="text" name="role" id="edit_role" required style="width:100%; margin-bottom:10px; padding:5px;">

            <label>Organization:</label>
            <input type="text" name="organization" id="edit_organization" style="width:100%; margin-bottom:10px; padding:5px;">

            <label>Schedule:</label>
            <input type="text" name="schedule" id="edit_schedule" placeholder="Optional" style="width:100%; margin-bottom:10px; padding:5px;">

            <label>Status:</label>
            <select name="status" id="edit_status" required style="width:100%; margin-bottom:10px; padding:5px;">
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="On Leave">On Leave</option>
            </select>

            <button type="button" id="submitEditStaff" class="btn" style="background:#007BFF; color:#fff;">Save Changes</button>
        </form>
    </div>
</div>

<div id="confirmEditModal" class="modal">
    <div class="modal-content" style="max-width:400px; padding:20px; text-align:center;">
        <span class="close" onclick="closeConfirmEditModal()">&times;</span>
        <h3>Confirm Action</h3>
        <p id="confirmEditMessage">Are you sure?</p>
        <button id="confirmEditBtn" class="btn" style="background:#007BFF; color:#fff; margin-right:10px;">Yes</button>
        <button id="cancelEditBtn" class="btn" style="background:#ccc; color:#333;">Cancel</button>
    </div>
</div>

<!-- CONFIRMATION MODAL -->
<div id="confirmAddModal" class="modal">
    <div class="modal-content" style="max-width:400px; padding:20px; text-align:center;">
        <span class="close" onclick="closeConfirmAddModal()">&times;</span>
        <h3>Confirm Submission</h3>
        <p>Are you sure you want to add this medical staff?</p>
        <button id="confirmAddBtn" class="btn" style="background:#378006; color:#fff; margin-right:10px;">Yes</button>
        <button id="cancelAddBtn" class="btn" style="background:#ccc; color:#333;">Cancel</button>
    </div>
</div>

<div id="notificationModal" class="modal">
        <div class="modal-content" style="max-width:600px; max-height:70vh; overflow-y:auto; padding:20px;">
            <span class="close" onclick="closeNotificationModal()">&times;</span>
            <h3>🔔 Notifications</h3>

            <div id="notificationContent">
                <p style="color:gray;">Loading notifications...</p>
            </div>
        </div>
    </div>

    <div id="logoutModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Confirm Logout</h3>
            <p>Are you sure you want to logout?</p>
            <div class="modal-buttons">
                <button id="confirmLogout" class="btn">Yes, Logout</button>
                <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
            </div>
        </div>
    </div>

<script>
    // Open Edit Modal
    document.querySelectorAll('.editStaffBtn').forEach(btn => {
        btn.onclick = function() {
            const modal = document.getElementById('editStaffModal');
            document.getElementById('edit_staff_id').value = this.dataset.id;
            document.getElementById('edit_full_name').value = this.dataset.full_name;
            document.getElementById('edit_role').value = this.dataset.role;
            document.getElementById('edit_organization').value = this.dataset.organization;
            document.getElementById('edit_schedule').value = this.dataset.schedule;
            document.getElementById('edit_status').value = this.dataset.status;

            modal.style.display = 'block';
        };
    });

    function closeEditStaffModal() {
        document.getElementById('editStaffModal').style.display = 'none';
    }

    // Edit confirmation modal
    const submitEditStaff = document.getElementById('submitEditStaff');
    const confirmEditModal = document.getElementById('confirmEditModal');
    const confirmEditBtn = document.getElementById('confirmEditBtn');
    const cancelEditBtn = document.getElementById('cancelEditBtn');
    const confirmEditMessage = document.getElementById('confirmEditMessage');

    submitEditStaff.onclick = function() {
        confirmEditMessage.textContent = "Are you sure you want to save changes?";
        confirmEditModal.style.display = 'block';
    };

    cancelEditBtn.onclick = function() {
        confirmEditModal.style.display = 'none';
    };

    confirmEditBtn.onclick = function() {
        const form = document.getElementById('editStaffForm');
        const formData = new FormData(form);

        fetch('edit_medical_staff.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if(data.success){
                alert('Medical staff updated successfully!');
                location.reload();
            } else {
                alert('Failed to update staff: ' + data.message);
            }
        })
        .catch(() => alert('Error submitting the form.'));
    };

    document.querySelectorAll('.deleteStaffBtn').forEach(btn => {
        btn.onclick = function() {
            const staffId = this.dataset.id;
            confirmEditMessage.textContent = "Are you sure you want to delete this staff?";
            confirmEditModal.style.display = 'block';

            confirmEditBtn.onclick = function() {
                fetch('delete_medical_staff.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ staff_id: staffId })
                })
                .then(res => res.json())
                .then(data => {
                    if(data.success){
                        alert('Staff deleted successfully!');
                        location.reload();
                    } else {
                        alert('Failed to delete staff: ' + data.message);
                    }
                })
                .catch(() => alert('Error deleting staff.'));
            };
        };
    });

    // Open Add Staff modal
    const addStaffBtn = document.getElementById('addStaffBtn');
    const addStaffModal = document.getElementById('addStaffModal');
    const confirmAddModal = document.getElementById('confirmAddModal');
    const submitAddStaff = document.getElementById('submitAddStaff');
    const confirmAddBtn = document.getElementById('confirmAddBtn');
    const cancelAddBtn = document.getElementById('cancelAddBtn');

    addStaffBtn.onclick = function() {
        addStaffModal.style.display = 'block';
    }

    function closeAddStaffModal() {
        addStaffModal.style.display = 'none';
    }

    function closeConfirmAddModal() {
        confirmAddModal.style.display = 'none';
    }

    // When clicking submit in add staff modal, open confirmation modal
    submitAddStaff.onclick = function() {
        confirmAddModal.style.display = 'block';
    }

    // Cancel confirmation
    cancelAddBtn.onclick = function() {
        closeConfirmAddModal();
    }

    // Confirm submission
    confirmAddBtn.onclick = function() {
        const form = document.getElementById('addStaffForm');
        const formData = new FormData(form);

        fetch('add_medical_staff.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if(data.success){
                alert('Medical staff added successfully!');
                location.reload(); // reload to see new staff
            } else {
                alert('Failed to add staff: ' + data.message);
            }
        })
        .catch(() => alert('Error submitting the form.'));
    }

    const notificationBtn = document.getElementById('notificationBtn');
    const notificationModal = document.getElementById('notificationModal');
    const notificationContent = document.getElementById('notificationContent');
    const notificationCount = document.getElementById('notificationCount');

    notificationBtn.onclick = function () {
        notificationModal.style.display = 'block';
        loadNotifications();
    };

    function loadNotifications() {
        fetch('fetch_notifications.php')
            .then(res => res.json())
            .then(data => {
                notificationContent.innerHTML = '';
                let total = 0;

                for (const section in data) {
                    if (!data[section].length) continue;

                    // Section title
                    const title = document.createElement('div');
                    title.className = 'notification-group-title';
                    title.textContent = section;
                    notificationContent.appendChild(title);

                    data[section].forEach(item => {
                        total++;

                        // Create notification div
                        const div = document.createElement('div');
                        div.className = 'notification-item';
                        div.innerHTML = item.text;

                        // Mark unread notifications
                        if (!item.read) {
                            div.classList.add('unread'); // style this in CSS
                            const dot = document.createElement('span');
                            dot.className = 'unread-dot';
                            div.appendChild(dot);
                        }

                        // Click to mark as read
                        div.onclick = () => markAsRead(item.id, div);

                        notificationContent.appendChild(div);
                    });
                }

                notificationCount.textContent = total || 0;

                if (total === 0) {
                    notificationContent.innerHTML = '<p style="color:gray;">No notifications today 🎉</p>';
                }
            })
            .catch(() => {
                notificationContent.innerHTML = '<p style="color:red;">Error loading notifications</p>';
            });
    }

    // Mark notification as read
    function markAsRead(id, element) {
        fetch('mark_notification_read.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        })
        .then(res => res.json())
        .then(resp => {
            if (resp.success) {
                element.classList.remove('unread');
                const dot = element.querySelector('.unread-dot');
                if (dot) dot.remove();
            }
        });
    }

    // ✅ Make all modal close buttons work
    document.querySelectorAll('.modal .close').forEach(btn => {
        btn.onclick = function() {
            this.closest('.modal').style.display = 'none';
        }
    });

    // Close modal when clicking outside
    window.onclick = function(event) {
        document.querySelectorAll('.modal').forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    };
    
    const logoutBtn = document.getElementById('logoutBtn');
    const logoutModal = document.getElementById('logoutModal');
    const closeModal = document.querySelector('.close');
    const cancelLogout = document.getElementById('cancelLogout');
    const confirmLogout = document.getElementById('confirmLogout');

    logoutBtn.onclick = function(e) {
        e.preventDefault();
        logoutModal.style.display = 'block';
    }

    cancelLogout.onclick = function() {
        logoutModal.style.display = 'none';
    }

    confirmLogout.onclick = function() {
        window.location.href = 'logout.php';
    }

    window.onclick = function(event) {
        if (event.target == logoutModal) {
            logoutModal.style.display = 'none';
        }
    }
</script>
</body>
</html>
