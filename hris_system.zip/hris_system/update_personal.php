<?php
session_start();
include 'includes/db.php';

if (!isset($_POST['emp_id'])) exit('Invalid request');

$emp_id = $_POST['emp_id'];

$stmt = $conn->prepare("
    UPDATE employees 
    SET first_name = ?, 
        middle_name = ?, 
        last_name = ?, 
        name_suffix = ?, 
        date_of_birth = ?, 
        place_of_birth = ?, 
        gender = ?, 
        civil_status = ?, 
        nationality = ?, 
        religion = ?, 
        spouse_name = ?, 
        blood_type = ?, 
        medical_notes = ?, 
        address = ?,
        father_name = ?,
        father_occupation = ?,
        mother_name = ?,
        mother_occupation = ?,
        guardian_name = ?,
        guardian_contact = ?
    WHERE emp_id = ?
");

$stmt->bind_param(
    "ssssssssssssssssssssi",
    $_POST['first_name'],
    $_POST['middle_name'],
    $_POST['last_name'],
    $_POST['name_suffix'],
    $_POST['date_of_birth'],
    $_POST['place_of_birth'],
    $_POST['gender'],
    $_POST['civil_status'],
    $_POST['nationality'],
    $_POST['religion'],
    $_POST['spouse_name'],
    $_POST['blood_type'],
    $_POST['medical_notes'],
    $_POST['address'],
    $_POST['father_name'],
    $_POST['father_occupation'],
    $_POST['mother_name'],
    $_POST['mother_occupation'],
    $_POST['guardian_name'],
    $_POST['guardian_contact'],
    $emp_id
);

$stmt->execute();

header("Location: employee_personal.php?id=$emp_id&updated=1");
exit();
?>
