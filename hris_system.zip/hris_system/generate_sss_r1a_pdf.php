<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $company_name  = $_POST['company_name'] ?? '';
    $address       = $_POST['address'] ?? '';
    $postal_code   = $_POST['postal_code'] ?? '';
    $sss_number    = $_POST['sss_number'] ?? '';
    $employer_type = $_POST['employer_type'] ?? '';
    $report_type   = $_POST['report_type'] ?? '';
    $signatory     = $_POST['signatory'] ?? '';
    $designation = $_POST['designation'] ?? '';
    $report_date   = $_POST['report_date'] ?? date('Y-m-d');
    $start_date = $_POST['start_date'] ?? '';
    $end_date   = $_POST['end_date'] ?? '';
} else {
    die("Form data not submitted.");
}

/* ===============================
   FETCH EMPLOYEES WITH DATE FILTER
================================ */
$empQuery = "
    SELECT 
        sss_no,
        first_name,
        middle_name,
        last_name,
        name_suffix,
        date_of_birth,
        date_hired,
        position
    FROM employees
    WHERE sss_no IS NOT NULL
";

$params = [];
$types = '';

if (!empty($start_date) && !empty($end_date)) {
    $empQuery .= " AND date_hired BETWEEN ? AND ?";
    $params[] = $start_date;
    $params[] = $end_date;
    $types .= 'ss';
}

$empQuery .= " ORDER BY last_name, first_name LIMIT 15";

$empStmt = $conn->prepare($empQuery);

if (!empty($params)) {
    $empStmt->bind_param($types, ...$params);
}

$empStmt->execute();
$employees = $empStmt->get_result()->fetch_all(MYSQLI_ASSOC);

if (!$employees) {
    die('No employees found for the selected date range.');
}

// Example: count all active employees
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM employees WHERE employment_status = 'active'");
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$totalEmployees = $row['total'] ?? 0;

require_once __DIR__ . '/vendor/tecnickcom/tcpdf/tcpdf.php';

$pdf = new TCPDF('L', 'mm', 'Letter', true, 'UTF-8', false);
$pdf->SetCreator('PulseWork HRIS');
$pdf->SetAuthor('PulseWork');
$pdf->SetTitle('SSS Form R-1A');
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Margins
$pdf->SetMargins(10, 10, 10);
$pdf->SetAutoPageBreak(false);

$pdf->AddPage();

/* ======================================================
   PAGE BORDER
====================================================== */
$pageWidth  = $pdf->getPageWidth();
$pageHeight = $pdf->getPageHeight();

// Outer border
$pdf->Rect(10, 10, $pageWidth - 20, $pageHeight - 20);

/* ======================================================
   HEADER BORDER
====================================================== */
$headerHeight = 30;
$pdf->Rect(10, 10, $pageWidth - 20, $headerHeight);

/* ======================================================
   HEADER CONTENT
====================================================== */

// Logo (replace with actual path later)
$logoPath = __DIR__ . '/assets/images/sss.png';
if (file_exists($logoPath)) {
    $pdf->Image($logoPath, 14, 14, 28);
}

// R-1A label
$pdf->SetFont('helvetica', 'B', 20);
$pdf->SetXY(45, 16);
$pdf->Cell(25, 10, 'R-1A', 0, 0, 'L');

// Center Header Text
$centerX = ($pageWidth / 2) - 40;

$pdf->SetXY($centerX, 14);
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(80, 5, 'Republic of the Philippines', 0, 1, 'C');

$pdf->SetX($centerX);
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Cell(80, 8, 'SOCIAL SECURITY SYSTEM', 0, 1, 'C');

$pdf->SetX($centerX);
$pdf->SetFont('helvetica', 'B', 20);
$pdf->Cell(80, 7, 'EMPLOYMENT FORM', 0, 1, 'C');

$pdf->SetX($centerX);
$pdf->SetFont('helvetica', '', 8);
$pdf->Cell(80, 5, '(Please read instructions/reminders at the back. Print all information in black ink.)', 0, 1, 'C');

/* ======================================================
   EMPLOYER INFORMATION ROW (UPDATED FROM FORM INPUT)
====================================================== */

$startY = 10 + $headerHeight;
$rowHeight = 18;

// Outer border
$pdf->Rect(10, $startY, $pageWidth - 20, $rowHeight);

// Column widths
$col1 = 65;   // Employer/SS No
$col2 = 135;  // Employer Name
$col3 = 35;   // Type of Employer
$col4 = $pageWidth - 20 - ($col1 + $col2 + $col3); // Type of Report

$x = 10;

// Vertical dividers
$pdf->Line($x + $col1, $startY, $x + $col1, $startY + $rowHeight);
$pdf->Line($x + $col1 + $col2, $startY, $x + $col1 + $col2, $startY + $rowHeight);
$pdf->Line($x + $col1 + $col2 + $col3, $startY, $x + $col1 + $col2 + $col3, $startY + $rowHeight);

// Column 1: Employer/SS Number
$pdf->SetFont('helvetica', 'B', 9.5);
$pdf->SetXY($x + 2, $startY + 2);
$pdf->Cell($col1 - 4, 5, 'Employer/SS Number', 0, 0);

// Column 1: Employer/SS Number
$pdf->SetFont('helvetica', 'B', 10);

// Guide lines (12 vertical)
$lines = 12;
$lineHeight = 5;
$bottomY = $startY + $rowHeight;
$topY = $bottomY - $lineHeight;
$usableWidth = $col1 - 10;
$spacing = $usableWidth / ($lines - 1);

// Draw vertical lines
for ($i = 0; $i < $lines; $i++) {
    $lineX = $x + 5 + ($i * $spacing);
    $pdf->Line($lineX, $topY, $lineX, $bottomY);
}

// Place each digit exactly **between the lines**
$sss_number_text = $sss_number ?? '';
$digits = str_split($sss_number_text);

for ($i = 0; $i < $lines; $i++) {
    $digit = $digits[$i] ?? '';

    // midpoint between line i and line i+1
    $cellX = $x + 5 + ($i * $spacing) + ($spacing / 2) - 2; // -2 to adjust for horizontal center
    $cellY = $topY + ($lineHeight / 2) - 2; // vertical center

    // Center digit in the gap
    $pdf->SetXY($cellX, $cellY);
    $pdf->Cell($spacing, 5, $digit, 0, 0, 'C');
}

// Column 2: Employer Name
$pdf->SetFont('helvetica', 'B', 9.5);
$pdf->SetXY($x + $col1 + 2, $startY + 2);
$pdf->Cell($col2 - 4, 5, 'Name of Business / Employer', 0, 0);

$pdf->SetFont('helvetica', 'B', 9);
$pdf->SetXY($x + $col1 + 2, $startY + 12);
$pdf->Cell($col2 - 4, 5, strtoupper($company_name), 0, 0, 'C');

// Column 3: Type of Employer (checkboxes)
$pdf->SetFont('helvetica', 'B', 8);
$pdf->SetXY($x + $col1 + $col2 + 2, $startY + 2);
$pdf->Cell($col3 - 4, 5, 'Type of Employer', 0, 0);

$box = 3.5;
$bottomY = $startY + $rowHeight;
$firstBoxY  = $bottomY - 12;
$secondBoxY = $bottomY - 6;

// Check based on submitted value
if ($employer_type === 'Regular') {
    $pdf->Rect($x + $col1 + $col2 + 6, $firstBoxY, $box, $box, 'DF'); // Filled box
    $pdf->Rect($x + $col1 + $col2 + 6, $secondBoxY, $box, $box);      // empty
} else {
    $pdf->Rect($x + $col1 + $col2 + 6, $firstBoxY, $box, $box);       // empty
    $pdf->Rect($x + $col1 + $col2 + 6, $secondBoxY, $box, $box, 'DF'); // filled
}

// Labels
$pdf->SetXY($x + $col1 + $col2 + 12, $firstBoxY - 0.5);
$pdf->Cell(30, 4, 'Regular', 0, 0);
$pdf->SetXY($x + $col1 + $col2 + 12, $secondBoxY - 0.5);
$pdf->Cell(40, 4, 'Household (HR)', 0, 0);

// Column 4: Type of Report (checkboxes)
$pdf->SetFont('helvetica', 'B', 8);
$pdf->SetXY($x + $col1 + $col2 + $col3 + 2, $startY + 2);
$pdf->Cell($col4 - 4, 5, 'Type of Report', 0, 0);

$firstBoxY  = $bottomY - 12;
$secondBoxY = $bottomY - 6;

if ($report_type === 'Initial') {
    $pdf->Rect($x + $col1 + $col2 + $col3 + 6, $firstBoxY, $box, $box, 'DF'); // filled
    $pdf->Rect($x + $col1 + $col2 + $col3 + 6, $secondBoxY, $box, $box);      // empty
} else {
    $pdf->Rect($x + $col1 + $col2 + $col3 + 6, $firstBoxY, $box, $box);       // empty
    $pdf->Rect($x + $col1 + $col2 + $col3 + 6, $secondBoxY, $box, $box, 'DF'); // filled
}

// Labels
$pdf->SetXY($x + $col1 + $col2 + $col3 + 12, $firstBoxY - 0.5);
$pdf->Cell(30, 4, 'Initial', 0, 0);
$pdf->SetXY($x + $col1 + $col2 + $col3 + 12, $secondBoxY - 0.5);
$pdf->Cell(30, 4, 'Subsequent', 0, 0);

/* ======================================================
   TELEPHONE / ADDRESS / POSTAL CODE ROW (FROM FORM)
====================================================== */

$startY2   = $startY + $rowHeight;
$rowHeight2 = 14;

// Outer border
$pdf->Rect(10, $startY2, $pageWidth - 20, $rowHeight2);

// Column widths
$telCol     = 65;   // Area Code / Telephone
$addressCol = 185;  // Business Address
$postalCol  = $pageWidth - 20 - ($telCol + $addressCol);

$x = 10;

// Vertical dividers
$pdf->Line($x + $telCol, $startY2, $x + $telCol, $startY2 + $rowHeight2);
$pdf->Line($x + $telCol + $addressCol, $startY2, $x + $telCol + $addressCol, $startY2 + $rowHeight2);

// Column 1: Area Code / Telephone
$pdf->SetFont('helvetica', 'B', 9);
$pdf->SetXY($x + 2, $startY2 + 2);
$pdf->Cell($telCol - 4, 5, 'Area Code / Telephone Number', 0, 0);

// Column 2: Business Address
$pdf->SetFont('helvetica', 'B', 9);
$pdf->SetXY($x + $telCol + 2, $startY2 + 9);
$pdf->Cell($addressCol - 4, 5, strtoupper($address), 0, 0, 'C');

// Column 3: Postal Code
$pdf->SetFont('helvetica', 'B', 9);
$pdf->SetXY($x + $telCol + $addressCol + 2, $startY2 + 2);
$pdf->Cell($postalCol - 4, 5, 'Postal Code', 0, 0);

// Number of vertical lines and digits
$lines = 5; // number of vertical lines
$digits = str_split($postal_code ?? ''); // e.g., '1234'
$numDigits = count($digits);

// Vertical guide line coordinates
$bottomY = $startY2 + $rowHeight2;
$lineHeight = 5;
$topY = $bottomY - $lineHeight;
$usableWidth = $postalCol - 6;
$spacing = $usableWidth / ($lines - 1);

// Draw vertical lines
for ($i = 0; $i < $lines; $i++) {
    $lineX = $x + $telCol + $addressCol + 5 + ($i * $spacing);
    $pdf->Line($lineX, $topY, $lineX, $bottomY);
}

// Place each digit in the **center of the gap between lines**
$gaps = $lines - 1; // number of gaps
for ($i = 0; $i < $numDigits && $i < $gaps; $i++) {
    $digit = $digits[$i];

    // midpoint of gap i
    $gapStartX = $x + $telCol + $addressCol + 5 + ($i * $spacing);
    $cellX = $gapStartX + ($spacing / 2) - 1.5; // adjust -1.5 for horizontal centering
    $cellY = $topY + ($lineHeight / 2) - 2;      // vertical centering

    $pdf->SetXY($cellX, $cellY);
    $pdf->Cell($spacing, 5, $digit, 0, 0, 'C');
}

/* ======================================================
   EMPLOYEE INFORMATION HEADER ROW
====================================================== */

$startY3    = $startY2 + $rowHeight2;
$rowHeight3 = 14;

// Column widths
$ssCol      = 30;
$nameCol    = 60;
$dobCol     = 25;
$doeCol     = 30;
$salaryCol  = 25;
$positionCol= 35;
$relCol     = 25;
$sssUseCol  = $pageWidth - 20 - (
    $ssCol + $nameCol + $dobCol + $doeCol +
    $salaryCol + $positionCol + $relCol
);

$x = 10;

// Outer border
$pdf->Rect($x, $startY3, $pageWidth - 20, $rowHeight3);

// Vertical dividers
$cols = [
    $ssCol,
    $nameCol,
    $dobCol,
    $doeCol,
    $salaryCol,
    $positionCol,
    $relCol
];

$cursorX = $x;
foreach ($cols as $w) {
    $cursorX += $w;
    $pdf->Line($cursorX, $startY3, $cursorX, $startY3 + $rowHeight3);
}

/* ===============================
   Header Fonts
================================ */
$pdf->SetFont('helvetica', 'B', 8);

/* ===============================
   Column 1: SS Number
================================ */
$pdf->SetXY($x + 2, $startY3 + 4);
$pdf->Cell($ssCol - 4, 5, 'SS Number', 0, 0, 'C');

/* ===============================
   Column 2: Name of Employee
================================ */
$pdf->SetXY($x + $ssCol + 2, $startY3 + 2);
$pdf->Cell($nameCol - 4, 5, 'Name of Employee', 0, 0, 'C');

$pdf->SetFont('helvetica', '', 7);
$pdf->SetXY($x + $ssCol + 2, $startY3 + 10);
$pdf->Cell($nameCol - 4, 4, '(Surname)      (Given Name)      (Middle Name)', 0, 0, 'C');

/* ===============================
   Column 3: Date of Birth
================================ */
$pdf->SetFont('helvetica', 'B', 8);
$pdf->SetXY($x + $ssCol + $nameCol + 2, $startY3 + 2);
$pdf->Cell($dobCol - 4, 5, 'Date of Birth', 0, 0, 'C');

$pdf->SetFont('helvetica', '', 7);
$pdf->SetXY($x + $ssCol + $nameCol + 2, $startY3 + 10);
$pdf->Cell($dobCol - 4, 4, '(mm/dd/yyyy)', 0, 0, 'C');

/* ===============================
   Column 4: Date of Employment
================================ */
$pdf->SetFont('helvetica', 'B', 8);
$pdf->SetXY($x + $ssCol + $nameCol + $dobCol + 2, $startY3 + 2);
$pdf->Cell($doeCol - 4, 5, 'Date of Employment', 0, 0, 'C');

$pdf->SetFont('helvetica', '', 7);
$pdf->SetXY($x + $ssCol + $nameCol + $dobCol + 2, $startY3 + 10);
$pdf->Cell($doeCol - 4, 4, '(mm/dd/yyyy)', 0, 0, 'C');

/* ===============================
   Column 5: Monthly Earnings
================================ */
$pdf->SetFont('helvetica', 'B', 8);
$pdf->SetXY($x + $ssCol + $nameCol + $dobCol + $doeCol + 2, $startY3 + 2);
$pdf->Cell($salaryCol - 4, 5, 'Monthly Earnings', 0, 0, 'C');

/* ===============================
   Column 6: Position
================================ */
$pdf->SetXY($x + $ssCol + $nameCol + $dobCol + $doeCol + $salaryCol + 2, $startY3 + 4);
$pdf->Cell($positionCol - 4, 5, 'Position', 0, 0, 'C');

/* ===============================
   Column 7: Relationship with Owner / HR
================================ */
$pdf->SetXY(
    $x + $ssCol + $nameCol + $dobCol + $doeCol + $salaryCol + $positionCol + 2,
    $startY3 + 3
);
$pdf->MultiCell(
    $relCol - 4,
    4,
    "Relationship\nwith Owner / HR",
    0,
    'C'
);

/* ===============================
   Column 8: For SSS Use
================================ */
$pdf->SetXY(
    $x + $ssCol + $nameCol + $dobCol + $doeCol +
    $salaryCol + $positionCol + $relCol + 2,
    $startY3 + 4
);
$pdf->Cell($sssUseCol - 4, 5, 'For SSS Use', 0, 0, 'C');

/* ======================================================
   EMPLOYEE ROWS (15 rows) WITH NUMBERING
====================================================== */

$numRows = 15;         // Number of rows
$rowHeight  = 6;      // Height per row
$startYRow  = $startY3 + $rowHeight3; // Start just below header

$pdf->SetFont('helvetica', '', 7); // Small font for table

$employeeCount     = count($employees);
$nothingFollowsRow = ($employeeCount < $numRows) ? $employeeCount : -1;

for ($r = 0; $r < $numRows; $r++) {

    $currentY = $startYRow + ($r * $rowHeight);

    // Draw row border
    $pdf->Rect($x, $currentY, $pageWidth - 20, $rowHeight);

    // Vertical dividers
    $cursorX = $x;
    foreach ($cols as $w) {
        $cursorX += $w;
        $pdf->Line($cursorX, $currentY, $cursorX, $currentY + $rowHeight);
    }

    // Row number
    $pdf->SetXY($x + 1, $currentY + 1);
    $pdf->Cell(5, $rowHeight, ($r + 1) . '.)', 0, 0, 'L');

    // If employee exists, populate
    if (isset($employees[$r])) {

        $emp = $employees[$r];

        // Format values
        $fullName = strtoupper(trim(
            $emp['last_name'] . ', ' .
            $emp['first_name'] . ' ' .
            ($emp['middle_name'] ?? '') . ' ' .
            ($emp['name_suffix'] ?? '')
        ));

        $dob = !empty($emp['date_of_birth'])
            ? date('m/d/Y', strtotime($emp['date_of_birth']))
            : '';

        $doe = !empty($emp['date_hired'])
            ? date('m/d/Y', strtotime($emp['date_hired']))
            : '';

        // SS Number
        $pdf->SetXY($x + 12, $currentY + 2);
        $pdf->Cell($ssCol - 12, $rowHeight, $emp['sss_no'], 0, 0, 'C');

        // Name
        $pdf->SetXY($x + $ssCol + 2, $currentY + 2);
        $pdf->Cell($nameCol - 4, $rowHeight, $fullName, 0, 0, 'C');

        // Date of Birth
        $pdf->SetXY($x + $ssCol + $nameCol + 2, $currentY + 2);
        $pdf->Cell($dobCol - 4, $rowHeight, $dob, 0, 0, 'C');

        // Date of Employment
        $pdf->SetXY($x + $ssCol + $nameCol + $dobCol + 2, $currentY + 2);
        $pdf->Cell($doeCol - 4, $rowHeight, $doe, 0, 0, 'C');

        // Monthly Earnings (leave blank for now)

        // Position
        $pdf->SetXY(
            $x + $ssCol + $nameCol + $dobCol + $doeCol + $salaryCol + 2,
            $currentY + 2
        );
        $pdf->Cell($positionCol - 4, $rowHeight, strtoupper($emp['position']), 0, 0, 'C');

        // Relationship
        $pdf->SetXY(
            $x + $ssCol + $nameCol + $dobCol + $doeCol + $salaryCol + $positionCol + 2,
            $currentY + 2
        );
        $pdf->Cell($relCol - 4, $rowHeight, 'EMPLOYEE', 0, 0, 'C');
    }

    // ===============================
   // NOTHING FOLLOWS (only once)
   // ===============================
   else if ($r === $nothingFollowsRow) {

      $pdf->SetFont('helvetica', 'B', 7);

      // Name of Employee column position
      $nameX     = $x + $ssCol + 2;
      $nameWidth = $nameCol - 4;

      $pdf->SetXY($nameX, $currentY + 2);
      $pdf->Cell(
         $nameWidth,
         $rowHeight,
         '** NOTHING FOLLOWS **',
         0,
         0,
         'C'
      );

      $pdf->SetFont('helvetica', '', 7); // reset font
   }
}

/* ======================================================
   SUMMARY / APPROVAL ROWS (CORRECTED ALIGNMENT)
====================================================== */

$summaryRowHeight = 24; // total height for summary section
          // spacing between last employee row and summary
$summaryStartY = $startYRow + ($numRows * $rowHeight);

$pdf->SetFont('helvetica', '', 8);
$x = 10;
$padding = 2;

// Column widths
$col1Width = 35;   // Total No. of Reported Employees
$col2Width = 105;   // Owner / HR Certification (increased for long label)
$col3Width = 40;   // Received / Verified
$col4Width = 40;   // Encoded
$col5Width = $pageWidth - 20 - ($col1Width + $col2Width + $col3Width + $col4Width); // Evaluated

// Outer border
$pdf->Rect($x, $summaryStartY, $pageWidth - 20, $summaryRowHeight);

// Vertical dividers
$dividerX = $x;
$dividerX += $col1Width; $pdf->Line($dividerX, $summaryStartY, $dividerX, $summaryStartY + $summaryRowHeight);
$dividerX += $col2Width; $pdf->Line($dividerX, $summaryStartY, $dividerX, $summaryStartY + $summaryRowHeight);
$dividerX += $col3Width; $pdf->Line($dividerX, $summaryStartY, $dividerX, $summaryStartY + $summaryRowHeight);
$dividerX += $col4Width; $pdf->Line($dividerX, $summaryStartY, $dividerX, $summaryStartY + $summaryRowHeight);

// =============================
// Column 1: Total No. of Reported Employees
// =============================
$col1X = $x + $padding;
$col1Y = $summaryStartY + $padding;

// Set smaller font for header
$pdf->SetFont('helvetica', '', 7);
$pdf->SetXY($col1X, $col1Y);
$pdf->MultiCell($col1Width - 2*$padding, 4, 'Total No. of Reported Employees', 0, 'L');

// Box for total employees
$boxSize = 6;
$boxX = $col1X + 2;
$boxY = $col1Y + 8;
$pdf->Rect($boxX, $boxY, $boxSize, $boxSize);

// Place the total employees number inside the box
$totalEmployees = $totalEmployees ?? 0; // make sure you define this from your query
$pdf->SetFont('helvetica', 'B', 7);
$pdf->SetXY($boxX, $boxY + 1); // small vertical offset for centering
$pdf->Cell($boxSize, 4, $totalEmployees, 0, 0, 'C');

// Page indicator below box
$pdf->SetXY($col1X, $boxY + $boxSize + 2);
$pdf->SetFont('helvetica', '', 6);
$pdf->Cell($col1Width - 2*$padding, 3, 'Page___of___Pages/s', 0, 0, 'L');

// =============================
// Column 2: Owner / HR Certification
// =============================
$col2X = $x + $col1Width;
$col2Y = $summaryStartY + $padding;

// Header
$pdf->SetXY($col2X + $padding, $col2Y);
$pdf->SetFont('helvetica', '', 7);
$pdf->MultiCell(
    $col2Width - 2*$padding,
    4,
    'Name of Owner / Managing Partner / President / Chairman:',
    0,
    'L'
);

// Line for main signatory name
$lineY = $col2Y + 6;
$pdf->Line(
    $col2X + $padding,
    $lineY,
    $col2X + $col2Width - $padding,
    $lineY
);

// Main signatory name (top line)
$pdf->SetXY($col2X + $padding + 1, $lineY - 4);
$pdf->SetFont('helvetica', 'B', 8);
$pdf->Cell(
    $col2Width - 2*$padding,
    4,
    $signatory ?? '',
    0,
    0,
    'L'
);

// Certification text
$certY = $lineY + 2;
$pdf->SetXY($col2X + $padding, $certY);
$pdf->SetFont('helvetica', '', 7);
$pdf->MultiCell(
    $col2Width - 2*$padding,
    3.5,
    'I certify to the correctness of the above information.',
    0,
    'L'
);

// =============================
// Name / Designation / Date
// =============================
$detailsY   = $certY + 6;
$innerWidth = $col2Width - 2*$padding;
$spacing    = 1.5;
$labelWidth = ($innerWidth - 2*$spacing) / 3;

// Underlines
$pdf->SetXY($col2X + $padding, $detailsY);
$pdf->Cell($labelWidth, 3.5, '', 'B', 0, 'C'); // Name
$pdf->Cell($spacing, 3.5, '', 0, 0);
$pdf->Cell($labelWidth, 3.5, '', 'B', 0, 'C'); // Designation
$pdf->Cell($spacing, 3.5, '', 0, 0);
$pdf->Cell($labelWidth, 3.5, '', 'B', 0, 'C'); // Date

// =============================
// VALUES JUST ABOVE UNDERLINES
// =============================
$valueY = $detailsY - 0.8; // tight, natural spacing
$pdf->SetFont('helvetica', '', 7);

// Name
$pdf->SetXY($col2X + $padding, $valueY);
$pdf->Cell($labelWidth, 3, $signatory ?? '', 0, 0, 'C');

// Designation
$pdf->SetXY(
    $col2X + $padding + $labelWidth + $spacing,
    $valueY
);
$pdf->Cell($labelWidth, 3, $designation ?? '', 0, 0, 'C');

// Date (formatted)
$pdf->SetXY(
    $col2X + $padding + (2 * $labelWidth) + (2 * $spacing),
    $valueY
);
$pdf->Cell(
    $labelWidth,
    3,
    !empty($report_date) ? date('m/d/Y', strtotime($report_date)) : '',
    0,
    0,
    'C'
);

// =============================
// Labels below
// =============================
$pdf->SetXY($col2X + $padding, $detailsY + 4);
$pdf->SetFont('helvetica', '', 6);
$pdf->Cell($labelWidth, 3, 'Signature over Printed Name', 0, 0, 'C');
$pdf->Cell($spacing, 3, '', 0, 0);
$pdf->Cell($labelWidth, 3, 'Official Designation', 0, 0, 'C');
$pdf->Cell($spacing, 3, '', 0, 0);
$pdf->Cell($labelWidth, 3, 'Date', 0, 0, 'C');

// =============================
// Column 3: Received / Verified
// =============================
$col3X = $x + $col1Width + $col2Width;
$col3Y = $summaryStartY + $padding;
$pdf->SetXY($col3X + $padding, $col3Y);
$pdf->MultiCell($col3Width - 2*$padding, 5, 'Received / L-501 Verified By / Date:', 0, 'L');

// Line & signature
$lineY = $col3Y + 10;
$pdf->Line($col3X + $padding, $lineY, $col3X + $col3Width - $padding, $lineY);
$pdf->SetXY($col3X + $padding, $lineY + 2);
$pdf->Cell($col3Width - 2*$padding, 4, 'Signature over Printed Name', 0, 0, 'C');

// =============================
// Column 4: Encoded By / Date
// =============================
$col4X = $x + $col1Width + $col2Width + $col3Width;
$col4Y = $summaryStartY + $padding;
$pdf->SetXY($col4X + $padding, $col4Y);
$pdf->MultiCell($col4Width - 2*$padding, 5, 'Encoded By / Date:', 0, 'L');

$lineY = $col4Y + 10;
$pdf->Line($col4X + $padding, $lineY, $col4X + $col4Width - $padding, $lineY);
$pdf->SetXY($col4X + $padding, $lineY + 2);
$pdf->Cell($col4Width - 2*$padding, 4, 'Signature over Printed Name', 0, 0, 'C');

// =============================
// Column 5: Evaluated By / Date
// =============================
$col5X = $x + $col1Width + $col2Width + $col3Width + $col4Width;
$col5Y = $summaryStartY + $padding;
$pdf->SetXY($col5X + $padding, $col5Y);
$pdf->MultiCell($col5Width - 2*$padding, 5, 'Evaluated By / Date:', 0, 'L');

$lineY = $col5Y + 10;
$pdf->Line($col5X + $padding, $lineY, $col5X + $col5Width - $padding, $lineY);
$pdf->SetXY($col5X + $padding, $lineY + 2);
$pdf->Cell($col5Width - 2*$padding, 4, 'Signature over Printed Name', 0, 0, 'C');

$pdf->Output('SSS_R1A.pdf', 'I');
exit();