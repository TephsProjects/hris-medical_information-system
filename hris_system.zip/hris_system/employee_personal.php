<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM employees WHERE emp_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Employee not found.";
    exit();
}

$emp = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Personal Information</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/employee_view.css">
</head>
<body>
    <div class="navbar">
        <h2>PulseWork: HR Information System</h2>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
            <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
        </div>
    </div>

    <nav class="sub-navbar">
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>
            
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_leave.php">Leave Form</a></li>
                    <li><a href="leave_requests.php">Leave Requests</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
                <ul class="dropdown-content">
                    <li><a href="reports.php">Reports</a></li>
                    <li><a href="accounts.php">Accounts</a></li>
                    <li><a href="add_employee.php">Add Employee</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_job.php">Job Opening</a></li>
                    <li><a href="job_list.php">Job List</a></li>
                    <li><a href="add_candidate.php">Add Candidate</a></li>
                    <li><a href="candidate_list.php">Candidates</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
                <ul class="dropdown-content">
                    <li><a href="training_list.php">Trainings</a></li>
                    <li><a href="add_training.php">Add Training</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_performance.php">Add Evaluation</a></li>
                    <li><a href="performance_list.php">Evaluation List</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <div class="main-content">
        <?php if (isset($_GET['updated'])): ?>
            <div style="padding:10px; background:#d4edda; color:black; border-radius:5px;">
                ✅ Personal information updated successfully!
            </div>
        <?php endif; ?>

        <div class="employee-profile">
            <div class="employee-header">
                <img src="<?php echo !empty($emp['image']) ? 'uploads/' . htmlspecialchars($emp['image']) : 'assets/images/default.png'; ?>" alt="Employee Image">

                <div class="info">
                    <h2><?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?></h2>
                    <p><strong>Employee No:</strong> <?php echo htmlspecialchars($emp['employee_no']); ?></p>
                    <p><strong><?php echo htmlspecialchars($emp['position']); ?></strong> — <?php echo htmlspecialchars($emp['department']); ?></p>
                    <p>Hired: <?php echo htmlspecialchars($emp['date_hired']); ?></p>
                </div>

                <div class="coe-actions">
                    <a href="generate_coe.php?id=<?php echo $emp['emp_id']; ?>" 
                    class="coe-btn" 
                    target="_blank">
                        📄 Generate COE
                    </a>
                </div>
            </div>

            <div class="employee-body">
                <div class="info-section">
                    <h3>Personal Information</h3>

                    <form method="POST" action="update_personal.php">
                        <input type="hidden" name="emp_id" value="<?php echo $emp['emp_id']; ?>">

                        <div class="info-columns" style="display:flex; gap:30px; flex-wrap:wrap;">
                            <!-- Left Column -->
                            <div class="column" style="flex:1; min-width:250px;">
                                <!-- Personal Info -->
                                <p><strong>First Name:</strong></p>
                                <input type="text" name="first_name" value="<?= htmlspecialchars($emp['first_name']); ?>" class="form-control">
                                <p><strong>Middle Name:</strong></p>
                                <input type="text" name="middle_name" value="<?= htmlspecialchars($emp['middle_name'] ?? ''); ?>" class="form-control">
                                <p><strong>Last Name:</strong></p>
                                <input type="text" name="last_name" value="<?= htmlspecialchars($emp['last_name']); ?>" class="form-control">
                                <p><strong>Name Suffix:</strong></p>
                                <input type="text" name="name_suffix" value="<?= htmlspecialchars($emp['name_suffix'] ?? ''); ?>" class="form-control">
                                <p><strong>Date of Birth:</strong></p>
                                <input type="date" name="date_of_birth" value="<?= htmlspecialchars($emp['date_of_birth']); ?>" class="form-control">
                                <p><strong>Place of Birth:</strong></p>
                                <input type="text" name="place_of_birth" value="<?= htmlspecialchars($emp['place_of_birth'] ?? ''); ?>" class="form-control">
                                <p><strong>Gender:</strong></p>
                                <select name="gender" class="form-control">
                                    <option value="Male" <?= ($emp['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?= ($emp['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                                </select>
                                <p><strong>Civil Status:</strong></p>
                                <input type="text" name="civil_status" value="<?= htmlspecialchars($emp['civil_status']); ?>" class="form-control">
                            </div>

                            <!-- Middle Column -->
                            <div class="column" style="flex:1; min-width:250px;">
                                <!-- Contact / Basic Info -->
                                <p><strong>Nationality:</strong></p>
                                <input type="text" name="nationality" value="<?= htmlspecialchars($emp['nationality']); ?>" class="form-control">
                                <p><strong>Religion:</strong></p>
                                <input type="text" name="religion" value="<?= htmlspecialchars($emp['religion'] ?? ''); ?>" class="form-control">
                                <p><strong>Spouse Name:</strong></p>
                                <input type="text" name="spouse_name" value="<?= htmlspecialchars($emp['spouse_name'] ?? ''); ?>" class="form-control">
                                <p><strong>Blood Type:</strong></p>
                                <input type="text" name="blood_type" value="<?= htmlspecialchars($emp['blood_type'] ?? ''); ?>" class="form-control">
                                <p><strong>Medical Notes / Allergies:</strong></p>
                                <textarea name="medical_notes" class="form-control"><?= htmlspecialchars($emp['medical_notes'] ?? ''); ?></textarea>
                                <p><strong>Address:</strong></p>
                                <textarea name="address" class="form-control"><?= htmlspecialchars($emp['address']); ?></textarea>
                            </div>

                            <!-- Right Column -->
                            <div class="column" style="flex:1; min-width:250px;">
                                <!-- Family / Guardian Info -->
                                <p><strong>Father's Name:</strong></p>
                                <input type="text" name="father_name" value="<?= htmlspecialchars($emp['father_name'] ?? ''); ?>" class="form-control">
                                <p><strong>Father's Occupation:</strong></p>
                                <input type="text" name="father_occupation" value="<?= htmlspecialchars($emp['father_occupation'] ?? ''); ?>" class="form-control">

                                <p><strong>Mother's Name:</strong></p>
                                <input type="text" name="mother_name" value="<?= htmlspecialchars($emp['mother_name'] ?? ''); ?>" class="form-control">
                                <p><strong>Mother's Occupation:</strong></p>
                                <input type="text" name="mother_occupation" value="<?= htmlspecialchars($emp['mother_occupation'] ?? ''); ?>" class="form-control">

                                <p><strong>Guardian Name:</strong></p>
                                <input type="text" name="guardian_name" value="<?= htmlspecialchars($emp['guardian_name'] ?? ''); ?>" class="form-control">
                                <p><strong>Guardian Contact:</strong></p>
                                <input type="text" name="guardian_contact" value="<?= htmlspecialchars($emp['guardian_contact'] ?? ''); ?>" class="form-control">
                            </div>
                        </div>

                        <button type="submit" class="update-btn" style="background:#007bff; margin-top:20px;">
                            💾 Update Personal Information
                        </button>
                    </form>
                </div>
            </div>

            <div class="footer-actions">
                <a href="employee_view.php?id=<?= $emp['emp_id']; ?>" class="back-btn">← Back to Full Profile</a>
                <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
            </div>
        </div>
    </div>
<div id="logoutModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Confirm Logout</h3>
            <p>Are you sure you want to logout?</p>
            <div class="modal-buttons">
                <button id="confirmLogout" class="btn">Yes, Logout</button>
                <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
            </div>
        </div>
    </div>
<script>
function toggleDropdown(event) {
    event.preventDefault();
    document.querySelectorAll('.dropdown').forEach(drop => {
        if (!drop.contains(event.target)) drop.classList.remove('active');
    });
    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

closeModal.onclick = function() { logoutModal.style.display = 'none'; }
cancelLogout.onclick = function() { logoutModal.style.display = 'none'; }
confirmLogout.onclick = function() { window.location.href = 'logout.php'; }
</script>
</body>
</html>
