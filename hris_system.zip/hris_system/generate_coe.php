<?php
session_start();
require __DIR__ . '/fpdf/fpdf.php';
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    exit('Unauthorized');
}

if (!isset($_GET['id'])) {
    exit('Employee ID missing');
}

/* ======================
   GET HR USER DETAILS
====================== */
$hrStmt = $conn->prepare("
    SELECT full_name, role, e_signature
    FROM users
    WHERE id = ?
");
$hrStmt->bind_param("i", $_SESSION['user_id']);
$hrStmt->execute();
$hrResult = $hrStmt->get_result();

if ($hrResult->num_rows === 0) {
    exit('HR user not found');
}

$hr = $hrResult->fetch_assoc();

/* ======================
   SIGNATURE PATH CHECK
====================== */
$signaturePath = null;
if (!empty($hr['e_signature'])) {
    $path = __DIR__ . '/uploads/esignatures/' . $hr['e_signature'];
    if (file_exists($path)) {
        $signaturePath = $path;
    }
}

/* ======================
   GET EMPLOYEE DETAILS
====================== */
$empId = (int)$_GET['id'];

$stmt = $conn->prepare("
    SELECT first_name, last_name, position, department, date_hired, employment_status
    FROM employees
    WHERE emp_id = ?
");
$stmt->bind_param("i", $empId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    exit('Employee not found');
}

$emp = $result->fetch_assoc();
$fullName = $emp['first_name'] . ' ' . $emp['last_name'];

/* ======================
   PDF SETUP
====================== */
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetMargins(15, 15, 15);
$pdf->SetAutoPageBreak(true, 25);

$pdf->Ln(5);
$pdf->Line(15, $pdf->GetY(), 195, $pdf->GetY()); 
$pdf->Ln(10); // small spacing before title

/* ======================
   TITLE
====================== */
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'CERTIFICATE OF EMPLOYMENT', 0, 1, 'C');
$pdf->Ln(8);

/* ======================
   BODY
====================== */
$pdf->SetFont('Arial', '', 10.5);

$bodyText =
    "This is to certify that {$fullName} is currently employed by PulseWork "
  . "as a {$emp['position']} under the {$emp['department']} Department.\n\n"
  . "The employee commenced employment on "
  . date('F d, Y', strtotime($emp['date_hired'])) . " and is presently holding a "
  . "{$emp['employment_status']} employment status.\n\n"
  . "This Certificate of Employment is being issued upon the request of the "
  . "employee for reference and for whatever lawful purpose it may serve.";

$pdf->MultiCell(0, 7, $bodyText, 0, 'J');
$pdf->Ln(15);

/* ======================
   ISSUED DATE
====================== */
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(
    0,
    6,
    'Issued this ' . date('jS') . ' day of ' . date('F Y') . ' at Makati City, Philippines.',
    0,
    1
);
$pdf->Ln(20);

/* ======================
   SIGNATURE BLOCK (LEFT SHIFTED)
====================== */
$blockX = 10; // moved 10mm to the left
$lineWidth = 80;
$signatureWidth = 45;
$startY = $pdf->GetY();
$centerX = $blockX + ($lineWidth / 2);

/* E-SIGNATURE */
if ($signaturePath) {
    $pdf->Image(
        $signaturePath,
        $centerX - ($signatureWidth / 2),
        $startY,
        $signatureWidth
    );
}

/* FULL NAME (floating above underline) */
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetXY($blockX, $startY + 12);
$pdf->Cell($lineWidth, 6, strtoupper($hr['full_name']), 0, 1, 'C');

/* UNDERLINE */
$pdf->SetXY($blockX, $startY + 12);
$pdf->Cell($lineWidth, 8, '_____________________________', 0, 1, 'C');

/* ROLE */
$pdf->SetFont('Arial', '', 10);
$pdf->SetX($blockX);
$pdf->Cell($lineWidth, 6, $hr['role'], 0, 1, 'C');

/* ======================
   FOOTER
====================== */
$pdf->SetY(-30);
$pdf->SetFont('Arial', 'I', 8);
$pdf->Cell(
    0,
    5,
    'This document is system-generated and does not require a physical signature.',
    0,
    1,
    'C'
);

/* ======================
   OUTPUT
====================== */
$pdf->Output('I', 'Certificate_of_Employment.pdf');
exit;
