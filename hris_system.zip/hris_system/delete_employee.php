<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['id'])) {
    $emp_id = intval($_GET['id']);

    // Start transaction to ensure all-or-nothing deletion
    $conn->begin_transaction();

    try {
        // 1️⃣ Delete related performance records
        $tables = ['performance', 'trainings', 'onboarding_tasks'];
        foreach ($tables as $table) {
            $delStmt = $conn->prepare("DELETE FROM $table WHERE emp_id = ?");
            $delStmt->bind_param("i", $emp_id);
            $delStmt->execute();
            $delStmt->close();
        }

        // 2️⃣ Delete employee
        $stmt = $conn->prepare("DELETE FROM employees WHERE emp_id = ?");
        $stmt->bind_param("i", $emp_id);
        $stmt->execute();
        $stmt->close();

        // 3️⃣ Commit transaction
        $conn->commit();

        // Redirect back to dashboard with success message
        header("Location: dashboard.php?deleted=1");
        exit();

    } catch (Exception $e) {
        // Rollback if any error occurs
        $conn->rollback();
        echo "Error deleting employee: " . $e->getMessage();
        exit();
    }
} else {
    header("Location: dashboard.php");
    exit();
}
?>
