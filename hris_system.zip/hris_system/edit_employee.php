<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$message = '';

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$emp_id = $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM employees WHERE emp_id = ?");
$stmt->bind_param("i", $emp_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: dashboard.php");
    exit();
}

$employee = $result->fetch_assoc();

// Fetch departments and positions at the top of the page
$departments = [];
$depQuery = $conn->query("SELECT * FROM departments ORDER BY department_name ASC");
while ($d = $depQuery->fetch_assoc()) {
    $departments[] = $d;
}

$positions = [];
$posQuery = $conn->query("SELECT * FROM positions ORDER BY position_name ASC");
while ($p = $posQuery->fetch_assoc()) {
    $positions[] = $p;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name     = $_POST['first_name'];
    $last_name      = $_POST['last_name'];
    $address        = $_POST['address'];
    $age            = $_POST['age'];
    $civil_status   = $_POST['civil_status'];
    $date_of_birth  = $_POST['date_of_birth'];
    $department_id  = $_POST['department_id'];
    $tax_status     = $_POST['tax_status'];
    $tin_no         = $_POST['tin_no'];
    $sss_no         = $_POST['sss_no'];
    $philhealth_no  = $_POST['philhealth_no'];
    $nationality    = $_POST['nationality'];
    $gender         = $_POST['gender'];
    $mobile_number  = $_POST['mobile_number'];
    $email          = $_POST['email'];
    $position_id    = $_POST['position_id'];
    $date_hired     = $_POST['date_hired'];
    $contact_person = $_POST['contact_person'];
    $emergency_contact = $_POST['emergency_contact'];
    $contract_end_date = $_POST['contract_end_date'];

    $image_path = $employee['image'];
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
        $file_name = time() . "_" . basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $file_name;
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_path = $file_name;
        }
    }

    $contract_file = $employee['contract_file'];
    if (!empty($_FILES['contract_file']['name'])) {
        $contract_dir = "contracts/";
        if (!is_dir($contract_dir)) mkdir($contract_dir, 0777, true);
        $file_name = time() . "_" . basename($_FILES["contract_file"]["name"]);
        $target_file = $contract_dir . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        if (in_array($file_type, ['pdf', 'doc', 'docx'])) {
            if (move_uploaded_file($_FILES["contract_file"]["tmp_name"], $target_file)) {
                $contract_file = $file_name;
            }
        }
    }

    $sss_file = $employee['sss_file'];
    $philhealth_file = $employee['philhealth_file'];
    $pagibig_file = $employee['pagibig_file'];
    $nbi_file = $employee['nbi_file'];

    if (!empty($_FILES['sss_file']['name'])) {
        $dir = "uploads/sss/";
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $file_name = time() . "_" . basename($_FILES["sss_file"]["name"]);
        $target_file = $dir . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (in_array($file_type, ['pdf', 'jpg', 'jpeg', 'png'])) {
            if (move_uploaded_file($_FILES["sss_file"]["tmp_name"], $target_file)) {
                $sss_file = $file_name;
            }
        }
    }

    if (!empty($_FILES['philhealth_file']['name'])) {
        $dir = "uploads/philhealth/";
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $file_name = time() . "_" . basename($_FILES["philhealth_file"]["name"]);
        $target_file = $dir . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (in_array($file_type, ['pdf', 'jpg', 'jpeg', 'png'])) {
            if (move_uploaded_file($_FILES["philhealth_file"]["tmp_name"], $target_file)) {
                $philhealth_file = $file_name;
            }
        }
    }

    if (!empty($_FILES['pagibig_file']['name'])) {
        $dir = "uploads/pagibig/";
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $file_name = time() . "_" . basename($_FILES["pagibig_file"]["name"]);
        $target_file = $dir . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (in_array($file_type, ['pdf', 'jpg', 'jpeg', 'png'])) {
            if (move_uploaded_file($_FILES["pagibig_file"]["tmp_name"], $target_file)) {
                $pagibig_file = $file_name;
            }
        }
    }

    if (!empty($_FILES['nbi_file']['name'])) {
        $dir = "uploads/nbi/";
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $file_name = time() . "_" . basename($_FILES["nbi_file"]["name"]);
        $target_file = $dir . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (in_array($file_type, ['pdf', 'jpg', 'jpeg', 'png'])) {
            if (move_uploaded_file($_FILES["nbi_file"]["tmp_name"], $target_file)) {
                $nbi_file = $file_name;
            }
        }
    }

    $update = $conn->prepare("UPDATE employees 
        SET first_name=?, last_name=?, address=?, age=?, civil_status=?, date_of_birth=?, 
            department_id=?, tax_status=?, tin_no=?, sss_no=?, philhealth_no=?, nationality=?, gender=?, 
            mobile_number=?, email=?, position_id=?, date_hired=?, contact_person=?, emergency_contact=?, 
            image=?, contract_file=?, contract_end_date=?, sss_file=?, philhealth_file=?, pagibig_file=?, nbi_file=?
        WHERE emp_id=?");

    $update->bind_param(
        "sssissssssssssssssssssssssi",
        $first_name, $last_name, $address, $age, $civil_status, $date_of_birth, $department_id, $tax_status,
        $tin_no, $sss_no, $philhealth_no, $nationality, $gender, $mobile_number, $email, $position_id,
        $date_hired, $contact_person, $emergency_contact, $image_path, $contract_file, $contract_end_date,
        $sss_file, $philhealth_file, $pagibig_file, $nbi_file, $emp_id
    );

    if ($update->execute()) {
        $message = "✅ Employee record updated successfully!";
        $stmt->execute();
        $result = $stmt->get_result();
        $employee = $result->fetch_assoc();
    } else {
        $message = "❌ Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Employee</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/edit_employee.css">
</head>
<body>
    <div class="navbar">
        <h2>PulseWork: HR Information System</h2>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
            <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
        </div>
    </div>

    <nav class="sub-navbar">
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>
            
            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_leave.php">Leave Form</a></li>
                    <li><a href="leave_requests.php">Leave Requests</a></li>
                </ul>
            </li>

            <!-- <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Payroll ▼</a>
                <ul class="dropdown-content">
                    <li><a href="add_payroll.php">Add Payroll</a></li>
                    <li><a href="payroll.php">Payroll List</a></li>
                    <li><a href="add_benefits.php">Add Benefits</a></li>
                    <li><a href="benefits_list.php">Benefits List</a></li>
                </ul>
            </li> -->

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
                <ul class="dropdown-content">
                    <li><a href="reports.php">Reports</a></li>
                    <li><a href="accounts.php">Accounts</a></li>
                    <li><a href="add_employee.php" class="active">Add/Edit Employee</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_job.php">Job Opening</a></li>
                    <li><a href="job_list.php">Job List</a></li>
                    <li><a href="add_candidate.php">Add Candidate</a></li>
                    <li><a href="candidate_list.php">Candidates</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Training ▾</a>
                <ul class="dropdown-content">
                    <li><a href="training_list.php">Trainings</a></li>
                    <li><a href="add_training.php">Add Training</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_performance.php">Add Evaluation</a></li>
                    <li><a href="performance_list.php">Evaluation List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <div class="main-content">
        <div class="edit-card">
            <h3>Edit Employee Information</h3>

            <?php if ($message): ?>
                <p class="message"><?php echo $message; ?></p>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div class="form-grid">
                    <div class="form-group">
                        <label>First Name:</label>
                        <input type="text" name="first_name" value="<?php echo htmlspecialchars($employee['first_name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Last Name:</label>
                        <input type="text" name="last_name" value="<?php echo htmlspecialchars($employee['last_name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Address:</label>
                        <input type="text" name="address" value="<?php echo htmlspecialchars($employee['address']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Age:</label>
                        <input type="number" name="age" min="18" max="99" value="<?php echo htmlspecialchars($employee['age']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Date of Birth:</label>
                        <input type="date" name="date_of_birth" value="<?php echo htmlspecialchars($employee['date_of_birth']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Civil Status:</label>
                        <select name="civil_status">
                            <option value="Single" <?php if($employee['civil_status']=='Single') echo 'selected'; ?>>Single</option>
                            <option value="Married" <?php if($employee['civil_status']=='Married') echo 'selected'; ?>>Married</option>
                            <option value="Widowed" <?php if($employee['civil_status']=='Widowed') echo 'selected'; ?>>Widowed</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Department:</label>
                        <select name="department_id" required>
                            <option value="">-- Select Department --</option>
                            <?php foreach($departments as $dep): ?>
                                <option value="<?php echo $dep['department_id']; ?>"
                                    <?php echo ($employee['department_id'] == $dep['department_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($dep['department_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Position:</label>
                        <select name="position_id" required>
                            <option value="">-- Select Position --</option>
                            <?php foreach($positions as $pos): ?>
                                <option value="<?php echo $pos['position_id']; ?>"
                                    <?php echo ($employee['position_id'] == $pos['position_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($pos['position_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Tax Status:</label>
                        <input type="text" name="tax_status" value="<?php echo htmlspecialchars($employee['tax_status']); ?>">
                    </div>

                    <div class="form-group">
                        <label>TIN No.:</label>
                        <input type="text" name="tin_no" value="<?php echo htmlspecialchars($employee['tin_no']); ?>">
                    </div>

                    <div class="form-group">
                        <label>SSS No.:</label>
                        <input type="text" name="sss_no" value="<?php echo htmlspecialchars($employee['sss_no']); ?>">
                    </div>

                    <div class="form-group">
                        <label>PhilHealth No.:</label>
                        <input type="text" name="philhealth_no" value="<?php echo htmlspecialchars($employee['philhealth_no']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Nationality:</label>
                        <input type="text" name="nationality" value="<?php echo htmlspecialchars($employee['nationality']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Gender:</label>
                        <select name="gender">
                            <option value="Male" <?php if($employee['gender']=='Male') echo 'selected'; ?>>Male</option>
                            <option value="Female" <?php if($employee['gender']=='Female') echo 'selected'; ?>>Female</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Mobile Number:</label>
                        <input type="text" name="mobile_number" value="<?php echo htmlspecialchars($employee['mobile_number']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Email:</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($employee['email']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Date Hired:</label>
                        <input type="date" name="date_hired" value="<?php echo htmlspecialchars($employee['date_hired']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Contact Person:</label>
                        <input type="text" name="contact_person" value="<?php echo htmlspecialchars($employee['contact_person']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Emergency Contact:</label>
                        <input type="text" name="emergency_contact" value="<?php echo htmlspecialchars($employee['emergency_contact']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Profile Image:</label>
                        <?php if (!empty($employee['image'])): ?>
                            <img src="uploads/<?php echo htmlspecialchars($employee['image']); ?>" alt="Profile Image" width="100">
                        <?php endif; ?>
                        <input type="file" name="image" accept="image/*">
                    </div>

                    <div class="form-group">
                        <label>Contract File:</label>
                        <?php if (!empty($employee['contract_file'])): ?>
                            <a href="contracts/<?php echo htmlspecialchars($employee['contract_file']); ?>" target="_blank">📄 View Current Contract</a>
                        <?php endif; ?>
                        <input type="file" name="contract_file" accept=".pdf,.doc,.docx">
                    </div>

                    <div class="form-group">
                        <label>Contract End Date:</label>
                        <input type="date" name="contract_end_date" value="<?php echo htmlspecialchars($employee['contract_end_date']); ?>">
                    </div>

                    <div class="form-group">
                        <label>SSS File:</label>
                        <?php if (!empty($employee['sss_file'])): ?>
                            <a href="uploads/sss/<?php echo htmlspecialchars($employee['sss_file']); ?>" target="_blank">📄 View Current SSS File</a>
                        <?php endif; ?>
                        <input type="file" name="sss_file" accept=".pdf,.jpg,.jpeg,.png">
                    </div>

                    <div class="form-group">
                        <label>PhilHealth File:</label>
                        <?php if (!empty($employee['philhealth_file'])): ?>
                            <a href="uploads/philhealth/<?php echo htmlspecialchars($employee['philhealth_file']); ?>" target="_blank">📄 View Current PhilHealth File</a>
                        <?php endif; ?>
                        <input type="file" name="philhealth_file" accept=".pdf,.jpg,.jpeg,.png">
                    </div>

                    <div class="form-group">
                        <label>Pag-IBIG File:</label>
                        <?php if (!empty($employee['pagibig_file'])): ?>
                            <a href="uploads/pagibig/<?php echo htmlspecialchars($employee['pagibig_file']); ?>" target="_blank">📄 View Current Pag-IBIG File</a>
                        <?php endif; ?>
                        <input type="file" name="pagibig_file" accept=".pdf,.jpg,.jpeg,.png">
                    </div>

                    <div class="form-group">
                        <label>NBI Clearance:</label>
                        <?php if (!empty($employee['nbi_file'])): ?>
                            <a href="uploads/nbi/<?php echo htmlspecialchars($employee['nbi_file']); ?>" target="_blank">📄 View Current NBI Clearance</a>
                        <?php endif; ?>
                        <input type="file" name="nbi_file" accept=".pdf,.jpg,.jpeg,.png">
                    </div>
                </div>

                <button type="submit" class="btn">💾 Save Changes</button>
            </form>
        </div>
    </div>

    <div id="logoutModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Confirm Logout</h3>
            <p>Are you sure you want to logout?</p>
            <div class="modal-buttons">
                <button id="confirmLogout" class="btn">Yes, Logout</button>
                <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
            </div>
        </div>
    </div>

<script>
function toggleDropdown(event) {
    event.preventDefault();

    document.querySelectorAll('.dropdown').forEach(drop => {
        if (!drop.contains(event.target)) {
            drop.classList.remove('active');
        }
    });

    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}
</script>
</body>
</html>